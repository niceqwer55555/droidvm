#!/system/bin/sh


# source vm_config.sh

# mkdir -p  $LINUX_DIR/tmp
# chmod 777 $LINUX_DIR/tmp

# rm -rf restorevm.sh

echo ""
