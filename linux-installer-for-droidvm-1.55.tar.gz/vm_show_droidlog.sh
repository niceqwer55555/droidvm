#!/bin/bash
#exec cmd -e "/system/bin/logcat -v tag|grep 'droidvm :'"
 cmd -e '/system/bin/logcat -v process droidvm:* *:S'
