#!/bin/bash

# action=$1
action=stop

gui_title="安卓端自启动服务进程"

if [ "$action" == "" ]; then
	action=stop
fi

echo "0">${app_home}/app_boot_config/cfg_autostart_virgl_service.txt
echo "0">${app_home}/app_boot_config/cfg_autostart_audio_service.txt
echo "0">${app_home}/app_boot_config/cfg_autostart_ifbrg_service.txt
echo "0">${app_home}/app_boot_config/cfg_autostart_vpntr_service.txt

gxmessage -title "${gui_title}" "已不会自行启动，重启生效"  -center
exit 0
