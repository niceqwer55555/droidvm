#!/bin/bash
# (
#  sleep 1;
#  echo ". ./tools/vm_config.sh";
#  sleep 1;
#  echo "set|grep PROOT";
#  sleep 1;
#  #echo exit
# )|exec telnet 127.0.0.1 5555


telnet 127.0.0.1 5555
