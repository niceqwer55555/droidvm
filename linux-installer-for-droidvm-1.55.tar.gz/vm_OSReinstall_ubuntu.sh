#!/bin/bash

gxmessage -title "重装系统"  $'\n请注意，重装系统会将当前系统的文件全部删除，且不可恢复\n确定要重装系统吗？\n\n' -center -buttons "我确定:1,取消:0"
if [ $? -eq 1 ]; then

	echo "3">${app_home}/app_boot_config/cfg_bootup_wait_seconds.txt

    rm -rf ${tools_dir}/startvm.sh
    
    # gxmessage -title "重新安装系统" "重新安装系统的标志已创建, 下次启动时生效"  -center

    gxmessage -title "重新安装系统" "重新安装系统的标志已创建, 下次启动时生效" -center -buttons "立即重启:1,稍后重启:0"
    if [ $? -eq 1 ]; then
		cat <<- EOF > /exbin/ipc/clipboardfromvm
			zzvm://setup
			# ref: http://droidvm.com/cn/olinux.htm
		EOF
        echo "#sethostclipboard" > ${NOTIFY_PIPE}
        ( sleep 1; /exbin/tools/vm_OSShutdown.sh ) &
    fi

fi
