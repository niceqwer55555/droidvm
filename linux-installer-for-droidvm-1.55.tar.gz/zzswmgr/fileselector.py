#!/usr/bin/python3
import gi
import os
import sys
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gio
from gi.repository import GLib

dialog = Gtk.FileChooserDialog(
title="请选择您下载的安装包",
parent=None,
action=Gtk.FileChooserAction.OPEN
)

script_dir = os.path.dirname(os.path.abspath(__file__))
dialog.set_default_size(800, 800)
dialog.set_resizable(True)
dialog.set_decorated(True)
dialog.set_icon_from_file(script_dir + "/appicons/ic_zzswmgr.png")

default_dir = os.path.expanduser("/home/droidvm/Desktop")  # 示例：用户文档目录
if os.path.exists(default_dir):
      dialog.set_current_folder(default_dir)  # 设置初始目录

# 添加按钮
dialog.add_buttons(
Gtk.STOCK_CANCEL,
Gtk.ResponseType.CANCEL,
Gtk.STOCK_OPEN,
Gtk.ResponseType.OK
)

# 显示对话框并处理响应
response = dialog.run()

if response == Gtk.ResponseType.OK:
      filename = dialog.get_filename()
      print(filename)

dialog.destroy()
