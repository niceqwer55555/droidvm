#!/usr/bin/env python3
#-*- encoding:utf-8 -*-

"""
软件说明
1. 此脚本为虚拟电脑(droidvm)中使用的 wbox 调参工具


export PREFIX=/exbin/z/usr
echo "unset BOX64_DYNAREC_ALIGNED_ATOMICS">$PREFIX/glibc/opt/conf/dynarec/aligned_atomics.conf
echo "export BOX64_DYNAREC_FASTNAN=0">$PREFIX/glibc/opt/conf/dynarec/fastnan.conf
echo "unset BOX64_DYNAREC_FASTROUND">$PREFIX/glibc/opt/conf/dynarec/fastround.conf
echo "export BOX64_DYNAREC_SAFEFLAGS=2">$PREFIX/glibc/opt/conf/dynarec/safeflags.conf
echo "export BOX64_DYNAREC_STRONGMEM=2">$PREFIX/glibc/opt/conf/dynarec/strongmem.conf
echo "unset BOX64_DYNAREC_WAIT">$PREFIX/glibc/opt/conf/dynarec/wait.conf
echo "unset BOX64_DYNAREC_X87DOUBLE">$PREFIX/glibc/opt/conf/dynarec/x87double.conf
echo "export BOX64_DYNAREC_CALLRET=1">$PREFIX/glibc/opt/conf/dynarec/callret.conf
echo "unset BOX64_IGNOREINT3">$PREFIX/glibc/opt/conf/dynarec/ignoreint3.conf

ls -al $PREFIX/glibc/opt/conf/dynarec_preset.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/aligned_atomics.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/fastnan.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/fastround.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/safeflags.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/strongmem.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/wait.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/x87double.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/callret.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/ignoreint3.conf
ls -al $PREFIX/glibc/opt/conf/dynarec/bigblock.conf

cat $PREFIX/glibc/opt/conf/dynarec_preset.conf
cat $PREFIX/glibc/opt/conf/dynarec/aligned_atomics.conf
cat $PREFIX/glibc/opt/conf/dynarec/fastnan.conf
cat $PREFIX/glibc/opt/conf/dynarec/fastround.conf
cat $PREFIX/glibc/opt/conf/dynarec/safeflags.conf
cat $PREFIX/glibc/opt/conf/dynarec/strongmem.conf
cat $PREFIX/glibc/opt/conf/dynarec/wait.conf
cat $PREFIX/glibc/opt/conf/dynarec/x87double.conf
cat $PREFIX/glibc/opt/conf/dynarec/callret.conf
cat $PREFIX/glibc/opt/conf/dynarec/ignoreint3.conf
cat $PREFIX/glibc/opt/conf/dynarec/bigblock.conf


"""

import argparse
import struct
import gi
import os
import sys
import subprocess
import asyncio
import time
import threading
import shutil
import re

gi.require_version("Gtk", "3.0")
from gi.repository import GLib,Gtk,Gio

parser = None
swtitle = 'wbox参数调节'
swver = '1.0'
win = None
WBOXUSR = "/exbin/z/usr"
WBOXCFG = WBOXUSR + "/glibc/opt/conf"

def shellexec(strcmd):
    try:
        print("正在运行指令：" + strcmd)
        process = subprocess.Popen(strcmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE) #, cwd=os.environ['ZZSWMGR_WORK_DIR'], env={'ZZSWMGR_WORK_DIR':os.environ['ZZSWMGR_WORK_DIR']})
        # process.stdin.close()
        # process.stdout.close()
        process.wait()
        strout = process.stdout.read().decode("utf8")
        # print(strout)
        return process.returncode
    except Exception as e:
        print("" + e)
        return -1


class boxDynarec(Gtk.Grid):
    def __init__(self, stack):
        super(boxDynarec,self).__init__()
        self.stack = stack

        self.preset_filePath= "/dynarec_preset.conf"
        self.preset_activeid= 0

        rows=0;wcolumn0=33;wcolumn1=33;wcolumn2=33
        # page = Gtk.Label(label="待实现", xalign=0, yalign=0)
        # page = Gtk.Grid()
        page = self
        page.set_border_width(20)
        page.set_column_spacing(5)
        page.set_row_spacing(10)
        stack.add_titled(page, "page_boxDynarec", "Box Dynarec 设置)")
        
        iname = Gtk.Label(label="预设的组合：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("兼容性最好")
        ictrl.append_text("默认+兼容")
        ictrl.append_text("默认设置")
        ictrl.append_text("性能最高")
        self.cbPreset = ictrl
        ictrl.connect('changed', self.onComboPreSetChanged)
        idesc = Gtk.Label(label="\n\n\n", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="1：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_DYNAREC_ALIGNED_ATOMICS = ictrl
        idesc = Gtk.Label(label="\nBOX64_DYNAREC_ALIGNED_ATOMICS\n", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="2：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_DYNAREC_FASTNAN = ictrl
        idesc = Gtk.Label(label="\nBOX64_DYNAREC_FASTNAN\n", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="3：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_DYNAREC_FASTROUND = ictrl
        idesc = Gtk.Label(label="\nBOX64_DYNAREC_FASTROUND\n", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="4：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_DYNAREC_SAFEFLAGS = ictrl
        idesc = Gtk.Label(label="\nBOX64_DYNAREC_SAFEFLAGS\n", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="5：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_DYNAREC_STRONGMEM = ictrl
        idesc = Gtk.Label(label="\nBOX64_DYNAREC_STRONGMEM\n", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="6：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_DYNAREC_WAIT = ictrl
        idesc = Gtk.Label(label="\nBOX64_DYNAREC_WAIT\n", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="7：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_DYNAREC_X87DOUBLE = ictrl
        idesc = Gtk.Label(label="\nBOX64_DYNAREC_X87DOUBLE\n", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="8：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_DYNAREC_CALLRET = ictrl
        idesc = Gtk.Label(label="BOX64_DYNAREC_CALLRET\n为1时\n性能更好", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="9：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_DYNAREC_BIGBLOCK = ictrl
        idesc = Gtk.Label(label="BOX64_DYNAREC_BIGBLOCK\n为0时\n可修复部分游戏卡死的问题", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="10：", xalign=1.0)
        ictrl = Gtk.ComboBoxText()
        ictrl.append_text("0")
        ictrl.append_text("1")
        ictrl.append_text("2")
        ictrl.append_text("3")
        ictrl.append_text("禁用")
        self.BOX64_IGNOREINT3 = ictrl
        idesc = Gtk.Label(label="\nBOX64_IGNOREINT3\n", xalign=0)
        idesc.set_justify(Gtk.Justification.LEFT)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(ictrl, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        page.attach_next_to(idesc, ictrl, Gtk.PositionType.RIGHT, wcolumn2, 1)
        rows += 1

        iname = Gtk.Label(label="", xalign=1.0)
        self.btnSave = Gtk.Button(label="\n保存\n")
        self.btnSave.connect("clicked", self.on_btnSave_clicked)
        page.attach(iname, 0, rows, wcolumn0, 1)
        page.attach_next_to(self.btnSave, iname, Gtk.PositionType.RIGHT, wcolumn1, 1)
        rows += 1

        # 最后再做这个动作！
        self.loadPreSetIndex()
        self.cbPreset.set_active(self.preset_activeid)

    def loadPreSetIndex(self):
        global win
        try:
            filepath = self.preset_filePath
            fullpath = WBOXCFG + filepath
            content = ""
            with open(fullpath, 'r') as file: 
                content = file.read()

            # print("content:\n" + content)

            self.preset_activeid= 0
            if re.findall(r"DYNAREC_CURRENT_PRESET=0\n", content):
                self.preset_activeid= 0
            if re.findall(r"DYNAREC_CURRENT_PRESET=1\n", content):
                self.preset_activeid= 1
            if re.findall(r"DYNAREC_CURRENT_PRESET=2\n", content):
                self.preset_activeid= 2
            if re.findall(r"DYNAREC_CURRENT_PRESET=3\n", content):
                self.preset_activeid= 3
        except Exception as e: 
            win.showmessage("无法读取", f"错误信息：\n{e}")
            return False

    def savePreSetIndex(self):
        global win
        filepath = self.preset_filePath
        nam= "DYNAREC_CURRENT_PRESET"
        fullpath = WBOXCFG + filepath
        txtval = self.cbPreset.get_active_text()


        if txtval == "":
            shellexec("rm -rf " + fullpath)
            return True


        with open(fullpath, 'w') as file: 
            file.write("export DYNAREC_SETTINGS_SCRIPT=2\n")

            if txtval == "兼容性最好" :
                file.write("export " + nam + "=0" + '\n')
            elif txtval == "默认+兼容" :
                file.write("export " + nam + "=1" + '\n')
            elif txtval == "默认设置" :
                file.write("export " + nam + "=2" + '\n')
            elif txtval == "性能最高" :
                file.write("export " + nam + "=3" + '\n')
            else:
                shellexec("rm -rf " + fullpath)

        return True

    def saveCBItem(self, ctrl, nam, filepath):
        global win
        fullpath = WBOXCFG + filepath
        txtval = ctrl.get_active_text()

        if txtval == "":
            shellexec("echo ''>" + fullpath)
            return

        with open(fullpath, 'w') as file: 
            if txtval == "0":
                file.write("export " + nam + "=0" + '\n')
            elif txtval == "1":
                file.write("export " + nam + "=1" + '\n')
            elif txtval == "2":
                file.write("export " + nam + "=2" + '\n')
            elif txtval == "3":
                file.write("export " + nam + "=3" + '\n')
            elif txtval == "禁用":
                file.write("unset " + nam + '\n')

    def on_btnSave_clicked(self, widget):
        global win
        try: 
            self.savePreSetIndex()
            self.saveCBItem(self.BOX64_DYNAREC_ALIGNED_ATOMICS, "BOX64_DYNAREC_ALIGNED_ATOMICS", "/dynarec/aligned_atomics.conf")
            self.saveCBItem(self.BOX64_DYNAREC_FASTNAN, "BOX64_DYNAREC_FASTNAN", "/dynarec/fastnan.conf")
            self.saveCBItem(self.BOX64_DYNAREC_FASTROUND, "BOX64_DYNAREC_FASTROUND", "/dynarec/fastround.conf")
            self.saveCBItem(self.BOX64_DYNAREC_SAFEFLAGS, "BOX64_DYNAREC_SAFEFLAGS", "/dynarec/safeflags.conf")
            self.saveCBItem(self.BOX64_DYNAREC_STRONGMEM, "BOX64_DYNAREC_STRONGMEM", "/dynarec/strongmem.conf")
            self.saveCBItem(self.BOX64_DYNAREC_WAIT, "BOX64_DYNAREC_WAIT", "/dynarec/wait.conf")
            self.saveCBItem(self.BOX64_DYNAREC_X87DOUBLE, "BOX64_DYNAREC_X87DOUBLE", "/dynarec/x87double.conf")
            self.saveCBItem(self.BOX64_DYNAREC_CALLRET, "BOX64_DYNAREC_CALLRET", "/dynarec/callret.conf")
            self.saveCBItem(self.BOX64_DYNAREC_BIGBLOCK, "BOX64_DYNAREC_BIGBLOCK", "/dynarec/bigblock.conf")
            self.saveCBItem(self.BOX64_IGNOREINT3, "BOX64_IGNOREINT3", "/dynarec/ignoreint3.conf")
            win.showmessage("保存成功", f"保存成功")
        except Exception as e: 
            win.showmessage("无法保存", f"错误信息：\n{e}")
            return False

    def onComboPreSetChanged(self, combo):
        txt_preset = combo.get_active_text()
        # print("txt_preset: " + txt_preset)
        if txt_preset == "兼容性最好" :
            # print ("__name__" + type(self).__name__)
            self.BOX64_DYNAREC_ALIGNED_ATOMICS.set_active(4)
            self.BOX64_DYNAREC_FASTNAN.set_active(0)
            self.BOX64_DYNAREC_FASTROUND.set_active(0)
            self.BOX64_DYNAREC_SAFEFLAGS.set_active(2)
            self.BOX64_DYNAREC_STRONGMEM.set_active(3)
            self.BOX64_DYNAREC_WAIT.set_active(1)
            self.BOX64_DYNAREC_X87DOUBLE.set_active(1)
            self.BOX64_DYNAREC_CALLRET.set_active(0)
            self.BOX64_IGNOREINT3.set_active(4)
        elif txt_preset == "默认+兼容" :
            self.BOX64_DYNAREC_ALIGNED_ATOMICS.set_active(4)
            self.BOX64_DYNAREC_FASTNAN.set_active(0)
            self.BOX64_DYNAREC_FASTROUND.set_active(4)
            self.BOX64_DYNAREC_SAFEFLAGS.set_active(2)
            self.BOX64_DYNAREC_STRONGMEM.set_active(2)
            self.BOX64_DYNAREC_WAIT.set_active(4)
            self.BOX64_DYNAREC_X87DOUBLE.set_active(4)
            self.BOX64_DYNAREC_CALLRET.set_active(0)
            self.BOX64_IGNOREINT3.set_active(4)
        elif txt_preset == "默认设置" :
            self.BOX64_DYNAREC_ALIGNED_ATOMICS.set_active(4)
            self.BOX64_DYNAREC_FASTNAN.set_active(4)
            self.BOX64_DYNAREC_FASTROUND.set_active(4)
            self.BOX64_DYNAREC_SAFEFLAGS.set_active(4)
            self.BOX64_DYNAREC_STRONGMEM.set_active(4)
            self.BOX64_DYNAREC_WAIT.set_active(4)
            self.BOX64_DYNAREC_X87DOUBLE.set_active(4)
            self.BOX64_DYNAREC_CALLRET.set_active(0)
            self.BOX64_IGNOREINT3.set_active(4)
        elif txt_preset == "性能最高" :
            self.BOX64_DYNAREC_ALIGNED_ATOMICS.set_active(4)
            self.BOX64_DYNAREC_FASTNAN.set_active(4)
            self.BOX64_DYNAREC_FASTROUND.set_active(4)
            self.BOX64_DYNAREC_SAFEFLAGS.set_active(0)
            self.BOX64_DYNAREC_STRONGMEM.set_active(4)
            self.BOX64_DYNAREC_WAIT.set_active(4)
            self.BOX64_DYNAREC_X87DOUBLE.set_active(4)
            self.BOX64_DYNAREC_CALLRET.set_active(0)
            self.BOX64_IGNOREINT3.set_active(4)


class Mainform(Gtk.Window):
    def __init__(self):
        global win
        super(Mainform,self).__init__(title=swtitle)
        self.set_default_size(800, 900)
        self.set_icon_from_file("./wbox.png")
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_border_width(3)
        self.set_name("Mainform")
        win = self

        # self.scroll_window = Gtk.ScrolledWindow()
        # self.add(self.scroll_window)

        self.grid = Gtk.Grid()
        # self.scroll_window.add(self.grid)
        self.grid.set_border_width(20)
        self.grid.set_column_spacing(5)
        self.grid.set_row_spacing(10)
        self.add(self.grid)

        txtReadme="" + \
            "软件说明 (欢迎加群交流：740164688)\n" + \
            "=============================================\n" + \
            "根据设备的芯片信息对 wbox 进行参数调节，在一定程度上可以：\n" + \
            "　1). 增强 wbox 对 exe 软件的兼容性\n" + \
            "　2). 加快 wbox 对 exe 软件的运行速度\n" + \
            "\n" + \
            "下面是具体的可调节项："

        rows = 0
        self.lblinfo = Gtk.Label(label="", xalign=0, yalign=0.5)
        self.lblinfo.set_markup(txtReadme)
        self.lblinfo.get_style_context().add_class("lblinfo")
        self.grid.attach(self.lblinfo, 0, rows, 1, 1)
        rows += 1

        self.hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.grid.attach(self.hbox, 0, rows, 1, 1)
        rows += 1


        stack = Gtk.Stack()
        stack.set_transition_type(Gtk.StackTransitionType.SLIDE_UP_DOWN)
        stack.set_transition_duration(1000)
        stack.set_hexpand(True) # 自动铺满可用区域
        stack.set_vexpand(True)

        boxDynarec(stack)
        self.create_page_boxver(stack)
        self.create_page_winever(stack)
        self.create_page_wineESync(stack)
        self.create_page_dxvk(stack)
        self.create_page_virgl(stack)
        self.create_page_debug(stack)
        self.create_page_misc(stack)


        # label = Gtk.Label()
        # label.set_markup("<big>A fancy label</big>")
        # stack.add_titled(label, "label", "A label")

        # image = Gtk.Image.new_from_icon_name("help-about", Gtk.IconSize.MENU)
        # image.set_pixel_size(256)
        # stack.add_titled(image, "image", "Image")


        stacksidebar = Gtk.StackSidebar()
        stacksidebar.set_stack(stack)
        self.hbox.add(stacksidebar)
        self.hbox.add(stack)

        self.loadcss()

    def create_page_boxver(self, stack):
        page = Gtk.Label(label="box版本切换功能待实现，目前固定为：\nBox64 with Dynarec v0.2.7 a159cb5e built on Mar  3 2024 08:31:41", xalign=0, yalign=0)
        stack.add_titled(page, "page_boxver", "Box版本管理")

    def create_page_winever(self, stack):
        page = Gtk.Label(label="wine版本切换功能待实现，目前固定为：\nwine-9.3-vanilla-wow64", xalign=0, yalign=0)
        stack.add_titled(page, "page_winever", "wine版本管理")

    def create_page_wineESync(self, stack):
        page = Gtk.Label(label="待实现", xalign=0, yalign=0)
        stack.add_titled(page, "page_wineESync", "wine ESYNC 设置")

    def create_page_dxvk(self, stack):
        page = Gtk.Label(label="待实现", xalign=0, yalign=0)
        stack.add_titled(page, "page_dxvk", "wine DXVK 设置")

    def create_page_virgl(self, stack):
        page = Gtk.Label(label="待实现", xalign=0, yalign=0)
        stack.add_titled(page, "page_virgl", "mesa VirGL 设置")

    def create_page_debug(self, stack):
        page = Gtk.Label(label="待实现", xalign=0, yalign=0)
        stack.add_titled(page, "page_debug", "调试开关")

    def create_page_misc(self, stack):
        page = Gtk.Label(label="待实现", xalign=0, yalign=0)
        stack.add_titled(page, "page_misc", "杂项和其它兼容性开关")



    def loadcss(self):
        strcss="""
        #Mainform__ {
            background-color: #eef;
        }

        .unused {
            color: #F55;
            background-color: #eef;
            /* 测试 */
        }
        """
        # strpath="/tmp/wbtools.css"
        # fp = open(strpath, 'w')
        # fp.write(strcss)
        # fp.close()

        provider = Gtk.CssProvider()
        provider.load_from_data(strcss)
        # provider.connect("parsing-error", self.show_css_parsing_error)
        # fname = Gio.file_new_for_path('play.css')
        # provider.load_from_file(fname)
        # https://docs.gtk.org/gtk4/method.CssProvider.load_from_file.html
        # provider.load_from_data(strcss), load_from_path, load_from_file, load_from_string
        # provider.load_from_path(strpath)
        # button.set_name("btnFillpwd")
        # self.apply_css(window, provider)
        self.apply_css(self, provider)

    def apply_css(self, widget, provider):
        Gtk.StyleContext.add_provider(widget.get_style_context(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        if isinstance(widget, Gtk.Container):
            widget.forall(self.apply_css, provider)

    def showmessage(self, strtitle, strmessage):
        # Gtk.MessageType.ERROR
        # Gtk.MessageType.INFO  # https://qytz-notes.readthedocs.io/tech/PyGObject-Tutorial/dialogs.html
        dialog = Gtk.MessageDialog(
                transient_for=self,
                # flags=Gtk.DialogFlags.MODAL,
                modal=True,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.CANCEL,
                text=strtitle,
        )
        dialog.format_secondary_text(strmessage)
        btn = dialog.get_widget_for_response(Gtk.ResponseType.CANCEL)
        btn.set_label("好的")
        dialog.run()
        dialog.destroy()






if __name__ == '__main__':
    # 获取脚本所在目录的路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # 更改工作目录为脚本所在目录
    os.chdir(script_dir)

    win = Mainform()
    win.connect("destroy",Gtk.main_quit)
    win.show_all()
    exit(Gtk.main())

