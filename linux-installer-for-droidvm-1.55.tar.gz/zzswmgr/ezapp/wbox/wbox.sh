#!/system/bin/sh

. ${app_home}/z/rt_vars.rc
. ${app_home}/z/gldriver.rc
. ${app_home}/z/config.rc

function exit_if_fail() {
    rlt_code=$1
    fail_msg=$2
    if [ $rlt_code -ne 0 ]; then
      echo -e "错误码: ${rlt_code}\n${fail_msg}" >${LOG_PATH}_setupgl.txt 2>&1
      # read -s -n1 -p "按任意键退出"
      exit $rlt_code
    fi
}

function wbox_wine_show_init_info() {

    . ${app_home}/hwinfo.rc
    device_cpu_name=`cat /proc/cpuinfo|grep Hardware|awk '{print $3}'`
    if [ "${device_cpu_name}" == "" ]; then
    device_cpu_name="检测不到"
    fi

    echo ""
    echo "  语言环境: ${LC_ALL}"
    echo "  日志路径: ${LOG_PATH}"
    echo "   CPU模块: ${device_cpu_name}"
    echo "   GPU模块: ${device_gpu_name}"
    echo "  显卡驱动: ${LINUX_GL_DRIVER_MODE}, 适用于 ${LINUX_GL_DRIVER_CARD}, ${LINUX_GL_DRIVER_INFO}"
    echo "wine程序包: ${WINE_PATH}"
    echo "wine主目录: ${WINEPREFIX}"
    echo "wine分辨率: ${RESOLUTION}"
    # echo "  兼容模式: ${STARTUP_COMPATIBILITY_MODE}"
    echo "X11-Server: ${DISPLAY} (\$DISPLAY)"
    echo ""
}

function wbox_wine_menu_generate() {
    if ! ls $PREFIX/glibc/opt/prefix/start/Registry/2.* &>/dev/null; then
        cp -r $PREFIX/glibc/opt/prefix/start/Registry/2.* $WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start\ Menu/Registry
    fi
    
    rm -rf "$WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start Menu/Install/media foundation (for RE)"
    
    if [ ! -e "$WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start Menu/Install/media foundation (for RE).lnk" ]; then
        cp "$PREFIX/glibc/opt/prefix/start/Install/media foundation (for RE).lnk" "$WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start Menu/Install"
    fi
    
    rm -rf $PREFIX/glibc/opt/prefix/start-default
    
    rm -d $PREFIX/glibc/opt/prefix/start/Install/1.* &>/dev/null
    rm -d $PREFIX/glibc/opt/prefix/start/Install/2.* &>/dev/null
    rm -d $WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start\ Menu/Install/1.* &>/dev/null
    rm -d $WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start\ Menu/Install/2.* &>/dev/null
    
    if ls $PREFIX/glibc/opt/prefix/start/Install/1.* &>/dev/null && ls $WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start\ Menu/Install/1.* &>/dev/null; then
        rm -rf $WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start\ Menu/Install/1.*/* &>/dev/null
        cp $PREFIX/glibc/opt/prefix/start/Install/1.*/* $WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start\ Menu/Install/1.* &>/dev/null
    fi
    
    if ls $PREFIX/glibc/opt/prefix/start/Install/2.* &>/dev/null && ls $WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start\ Menu/Install/2.* &>/dev/null; then
        rm -rf $WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start\ Menu/Install/2.*/* &>/dev/null
        cp $PREFIX/glibc/opt/prefix/start/Install/2.*/* $WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start\ Menu/Install/2.* &>/dev/null
    fi
}

function wbox_wine_apply_fix() {
    if [ ! -f $WINEPREFIX/moboxmeta/services-fix-applied ]; then
        echo "正在安装 services 修复包"
        $GLIBC_BIN/box64 $GLIBC_BIN/wine regedit $PREFIX/glibc/opt/prefix/fix-services.reg &>/dev/null
        sleep 5
        $GLIBC_BIN/box64 $GLIBC_BIN/wineserver -k &>/dev/null
        touch $WINEPREFIX/moboxmeta/services-fix-applied
    fi
    if [ ! -f $WINEPREFIX/moboxmeta/fonts-fix-applied ]; then
        echo "正在安装 fonts 修复包"
        tar -xf $PREFIX/glibc/opt/prefix/fix-fonts.tar.xz -C $WINEPREFIX/drive_c/windows
        touch $WINEPREFIX/moboxmeta/fonts-fix-applied
    fi
    if [ ! -f $WINEPREFIX/moboxmeta/dxdlls-fix-applied ]; then
        echo "正在安装 dlls 修复包"
        7z x $PREFIX/glibc/opt/prefix/directx.7z -o$WINEPREFIX/drive_c -y &>/dev/null
        $GLIBC_BIN/box64 $GLIBC_BIN/wine regedit $PREFIX/glibc/opt/prefix/user.reg &>/dev/null
        sleep 5
        $GLIBC_BIN/box64 $GLIBC_BIN/wineserver -k &>/dev/null
        touch $WINEPREFIX/moboxmeta/dxdlls-fix-applied
    fi
}

function wbox_wine_init_GraphicsDriver() {

    echo "正在安装 适用于 ${LINUX_GL_DRIVER_CARD} 的 ${LINUX_GL_DRIVER_MODE} 显卡驱动"
    echo ""
    echo "如果太久没动，请敲一次回车键!"
    echo ""

    TMP_OPTIONAL1="explorer /desktop=shell,${RESOLUTION} cmd /c"
    TMP_OPTIONAL1=
    TMP_OPTIONAL2="cmd /c"

    echo "正在安装 PhysX 9.10, 7-Zip, Visual C++ Redistributable"
    # $GLIBC_BIN/box64 $GLIBC_BIN/wine explorer /desktop=shell,${RESOLUTION} cmd /c "start Z:\\usr\\glibc\\opt\\apps\\install.bat" >${LOG_PATH}_redist.txt 2>&1
    cd ${WBOXDIR}/usr/glibc/opt/apps
    BOX64_LOG=  box64 $GLIBC_BIN/wine \
    ${WBOXDIR}/usr/glibc/opt/apps/install.bat 2>&1 >${LOG_PATH}_redist.txt
    exit_if_fail $? "安装失败"

    if [ "${LINUX_GL_DRIVER_MODE}" == "MESA.virpipe" ]; then
        echo "正在安装 virgl-mesa-24 (linux侧的 libGL.so，这里是 mesa 官方实现的opengl库，支持llvmpipe、virpipe)"
        # $GLIBC_BIN/box64 $GLIBC_BIN/wine explorer /desktop=shell,${RESOLUTION} cmd /c "cd Z:\\usr\\glibc\\opt\\prefix\\mesa && start Z:\\usr\\glibc\\opt\\prefix\\mesa\\turnip-v5.bat" &>/dev/null
        cd ${WBOXDIR}/usr/glibc/opt/prefix/mesa
        BOX64_LOG=  box64 $GLIBC_BIN/wine \
        ${WBOXDIR}/usr/glibc/opt/prefix/mesa/virgl-mesa-24.bat 2>&1 >${LOG_PATH}_virgl-mesa.txt
        exit_if_fail $? "安装失败"

        sleep 1
        echo "正在安装 wined3d-8.0.2 (wine侧的Direct3D)"
        # $GLIBC_BIN/box64 $GLIBC_BIN/wine explorer /desktop=shell,${RESOLUTION} cmd /c "cd Z:\\usr\\glibc\\opt\\prefix\\d3d && start Z:\\usr\\glibc\\opt\\prefix\\d3d\\wined3d-8.0.2.bat" &>/dev/null
        cd ${WBOXDIR}/usr/glibc/opt/prefix/d3d
        BOX64_LOG=  box64 $GLIBC_BIN/wine \
        ${WBOXDIR}/usr/glibc/opt/prefix/d3d/wined3d-8.0.2.bat 2>&1 >${LOG_PATH}_wined3d.txt
        exit_if_fail $? "安装失败"

    	# 字符串等长替换！
        sed -i "s|/data/data/com.termux/files/usr/tmp/.virgl_test|/data/data/com.zzvm/files/z/usr/tmp/.virgl_test|"   `realpath $WBOXDIR/usr/glibc/lib/libGL.so`

    elif [ "${LINUX_GL_DRIVER_MODE}" == "MESA.turnip" ]; then
        sleep 1
        echo "正在安装 dxvk-async-1.10.3"
        # $GLIBC_BIN/box64 $GLIBC_BIN/wine explorer /desktop=shell,${RESOLUTION} cmd /c "cd Z:\\usr\\glibc\\opt\\prefix\\d3d && start Z:\\usr\\glibc\\opt\\prefix\\d3d\\dxvk-async-1.10.3.bat" &>/dev/null
        cd ${WBOXDIR}/usr/glibc/opt/prefix/d3d
        BOX64_LOG=  box64 $GLIBC_BIN/wine \
        ${WBOXDIR}/usr/glibc/opt/prefix/d3d/dxvk-async-1.10.3.bat 2>&1 >${LOG_PATH}_dxvk-async.txt
        exit_if_fail $? "安装失败"

        sleep 1
        echo "正在安装 turnip-v5 (linux侧的 libGL.so，这里是 骁龙 基于mesa开源项目实现的opengl库，支持turnip，但仅适用于骁龙芯片)"
        # $GLIBC_BIN/box64 $GLIBC_BIN/wine explorer /desktop=shell,${RESOLUTION} cmd /c "cd Z:\\usr\\glibc\\opt\\prefix\\mesa && start Z:\\usr\\glibc\\opt\\prefix\\mesa\\turnip-v5.bat" &>/dev/null
        cd ${WBOXDIR}/usr/glibc/opt/prefix/mesa
        BOX64_LOG=  box64 $GLIBC_BIN/wine \
        ${WBOXDIR}/usr/glibc/opt/prefix/mesa/turnip-v5.bat 2>&1 >${LOG_PATH}_turnip-mesa.txt
        exit_if_fail $? "安装失败"

        sed -i "s|/data/data/com.termux/files|/data/data/com.zzvm/files/z|g" `realpath ${WBOXDIR}/usr/glibc/share/vulkan/icd.d/freedreno_icd.aarch64.json`
        exit_if_fail $? "安装失败"

    else
        echo "不支持这类驱动：${LINUX_GL_DRIVER_MODE}"
        return
    fi

    # fi


    touch     ${WBOXDIR}/glchanged
    chmod 777 ${WBOXDIR}/glchanged
    echo "显卡驱动完成完成，请重新运行wbox"
}

function wbox_wine_init() {
    if [ -e $WINEPREFIX/.update-timestamp ]; then
        :
    else

        wbox_wine_show_init_info


        echo "检测到您首次运行wine"
        echo "正在初始化: C盘 和 windows 程序的运行环境，耗时约1分钟"
        echo ""

        rm -rf   ${PREFIX}/glibc/bin/{wine,wineserver}
        ln -sf   ${PREFIX}/glibc/${WBOX_WINE}/bin/wine       ${PREFIX}/glibc/bin/wine
        ln -sf   ${PREFIX}/glibc/${WBOX_WINE}/bin/wineserver ${PREFIX}/glibc/bin/wineserver

        echo "正在汉化 文件管理器路径"
        if [ ! -f $WBOXDIR/usr/glibc/etc/locale.gen.bak ]; then
            cp -f $WBOXDIR/usr/glibc/etc/locale.gen $WBOXDIR/usr/glibc/etc/locale.gen.bak
        fi
    	echo "zh_CN.utf8"           > $WBOXDIR/usr/glibc/opt/locale.conf
        echo "zh_CN.UTF-8 UTF-8"    > $WBOXDIR/usr/glibc/etc/locale.gen     # 也可以从宿主 etc/locale.gen 复制过来
        locale-gen

        rm -rf $WINEPREFIX
        unset BOX64_DYNAREC_BIGBLOCK
        unset WINEESYNC
        unset WINEESYNC_TERMUX
        unset BOX64_DYNAREC_CALLRET
        if [ -e $WINE_PATH/lib/wine/i386-windows/shell32-bak.dll ] || [ -e $WINE_PATH/lib64/wine/x86_64-windows/shell32-bak.dll ]; then
            mv $WINE_PATH/lib/wine/i386-windows/shell32-bak.dll     $WINE_PATH/lib/wine/i386-windows/shell32.dll &>/dev/null
            mv $WINE_PATH/lib/wine/x86_64-windows/shell32-bak.dll   $WINE_PATH/lib/wine/x86_64-windows/shell32.dll &>/dev/null
            mv $WINE_PATH/lib64/wine/x86_64-windows/shell32-bak.dll $WINE_PATH/lib64/wine/x86_64-windows/shell32.dll &>/dev/null
            mv $WINE_PATH/lib64/wine/i386-windows/shell32-bak.dll   $WINE_PATH/lib64/wine/i386-windows/shell32.dll &>/dev/null
        fi

        WINEDLLOVERRIDES="winegstreamer,mscoree,mshtml=" $GLIBC_BIN/box64 $GLIBC_BIN/wine wineboot --init >${LOG_PATH}_wineboot.txt 2>&1
        if [ ! -e $WINEPREFIX/.update-timestamp ]; then
            echo "初始化失败. 请查看 ${LOG_PATH}_wineboot.txt"
            $GLIBC_BIN/box64 $GLIBC_BIN/wineserver -k &>/dev/null
            echo ""
            cat ${LOG_PATH}_wineboot.txt
            exit
        fi

        echo "正在释放 扩展文件"
        7z x $PREFIX/glibc/opt/prefix/drive_c.7z -o$WINEPREFIX/drive_c -y &>/dev/null
        exit_if_fail $? "扩展文件 释放失败"

        echo "正在释放 DirectX"
        7z x $PREFIX/glibc/opt/prefix/directx.7z -o$WINEPREFIX/drive_c -y &>/dev/null
        exit_if_fail $? "DirectX 释放失败"

        echo "正在释放 开始菜单"
        cp -r $PREFIX/glibc/opt/prefix/start/*    "$WINEPREFIX/drive_c/ProgramData/Microsoft/Windows/Start Menu"
        exit_if_fail $? "开始菜单 释放失败"
        
        echo "正在创建 其它盘符"
        rm -rf                   "$WINEPREFIX/dosdevices/z:"
        ln -sf $PREFIX/../       "$WINEPREFIX/dosdevices/z:"    # 必须
        
        echo "正在复制 字体文件 到 wine 中"
        cp $PREFIX/glibc/opt/prefix/marlett.ttf                        $WINEPREFIX/drive_c/windows/Fonts
        cp -f ${VM_ROOT}/usr/share/fonts/truetype/wqy/wqy-microhei.ttc $WINEPREFIX/drive_c/windows/Fonts

        echo "正在复制 字体文件 到 glibc-rootsf 中"
        mkdir -p ~/.fonts 2>/dev/null
        cp -f ${VM_ROOT}/usr/share/fonts/truetype/wqy/wqy-microhei.ttc ~/.fonts/


        echo "正在导入 注册表文件"
        $GLIBC_BIN/box64 $GLIBC_BIN/wine regedit $PREFIX/glibc/opt/prefix/system.reg &>/dev/null
        $GLIBC_BIN/box64 $GLIBC_BIN/wine regedit $PREFIX/glibc/opt/prefix/system.reg &>/dev/null
        $GLIBC_BIN/box64 $GLIBC_BIN/wine regedit $PREFIX/glibc/opt/prefix/dpi.reg &>/dev/null
        if [ $? -ne 0 ]; then echo "wine dpi 设置失败"; fi
        
        echo "正在释放 mobox专用修复包"
        $GLIBC_BIN/box64 $GLIBC_BIN/wine regedit $PREFIX/glibc/opt/prefix/fix-services.reg &>/dev/null
        tar -xJf $PREFIX/glibc/opt/prefix/fix-fonts.tar.xz -C $WINEPREFIX/drive_c/windows
        # exit_if_fail $? "mobox专用修复包 释放失败"
        
        echo "正在标记 待修复项"
        mkdir -p $WINEPREFIX/moboxmeta
        touch    $WINEPREFIX/moboxmeta/services-fix-applied
        touch    $WINEPREFIX/moboxmeta/fonts-fix-applied
        touch    $WINEPREFIX/moboxmeta/dxdlls-fix-applied
        
        # 原来是在这里安装的驱动
        # wbox_wine_init_GraphicsDriver

        if [ -e $WINE_PATH/lib/wine/i386-unix/libwine.so.1 ] || [ -e $WINE_PATH/lib64/wine/x86_64-unix/libwine.so.1 ]; then
            mv $WINE_PATH/lib/wine/i386-windows/shell32.dll $WINE_PATH/lib/wine/i386-windows/shell32-bak.dll &>/dev/null
            mv $WINE_PATH/lib/wine/x86_64-windows/shell32.dll $WINE_PATH/lib/wine/x86_64-windows/shell32-bak.dll &>/dev/null
            mv $WINE_PATH/lib64/wine/x86_64-windows/shell32.dll $WINE_PATH/lib64/wine/x86_64-windows/shell32-bak.dll &>/dev/null
            mv $WINE_PATH/lib64/wine/i386-windows/shell32.dll $WINE_PATH/lib64/wine/i386-windows/shell32-bak.dll &>/dev/null
        else
            rm -rf $WINE_PATH/lib/wine/i386-unix/shell32.dll.so &>/dev/null
            rm -rf $WINE_PATH/lib/wine/x86_64-unix/shell32.dll.so &>/dev/null
            rm -rf $WINE_PATH/lib64/wine/x86_64-unix/shell32.dll.so &>/dev/null
            rm -rf $WINE_PATH/lib64/wine/i386-unix/shell32.dll.so &>/dev/null
        fi
        $GLIBC_BIN/box64 $GLIBC_BIN/wineserver -k &>/dev/null


        echo "disable">$WINEPREFIX/.update-timestamp

        echo "正在调整 开始菜单"
        wbox_wine_menu_generate

        echo "正在安装 专项补丁"
        wbox_wine_apply_fix

    fi


}


function wbox_wine_link_x11_unix() {
    mkdir -p ${WBOXDIR}/usr/tmp 2>/dev/null
    # ln -sf ../../../vm/ubuntu-arm64/tmp/.X11-unix  /exbin/z/usr/tmp/.X11-unix
    ln -sf ${VM_ROOT}/tmp/.X11-unix ${WBOXDIR}/usr/tmp/.X11-unix
}

function wbox_wine_start_virgl_server() {
    if [ "${LINUX_GL_DRIVER_MODE}" != "MESA.virpipe" ]; then
        rm -rf ${WBOXDIR}/usr/tmp/.virgl_test

        export MESA_LOADER_DRIVER_OVERRIDE=zink
        unset GALLIUM_DRIVER
        unset MESA_GL_VERSION_OVERRIDE

        return
    fi

    # # 实测可用
    # chmod +x $PREFIX/glibc/opt/virgl/libvirgl_test_server.so
    # echo "$PREFIX/glibc/opt/virgl/libvirgl_test_server.so  --socket-path=\"${WBOXDIR}/usr/tmp/.virgl_test\"  &>/dev/null &"
    # $PREFIX/glibc/opt/virgl/libvirgl_test_server.so  --socket-path="${WBOXDIR}/usr/tmp/.virgl_test"  &>/dev/null &

    # 实测可用
    ln -sf ${VM_ROOT}/tmp/.virgl_test ${WBOXDIR}/usr/tmp/.virgl_test

    export GALLIUM_DRIVER=virpipe
    export MESA_GL_VERSION_OVERRIDE=4.0

}


function wbox_wine_start_and_wait() {

    wbox_wine_init

    cd ${WINE_PATH}
    bash
    
    REBOOT=0
    while true; do
        if [ -e $PREFIX/glibc/opt/shutdown ]; then
            rm -rf $PREFIX/glibc/opt/shutdown
            $GLIBC_BIN/box64 $GLIBC_BIN/wineserver -k &>/dev/null
            break
        fi
        if [ -e $PREFIX/glibc/opt/reboot ]; then
            rm -rf $PREFIX/glibc/opt/reboot
            $GLIBC_BIN/box64 $GLIBC_BIN/wineserver -k &>/dev/null
            REBOOT=1
            break
        fi
        # read -t 3 i
        # case "$i" in
        # 1)
        $GLIBC_BIN/box64 $GLIBC_BIN/wineserver -k &>/dev/null
        break
        # ;;
        # esac
    done
    
    if [ "$REBOOT" = "1" ]; then
      echo "正在重启wine(wine内部运行的程序请求重启)"
      exec $0
    fi
}

function startwine() {

    wbox_wine_link_x11_unix

    wbox_wine_start_virgl_server

    echo ""

    if [ "${WINEEXECUTABLE}" == "" ]; then
        echo "未指定要运行的wine程序，正在启动bash环境，您可以通过输入 wbox \"要启动的wine程序\""
        echo "#!/system/bin/sh"                     > ${WBOXDIR}/usr/glibc/bin/wbox
        echo "exec box64 ${WINE_PATH}/bin/wine \$@" >>${WBOXDIR}/usr/glibc/bin/wbox
        chmod a+x                                     ${WBOXDIR}/usr/glibc/bin/wbox
        export BOX64_LOG=5
        which bash
        bash
    elif [ "${WINEEXECUTABLE}" == "init" ]; then
        wbox_wine_init
    elif [ "${WINEEXECUTABLE}" == "info" ]; then
        wbox_wine_show_init_info
    # elif [ "${WINEEXECUTABLE}" == "config" ]; then
        # 实测全部替换完仍不可用，主要是没有: tput, package-manager, wget, ~/.termux/colors.properties, ~/.termux/font.ttf, ${PREFIX}/usr/bin/termux-reload-settings shebang不对
        # sed -i 's|\#!/bin/bash|\#!/data/user/0/com.zzvm/files/z/usr/bin/bash|g'  ${PREFIX}/glibc/opt/scripts/mobox
        # ${PREFIX}/glibc/opt/scripts/mobox
    elif [ "${WINEEXECUTABLE}" == "setupgl" ]; then
        wbox_wine_init_GraphicsDriver
    elif [ "${WINEEXECUTABLE}" == "startvgl" ]; then
        :
    else
        if  [[ $WINEEXECUTABLE == "/data/data/"* ]]; then
            :
        elif  [[ $WINEEXECUTABLE == "/data/user/"* ]]; then
            :
        elif [[ $WINEEXECUTABLE == "/exbin/"* ]]; then
			WINEEXECUTABLE=${WINEEXECUTABLE##*"/exbin/"}
			# WINEEXECUTABLE=${WINEEXECUTABLE%%"]"*}
            WINEEXECUTABLE="${app_home}/${WINEEXECUTABLE}"
        elif  [[ $WINEEXECUTABLE == "/"* ]]; then
            WINEEXECUTABLE="${VM_ROOT}${WINEEXECUTABLE}"
        fi


        if [ $narg -eq 1 ]; then
            box64 $GLIBC_BIN/wine "$WINEEXECUTABLE"
        else
            box64 $GLIBC_BIN/wine $WINEEXECUTABLE
        fi
    fi
}





# wbox_wine_start_and_wait
narg=$#
WINEEXECUTABLE="$@"

# echo "startwine..."
# echo "$narg"
# echo "$WINEEXECUTABLE"
startwine





: '

    # 启动wine命令行窗口，测试可用
    box64 bin/wine start cmd

    # # $GLIBC_BIN/box64 $GLIBC_BIN/wine explorer /desktop=shell,$RESOLUTION $PREFIX/glibc/opt/apps/tfm.exe >$LOG_PATH 2>&1 &
    # # sleep 2
    # # $GLIBC_BIN/box64 $GLIBC_BIN/wine explorer $PREFIX/glibc/opt/apps/f5taskmgr.exe &>/dev/null &
    # # sleep 2
    
    # $GLIBC_BIN/box64 $GLIBC_BIN/wine explorer /desktop=shell,$RESOLUTION >$LOG_PATH 2>&1 &
    # # $GLIBC_BIN/box64 $GLIBC_BIN/wine $PREFIX/glibc/opt/apps/f5taskmgr.exe &
    
    # $GLIBC_BIN/box64 $GLIBC_BIN/wine cmd
    
    # box64 $GLIBC_BIN/wine explorer /desktop=shell /unix

    # box64 $GLIBC_BIN/wine winecfg

    box64 bin/wine /data/user/0/com.zzvm/files/z/3d_demo/CubeMap.exe    # 报错：mobox could not init direct3d => Error initializing native libGL.so.1 => 在开始菜单安装 mesa

    ln -sf /data/data/com.zzvm/files/z/usr/etc/resolv.conf    resolv.conf

    在安卓终端运行wbox:
    cd /data/user/0/com.zzvm/files/z/3d_demo
    /data/user/0/com.zzvm/files/tools/zzswmgr/ezapp/wbox/wbox.sh  ./CubeMap.exe


    调试日志的开关：
		export MESA_NO_ERROR=0
		export WINEDEBUG=+all
		export BOX64_LOG=1
		export BOX64_NOBANNER=0
		export BOX64_SHOWSEGV=1
		export BOX64_DLSYM_ERROR=1
		export BOX64_DYNAREC_MISSING=1

    常见问题：
    ~/  目录不可访问， 导致 error launching installer

'
