#!/usr/bin/python3
import time
import pygame
from   pygame.locals import *


# 初始化Pygame
pygame.init()

# 设置屏幕尺寸
screen_width = 768
screen_height = 1367
screen = pygame.display.set_mode((screen_width, screen_height))

icon = pygame.image.load("/exbin/tools/zzswmgr/appicons/android.jpg").convert_alpha()
pygame.display.set_caption('安卓桌面')
pygame.display.set_icon(icon)


# # 设置文本框字体和大小
# font = pygame.font.Font(None, 32)

# # 设置文本框位置和尺寸
# input_box = pygame.Rect(100, 100, 140, 32)

# # 设置文本输入框的颜色
# color_active = pygame.Color('lightskyblue3')
# color_inactive = pygame.Color('gray15')
# color = color_inactive

# # 设置文本内容
# text = 'testst'




# 游戏主循环
running = True
while running:
    screen.fill((0, 0, 0))

    #等待事件发生
    event = pygame.event.wait()
    print("wait o")
    if event.type == pygame.QUIT:
        exit()
    if event.type == pygame.MOUSEBUTTONDOWN:
        print('鼠标按下',event.pos)
    if event.type == pygame.MOUSEBUTTONUP:
        print('鼠标弹起')
    if event.type == pygame.MOUSEMOTION:
        print('鼠标移动')
        # 键盘事件
    if event.type ==pygame.KEYDOWN:
        # 打印按键的英文字符
        print('键盘按下',chr(event.key))
    if event.type == pygame.KEYUP:
        print('键盘弹起')


    # time.sleep(0.001)
    # screen.fill((0, 0, 0))
    # print("fill")

    # # 获取所有的事件
    # for event in pygame.event.get():

    #     print("event.type: " + pygame.event.event_name(event.type))

    #     # 判断事件类型是否为QUIT
    #     if event.type == QUIT:
    #         running = False

    #     # 判断事件类型是否为KEYDOWN
    #     elif event.type == KEYDOWN:
    #         # 如果按下的是回车键
    #         if event.key == K_RETURN:
    #             # 打印并清空玩家输入的文本
    #             print(text)
    #             text = ''

    #         # 如果按下的是退格键
    #         elif event.key == K_BACKSPACE:
    #             # 删除最后一个字符
    #             text = text[:-1]

    #         else:
    #             # 将玩家输入的字符添加到文本中
    #             text += event.unicode

    # # # 设置文本输入框的外观
    # # pygame.draw.rect(screen, color, input_box, 2)

    # # # 绘制文本
    # # text_surface = font.render(text, True, (255, 255, 255))
    # # screen.blit(text_surface, (input_box.x + 5, input_box.y + 5))

    # # # 更新屏幕
    # # pygame.display.flip()
