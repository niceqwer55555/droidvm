# build_mylinux

#### 介绍
自己编译linux, for qemu-x86_64
release 版带usbip


#### 使用说明

1.  下载发行版的zip压缩包后，解压，然后使用qemu加载虚拟硬盘文件


#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request
