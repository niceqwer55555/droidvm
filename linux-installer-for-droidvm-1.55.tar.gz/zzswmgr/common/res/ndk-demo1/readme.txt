
编译：
chmod 755 ./build.sh
./build.sh
