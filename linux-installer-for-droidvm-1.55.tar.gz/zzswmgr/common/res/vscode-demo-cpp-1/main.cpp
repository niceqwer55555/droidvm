#include <iostream>
using namespace std;
 
int main() 
{
    int i;
    for(i=0;i<10;i++) {
        cout << "Hello, World!\n";
    }
    return 0;
}

// 如何在vscode中调试，请参考：readme.txt
