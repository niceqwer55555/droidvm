#!/system/bin/sh
cd ~/tools/ndkproot
chmod a+x proot2
export PROOT_VERBOSE=100
export PROOT_TMP_DIR=./
export PROOT_LOADER=./pr-loader64
export PROOT_LOADER_32=./pr-loader64
command="./proot2"
tmpdir="/apex"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/acct"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/odm"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/odm_dlkm"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/oem"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/product"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/sys"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/system"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/system_ext"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/vendor"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
tmpdir="/vendor_dlkm"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
command+=" -b /linkerconfig"
command+=" -b /system -b /dev -b /:/host-rootfs"
command+=" -b /dev/urandom:/dev/random"
command+=" -b /dev"
command+=" -b /proc"
command+=" -b /sys"
command+=" -b /data"
command+=" -r ../../vm/ubuntu-arm64 -b /system -b /data -w /usr/bin  ./bash"
$command
