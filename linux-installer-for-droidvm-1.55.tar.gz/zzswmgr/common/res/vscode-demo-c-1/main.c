#include <stdio.h>

int main(int argc, char const *argv[])
{
	int i;
	for(i=0; i< 10; i++) {
		printf("i: %d\n", i);
	}
	return 0;
}

// 如何在vscode中调试，请参考：readme.txt
