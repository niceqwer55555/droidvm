1.51版以后，软件管家运行时
                                        ./scripts 会指向当前发行版的目录，即：
../../distributions/${LINUX_DISTRIBUTION}/scripts
