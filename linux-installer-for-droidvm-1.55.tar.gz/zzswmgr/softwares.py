
from swgroups import SWGROUP
from swgroups import SWPROPS
from swgroups import SWSOURCE
from swgroups import SWARCH
from swgroups import SWOP

class SW(object):
    viewlogInNewWindow = False

    def __init__(self, groups, props, archs, name, version, timecost, info, script, dlsource):
        self.swop = SWOP.none
        self.straction = ""

        self.groups = groups
        self.props = props
        self.archs = archs
        self.name = name
        self.version = version
        self.timecost = timecost
        self.info = info
        self.script = script
        self.dlsource = dlsource

        self.deprecated = False
        self.recommend  = False

SoftWareList = []

# SoftWareList.append(
#     SW( [SWGROUP.input], [SWPROPS.sysdir], [SWARCH.arm64, SWARCH.amd64],
#         "安装本地deb包", 
#         "",
#         "",
#         "安装本地的deb安装包", 
#         "./scripts/debinstall.sh",
#         SWSOURCE.thirdpary,
# ))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "adb", 
        "",
        "",
        "adb是个命令行工具，但有很高的权限，不会用将非常危险！\n"
        "(可读取短信、联系人、电话拨打记录，安装应用。。。请！慎！用！)\n"
        "\n"
        "在虚拟电脑中主要用于\n"
        "1. 解除安卓对单个应用最多可启动进程数量的限制\n"
        "2. 通过usb数据线或者wifi网络控制、调试安卓设备\n"
        "3. 通过图形界面的方式控制安卓设备(scrcpy)\n"
        "\n"
        "安装完成后，adb指令可用，桌面有 解除进程数限制 的启动图标(ADBme)\n"
        "adb指令使用示例:\n"
        "adb pair    192.168.1.13\n"
        "adb connect 192.168.1.13:5555\n"
        "adb shell\n"
        "adb shell ls -al "
        "",
        "./scripts/adb.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "scrcpy", 
        "",
        "",
        "scrcpy是常用的安卓远控软件\n"
        "",
        "./scripts/scrcpy.sh",
        SWSOURCE.aptrepo,
))



SoftWareList.append(
    SW( [SWGROUP.input, SWGROUP.none], [SWPROPS.sysdir], [SWARCH.arm64, SWARCH.amd64],
        "fcitx-table-wbpy", 
        "",
        "",
        "码表 简体中文输入法，包括五笔、拼音\n"
        "输入架构：fcitx4系列\n"
        "词库格式：.mb\n"
        "词库路径： ~/.config/fcitx/table(五笔)\n"
        "词库路径：/usr/share/fcitx/table\n"
        "词库路径：/usr/share/fcitx/pinyin(拼音)\n"
        "词库路径： ~/.config/fcitx/pinyin\n"
        "\n"
        "带拼音词库导入工具，支持无痛添加搜狗.scel拼音词库\n"
        "\n"
        "安装完成后，需要自己调整一下快捷键，步骤为：\n"
        "右下角输入法图标，右击(音量加键)，点配置", 
        "./scripts/fcitx.sh",
        SWSOURCE.aptrepo,
))
SoftWareList[-1].recommend = True

SoftWareList.append(
    SW( [SWGROUP.input], [SWPROPS.sysdir], [SWARCH.arm64, SWARCH.amd64],
        "fcitx5", 
        "",
        "",
        "linux标配简体中文输入法，包括五笔、拼音、仓颉。。。\n"
        "输入架构：fcitx5系列\n"
        "词库格式：.dict\n"
        "词库路径：/usr/share/libime(其中sc是简体拼音的词库)\n"
        "扩展词库：~/.local/share/fcitx5/pinyin/dictionaries(拼音)\n"
        "扩展词库：~/.local/share/fcitx5/table(五笔)\n"
        "\n"
        "带拼音词库导入工具，支持无痛添加搜狗.scel拼音词库\n"
        "\n"
        "此版输入法目前不支持在chrome中输入中文!\n"
        "\n"
        "安装完成后，需要自己调整一下快捷键，步骤为：\n"
        "右下角输入法图标，右击(音量加键)，点配置", 
        "./scripts/fcitx5.sh",
        SWSOURCE.aptrepo,
))
# SoftWareList[-1].deprecated = True



SoftWareList.append(
    SW( [SWGROUP.input], [SWPROPS.sysdir], [SWARCH.arm64, SWARCH.amd64],
        "紫光华宇拼音输入法", 
        "",
        "",
        "紫光华宇 简体中文拼音、五笔输入法, 官方linux信创版\n"
        "输入架构：fcitx4系列\n"
        "词库格式：.uwl\n"
        "词库路径：~/.config/fcitx-huayupy/wordlib\n"
        "\n"
        "此输入法自带专业词库，属性设置中勾选您需要的扩展词库即可！\n"
        "\n"
        "安装完成后，需要自己调整一下快捷键，步骤为：\n"
        "右下角输入法图标，右击(音量加键)，点配置", 
        "./scripts/fcitx-huayuPY.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.input], [SWPROPS.sysdir], [SWARCH.arm64, SWARCH.amd64],
        "屏幕键盘-zzvkb", 
        "",
        "",
        "虚拟电脑中使用python+pygobject写的全键位屏幕键盘\n"
        "只适配了简体中文的键盘布局(共用美式键盘布局)\n"
        "\n"
        "zzvkb 跟软件管家一样，采用 MIT 许可协议开源\n"
        "\n",
        "./scripts/zzvkb.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.input], [SWPROPS.sysdir], [SWARCH.arm64, SWARCH.amd64],
        "屏幕键盘-xvkbd", 
        "",
        "",
        "全键位屏幕键盘\n"
        "实际安装的软件包是 xvkbd, 并默认配置为中文键盘布局\n"
        "\n"
        "几十年的老软件了, 按键的字体大小无法调整！\n"
        "\n",
        "./scripts/xvkbd.sh",
        SWSOURCE.aptrepo,
))
SoftWareList[-1].deprecated = True

# SoftWareList.append(
#     SW( [SWGROUP.input], [], [SWARCH.arm64, SWARCH.amd64],
#         "搜狗拼音输入法", 
#         "",
#         "",
#         "搜狗拼音输入法, 官方linux原版，实测安装成功也无法在proot环境使用",  # err: receive message mq_open failed 函数未实现
#         "输入架构：fcitx4系列\n"
#         "./scripts/fcitx-sougou.sh",
#         SWSOURCE.officialwebsite,
# ))
## 已废弃
# SoftWareList[-1].deprecated = True

SoftWareList.append(
    SW( [SWGROUP.editor], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "geany", 
        "",
        "",
        "geany 是个轻巧的多标签文本编辑器\n"
        "\n"
        "安装完成后，桌面上的软件目录中有启动图标", 
        "./scripts/geany.sh",
        SWSOURCE.aptrepo,
))

# SoftWareList.append(
#     SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "libfm修复包", 
#         "",
#         "",
#         "修复桌面右键菜单没有 新建按钮的问题\n"
#         , 
#         "./scripts/libfm-patch.sh",
#         SWSOURCE.aptrepo,
# ))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "xfce4", 
        "",
        "",
        "xfce4 是一个常用的linux桌面环境,由多个软件组成\n"
        "界面比精简桌面漂亮\n"
        "但启动的进程数量较多，容易被杀进程、出现黑屏的现象\n"
        "所以，在进程杀得比较狠的手机上，[ 不建议 ] 安装\n"
        "\n"
        "安装完成后，桌面上有切换桌面的图标\n"
        , 
        "./scripts/xfce4.sh",
        SWSOURCE.aptrepo,
        # "2025.03.16 发现debian中的xfce4启动要更快一点。\n"
))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "xfce4-美化包-仿osx11", 
        "",
        "",
        "xfce4专用的主题包\n"
        "仓库地址：https://gitee.com/droidvm/xfce4-theme\n"
        "安装时会设置xfce4的：\n"
        "1). 任务栏\n"
        "2). 外观.主题\n"
        "3). 外观.图标\n"
        "4). 窗口.主题\n"
        "5). 桌面.壁纸\n"
        , 
        "./scripts/xfce4-theme-osx11.sh",
        SWSOURCE.thirdpary,
))


# SoftWareList.append(
#     SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "xfce4-美化包-仿win10", 
#         "",
#         "",
#         "xfce4专用的主题包 kali-udercover\n"
#         "安装时会设置xfce4的：\n"
#         "1). 任务栏\n"
#         "2). 外观.主题\n"
#         "3). 外观.图标\n"
#         "4). 窗口.主题\n"
#         "5). 桌面.壁纸\n"
#         "6). 开始菜单\n"
#         "\n"
#         "运行一次kali-undercover是启动主题, 再运行一次是禁用主题\n"
#         , 
#         "./scripts/xfce4-theme-win10.sh",
#         SWSOURCE.thirdpary,
# ))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "xfce4-美化包-仿win11", 
        "",
        "",
        "xfce4专用的主题包\n"
        "仓库地址：https://gitee.com/droidvm/xfce4-theme\n"
        "安装时会设置xfce4的：\n"
        "1). 任务栏\n"
        "2). 外观.主题\n"
        "3). 外观.图标\n"
        "4). 窗口.主题\n"
        "5). 桌面.壁纸\n"
        , 
        "./scripts/xfce4-theme-win11.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "xfce4-美化包-默认主题", 
        "",
        "",
        "xfce4默认主题\n"
        , 
        "./scripts/xfce4-theme-default.sh",
        SWSOURCE.thirdpary,
))

# SoftWareList.append(
#     SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "xfce4-tinysession", 
#         "",
#         "",
#         "以最少的进程数量启动xfce4", 
#         "./scripts/xfce4-tinysession.sh",
#         SWSOURCE.aptrepo,
# ))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "parcellite", 
        "",
        "",
        "剪贴板管理小工具，支持历史剪贴板快速切换\n"
        "\n", 
        "./scripts/parcellite.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "meld", 
        "",
        "",
        "文本文件比较工具(file compare)\n"
        "\n", 
        "./scripts/meld.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "compton", 
        "",
        "",
        "compton 是个x11显示系统的混合层\n"
        "安装后可以实现窗体、菜单透明效果", 
        "./scripts/compton.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "windows10图标样式", 
        "",
        "",
        "windows10 图标样式\n"
        "软件官网：https://github.com/yeyushengfan258/We10X-icon-theme\n"
        "\n\n"
        "安装完成后，请依次点击：\n"
        " 开始使用->显示设置->显示风格->修改图标样式\n"
        "进行启用\n"
        "",
        "./scripts/windows10icon.sh",
        SWSOURCE.github,
))


SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "breeze-cursor-theme", 
        "",
        "",
        "漂亮的鼠标指针样式\n"
        "",
        "./scripts/breeze-cursor-theme.sh",
        SWSOURCE.aptrepo,
))




SoftWareList.append(
    SW( [SWGROUP.internet, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "chrome", 
        "112.0.5615.49",
        "约2分钟",
        "常用的网页浏览器，这版可以播放网页视频", 
        "./scripts/chrome.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "electron-flash-senbrowser", 
        "11.0.5",
        "约4分钟",
        "基于 armhf-electron v11 版的flash浏览器，可以玩4399页游\n"
        "仓库地址：https://github.com/yusenyi123/electron-flash-senbrowser\n"
        "\n"
        "此版本不支持没有32位模式的CPU, 如8Gen3、天玑8300、9300等 armv9 架构的CPU\n"
        "核心插件：libpepflashplayer.so\n"
        "感谢博主：森森top(B站)\n"
        "\n"
        "其它未测试过的flash相关的插件：\n"
        "  1). PepperFlashPlayer, 谷歌家的插件，集成于87版以下的chromium中\n"
        "  　　arm64未流行时flash就停更了\n"
        "  　　所以这个flash插件到目前为止都没有人去搞arm64版本\n"
        "  　　可能要翻旧版的chrome源码自行移植编译\n"
        "  　　这里用的是armhf版本\n"
        "  2). Lightspark, 最近还有在维护\n"
        "  3). Ruffle, 不支持as3\n"
        "\n"
        "安装完成后，桌面上有 FlasyPlayer 的启动图标\n"
        "",
        "./scripts/electron-flash-senbrowser.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.internet, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "firefox-nightly", 
        "",
        "约2分钟",
        "常用的网页浏览器\n"
        "可以启用插件来播放flash视频/游戏，不支持as3\n"
        "比如：\n"
        "  Ruffle、FlashPlayer 2022 (这两个插件都基于 ruffle 模拟器, 不支持as3)\n"
        "\n"
        "不支持4399页游!!!\n"
        "要运行4399页游，请安装 electron-flash-senbrowser\n"
        "", 
        "./scripts/firefox-nightly.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.internet], [SWPROPS.sysdir],  [SWARCH.arm64],
        "chrome-爬虫版", 
        "",
        "约3分钟",
        "常用的网页浏览器，会同时安装 python、pip、playwright(爬虫)\n"
        "这版不能播放网页视频\n"
        "",
        "./scripts/chrome-pr.sh",
        SWSOURCE.pip,
))

SoftWareList.append(
    SW( [SWGROUP.internet], [SWPROPS.sysdir],  [SWARCH.arm64],
        "firefox-爬虫版", 
        "",
        "约3分钟",
        "常用的网页浏览器，会同时安装 python、pip、playwright(爬虫)\n"
        "这版不能使用输入法输入中文", 
        "./scripts/firefox-pr.sh",
        SWSOURCE.pip,
))

SoftWareList.append(
    SW( [SWGROUP.internet], [SWPROPS.sysdir],  [SWARCH.arm64],
        "basilisk", 
        "",
        "约1分钟",
        "网页浏览器，英文，部分机型用不了chrome的情况，可以安装此浏览器代替\n"
        "软件官网：https://www.basilisk-browser.org/",
        "./scripts/basilisk.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.internet, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "QQ-linux版", 
        "3.2.16_250307",
        "",
        "QQ是国内最流行的聊天工具之一\n"
        "软件官网：https://im.qq.com/linuxqq/index.shtml\n"
        "\n"
        "", 

        "./scripts/linuxQQ.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.internet, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "微信-linux版", 
        "4.0.1",
        "约4分钟",
        "微信是国内最流行的聊天工具之一\n"
        "软件官网：https://weixin.qq.com/\n"
        "", 

        "./scripts/linuxWX.sh",
        SWSOURCE.officialwebsite,
))


# SoftWareList.append(
#     SW( [SWGROUP.internet, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
#         "微信", 
#         "2.1.9",
#         "约4分钟",
#         "微信是国内最流行的聊天工具之一\n"
#         "软件官网：https://weixin.qq.com/\n"
#         "因微信没公开发布linux版客户端，所以这里安装的是UOS版的", 

#         "./scripts/linux-wechat-uos.sh",
#         SWSOURCE.thirdpary,
# ))

SoftWareList.append(
    SW( [SWGROUP.internet], [SWPROPS.sysdir],  [SWARCH.arm64],
        "钉钉", 
        "7.6.25",
        "约4分钟",
        "钉钉linux版\n"
        "软件官网：https://www.dingtalk.com/\n"
        "", 

        "./scripts/linuxDingTalk.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.internet], [SWPROPS.sysdir],  [SWARCH.arm64],
        "electron", 
        # "28.1.3",
        "18.2.3",
        "",
        "electron是个基础运行库，有很多近年开发的跨平台软件都是基于electron开发的\n"
        "软件官网：https://www.electronjs.org/zh/\n"
        "镜像站点：https://registry.npmmirror.com/binary.html?path=electron/v28.1.3/\n"
        "", 

        "./scripts/electron.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.internet], [SWPROPS.sysdir],  [SWARCH.arm64],
        "bilibili", 
        "1.1.0-12",
        "",
        "B站客户端，从开源的 tmoe 项目中扣出来的，不是B站官方原版软件!\n"
        "所以如果需要登录，请使用小号登录!\n"
        "github上还有两三个类似的开源项目，都是基于 electron 的修改版客户端"
        "", 

        "./scripts/bilibili.sh",
        SWSOURCE.thirdpary,
))



SoftWareList.append(
    SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "wps-pad", 
        "12.8.2.14776.PAD",
        "约3分钟",
        "国内金山公司出品的办公软件集合\n"
        "软件官网：https://linux.wps.cn/\n"
        "软件来源：https://www.coolapk.com/feed/61898920?shareKey=ZTU2NzI5NTY2YTVmNjdjYTU4MDA~\n"
        "\n"
        "安装包需要自行下载\n"
        "建议进资源群获取，群号: 1030919016, 此群长期禁聊\n"
        "文件名: wps-pad_12.8.2.14776\n"
        "\n"
        "可以登录，可以使用在线模板创建新文档\n"
        "",
        "./scripts/wps-pad.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "wps-365", 
        "",
        "约10分钟",
        "国内金山公司出品的办公软件集合，这里装的是365版本\n"
        "软件官网：https://365.wps.cn/\n"
        "可免费试用30天(可尝试 rm -rf  ~/.config/Kingsoft )\n"
        "\n"
        "安装包需要自行下载 (官网上的安装包变来变去，依赖库难以持续跟进适配)\n"
        "建议进资源群获取，群号: 1030919016, 此群长期禁聊\n"
        "文件名: wps-365_12.8.2.17001.AK.preload.sw._integration_xiezuo4.25.0_arm64.deb\n"
        "\n"
        "可以登录，可以使用在线模板创建新文档\n"
        , 
        "./scripts/wps-365.sh",
        SWSOURCE.officialwebsite,
))


# SoftWareList.append(
#     SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
#         "wps-个人免费版", 
#         "",
#         "约10分钟",
#         "国内金山公司出品的办公软件集合\n"
#         "软件官网：https://linux.wps.cn/\n"
#         "免费个人版本已从wps官网下架(arm64-linux版)，故即将废弃！\n"
#         "(目前仍可使用, 2025.02.11确认)\n"
#         "\n"
#         "可以登录，可以使用在线模板创建新文档\n"
#         "\n"
#         "即将废弃！\n"
#         "即将废弃！\n"
#         "即将废弃！\n"
#         "\n",
#         "./scripts/wps-free.sh",
#         SWSOURCE.thirdpary,
# ))
# # SoftWareList[-1].deprecated = True

# SoftWareList.append(
#     SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
#         "wps-pro", 
#         "",
#         "约10分钟",
#         "国内金山公司出品的办公软件集合，这里装的是专业版\n"
#         "此版本最快，可免费试用30天(可尝试 rm -rf  ~/.config/Kingsoft )\n"
#         "\n"
#         "安装包需要自行下载!\n"
#         "\n"
#         "此版目前不能：\n"
#         "1). 不能登录账号\n"
#         "2). 不能新建文件，只能在桌面上或文件夹内使用右键菜单新建文件\n"
#         "\n"
#         "原因是 libkccservice.so 中的 CryptoPP 会触发 SIGSEGV ，暂未找到解法，等大佬解决\n"
#         # "已废弃！(安装包已无法下载)\n"
#         # "已废弃！(安装包已无法下载)\n"
#         # "已废弃！(安装包已无法下载)\n"
#         , 
#         "./scripts/wps-pro.sh",
#         SWSOURCE.thirdpary,
# ))
# # SoftWareList[-1].deprecated = True

# SoftWareList.append(
#     SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
#         "wps-个人免费版-修复包", 
#         "",
#         "约1分钟",
#         "wps修复\n"
#         "包括字体安装，以及处理免费版中字体加粗显示异常的问题", 
#         "./scripts/wps-patch.sh",
#         SWSOURCE.thirdpary,
# ))

SoftWareList.append(
    SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "腾讯文档", 
        "",
        "约2分钟",
        "腾讯公司出品的办公软件集合\n"
        "软件官网：https://docs.qq.com/home/download\n"
        "\n"
        "安装完成后，桌面有启动图标", 
        "./scripts/TencentDocs.sh",
        SWSOURCE.officialwebsite,
))
# SoftWareList[-1].recommend = True

SoftWareList.append(
    SW( [SWGROUP.office], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "希沃白板5", 
        "5.2.2.4.12789",
        "约1分钟",
        "希沃白板uos版", 
        "./scripts/EasiNote.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.office], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "libreoffice", 
        "",
        "约8分钟",
        "办公软件集合，支持中文界面，但是对msoffice的格式支持得不太好", 
        "./scripts/libreoffice.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.office], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "filezilla", 
        "",
        "约8分钟",
        "非常流行的 ftp 客户端软件", 
        "./scripts/filezilla.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "scribus", 
        "",
        "约1分钟",
        "pdf编辑器\n"
        "", 
        "./scripts/scribus.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "xournal", 
        "",
        "约1分钟",
        "pdf编辑器--未测试\n"
        "", 
        "./scripts/xournal.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "okular", 
        "",
        "约1分钟",
        "pdf阅读器\n"
        "", 
        "./scripts/okular.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.office, SWGROUP.none], [SWPROPS.sysdir],  [SWARCH.arm64],
        "cajviewer",  # -uos版
        "",
        "约2分钟",
        "中国知网出的学术文献阅读工具\n"
        "官方网站：https://cajviewer.cnki.net/caj9.0/downloadMore.html (鲲鹏|飞腾)\n"
        "支持caj、pdf文件阅读、编辑\n"
        "", 
        "./scripts/cajviewer.sh",
        SWSOURCE.officialwebsite,
))


SoftWareList.append(
    SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "mpg123", 
        "",
        "",
        "命令行下的mp3播放器\n"
        "\n"
        "安装完成后，桌面上有 声音测试 的启动图标", 
        "./scripts/mpg123.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "termux-pulseaudio", 
        "",
        "",
        "termux 中使用的 pulseaudio，带 aaudio-sink\n"
        "用于华为 MatePad 平板等没有声音的设备\n"
        "其它设备，不用安装此音频库"
        "\n"
        "安装完成后，安装完成后需要重启", 
        "./scripts/termux-pulseaudio.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "smplayer", 
        "",
        "",
        "linux中常用的视频播放器\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/smplayer.sh",
        SWSOURCE.aptrepo,
))

# SoftWareList.append(
#     SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "mpv", 
#         "",
#         "",
#         "linux中常用的视频播放器\n"
#         "\n"
#         "安装完成后，桌面上有启动图标", 
#         "./scripts/mpv.sh",
#         SWSOURCE.aptrepo,
# ))

SoftWareList.append(
    SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "qq音乐", 
        "",
        "",
        "qq音乐。来自信创技术联盟\n"
        "软件来源：https://www.cnxclm.com/read-4251-1.html\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/qqmusic.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "落雪音乐", 
        "2.11.0",
        "",
        "落雪音乐\n"
        "软件仓库：https://github.com/lyswhut/lx-music-desktop\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/lxmusic.sh",
        SWSOURCE.github,
))



SoftWareList.append(
    SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "YesPlayMusic", 
        "",
        "",
        "开源的非官方网易音乐\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/yesplaymusic.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "parole播放器", 
        "",
        "",
        "音乐、视频播放器\n"
        "\n"
        "安装完成后，桌面上的软件目录里面有启动图标", 
        "./scripts/parole.sh",
        SWSOURCE.aptrepo,
))


# mplayer/gmplayer 无法正常运行
SoftWareList.append(
    SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "vlc播放器", 
        "",
        "",
        "音乐、视频播放器\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/vlc.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.media], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "LDDC", 
        "0.9.1",
        "",
        "歌词下载工具, 支持多平台搜索, 带解密\n"
        "仓库地址：https://github.com/chenmozhijin/LDDC\n"
        "\n"
        "注意：\n"
        "=================\n"
        "需要这么操作才能正常启动:\n"
        "在开始->控制台->proot-sysipc->开启\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/LDDC.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.compress], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "zip_unzip", 
        "",
        "",
        "命令行下的zip压缩、解压缩工具\n"
        "\n"
        "安装完成会在右键菜单中有压缩选项",
        "./scripts/zip_unzip.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.compress], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "360zip", 
        "",
        "",
        "压缩工具，支持非常多的压缩格式\n"
        "安装完成后，桌面有启动图标", 
        "./scripts/360zip.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.compress], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "EGzip", 
        "",
        "",
        "压缩工具，支持非常多的压缩格式，强烈推荐！！\n"
        "安装的是 EnGrampa 归档管理器\n"
        "安装完成后，桌面有启动图标，并且自动集成到右键菜单", 
        "./scripts/EGzip.sh",
        SWSOURCE.aptrepo,
))
SoftWareList[-1].recommend = True

# SoftWareList.append(
#     SW( [SWGROUP.compress], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "LXzip", 
#         "",
#         "",
#         "压缩工具，支持非常多的压缩格式\n"
#         "安装的是 lxqt-archiver", 
#         "./scripts/LXzip.sh",
#         SWSOURCE.aptrepo,
# ))


SoftWareList.append(
    SW( [SWGROUP.compress], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "PeaZip", 
        "",
        "",
        "压缩工具，支持非常多的压缩格式", 
        "./scripts/peazip.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.compress], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "ark", 
        "",
        "",
        "压缩工具，支持非常多的压缩格式""\n"
        "23.10以上的rootfs，请使用这个工具解压", 
        "./scripts/ark.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.compress], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "xarchiver", 
        "",
        "",
        "压缩工具，支持非常多的压缩格式", 
        "./scripts/xarchiver.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.download], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "motrix", 
        "",
        "",
        "下载工具，界面漂亮", 
        "./scripts/motrix.sh",
        SWSOURCE.github,
))
SoftWareList[-1].viewlogInNewWindow=True

SoftWareList.append(
    SW( [SWGROUP.download], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "uget", 
        "",
        "",
        "下载工具，界面比较老旧", 
        "./scripts/uget.sh",
        SWSOURCE.aptrepo,
))

# SoftWareList.append(
#     SW( [SWGROUP.vir, SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64],
#         "termux", 
#         "",
#         "约2分钟",
#         "借助 包名抢占.apk, 无痛使用termux仓库中的软件\n"
#         "仓库地址：https://github.com/termux/termux-packages/releases\n"
#         "\n"
#         "如果旧包清不掉，请使用adb清除，指令如下：\n"
#         "adb uninstall com.termux\n"
#         "\n"
#         "不支持 termux-api等与app极度相关的扩展功能\n"
#         "", 
#         "./scripts/termux.sh",
#         SWSOURCE.github,
# ))

# SoftWareList.append(
#     SW( [SWGROUP.vir, SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64],
#         "mobox", 
#         "",
#         "约2分钟",
#         "mobox可在arm64架构的安卓环境中运行常规的exe软件, 但并非所有软件都能运行!\n"
#         "仓库地址：https://github.com/olegos2/mobox\n"
#         "", 
#         "./scripts/mobox.sh",
#         SWSOURCE.github,
# ))

SoftWareList.append(
    SW( [SWGROUP.vir, SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64],
        "wbox", 
        "",
        "约6分钟",
        "支持在安卓上运行windows软件的转换层\n"
        "仓库地址：https://github.com/olegos2/mobox\n"
        "\n"
        "基于mobox修改而来\n"
        "集成了 termux+glibc+box64+wine，是个四合一的运行库\n"
        "支持 tunrip、virgl 两种硬件加速方式\n"
        "支持双击运行exe程序\n"
        "支持中文路径\n"
        "支持有空格的软件路径\n"
        "\n\n"
        "显卡驱动安装：打开桌面上的 显卡驱动 文件夹，骁龙系列可安装turnip，否则请安装virgl\n"
        "字体大小调节：双击桌面上的 wb配置 -> 显示 -> 将dpi调到144或更高即可\n"
        "\n\n"
        "常见错误：error launching installer\n"
        "若碰到请将exe文件放到Z盘后再双击运行\n"
        "\n\n"
        "安装成功后，wbox 指令可用，桌面上也有启动图标\n"
        "C盘和Z盘，会出现在文件管理器的左边栏", 
        "./scripts/wbox.sh",
        SWSOURCE.github,
))
SoftWareList[-1].deprecated = True


SoftWareList.append(
    SW( [SWGROUP.vir, SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64],
        "box", 
        "",
        "",
        "在arm架构的linux上运行 x86/x64架构的linux软件\n"
        "\n\n"
        "安装成功后，box86、box64 指令可用", 
        "./scripts/box.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.vir, SWGROUP.game, SWGROUP.swcompile], [SWPROPS.sysdir],  [SWARCH.arm64],
        "compile-box", 
        "",
        "约20分钟",
        "在arm架构的linux上运行 x86/x64架构的linux软件\n以编译源码的方式安装", 
        "./scripts/compile-box.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.vir, SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "wine-x32-x64", 
        "8.9",
        "约6分钟",
        "在linux中运行windows软件的环境"
        "\n\n"
        "安装成功后 wine32、wine64、winexe 指令可用\n"
        "桌面也会有wine的启动图标\n",
        "./scripts/wine-8.9.sh",
        SWSOURCE.thirdpary,
))

# SoftWareList.append(
#     SW( [SWGROUP.vir], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "wine-x32-x64", 
#         "9.1",
#         "约6分钟",
#         "在linux中运行windows软件的环境", 
#         "./scripts/wine-9.1.sh",
#         SWSOURCE.thirdpary,
# ))

# SoftWareList.append(
#     SW( [SWGROUP.vir], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "playonlinux", 
#         "",
#         "约6分钟",
#         "在linux中运行windows软件的环境, playonlinux 是对wine的二次开发，带有图形管理界面", 
#         "./scripts/playonlinux.sh",
#         SWSOURCE.thirdpary,
# ))

SoftWareList.append(
    SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "glmark2", 
        "",
        "",
         "3d测分工具\n运行结束时会给出分数，得分越高表示当前系统的3D性能越好，\n"
        +"由于虚拟电脑目前使用的opengl是mesa通过virgl把绘图请求转发到安卓环境执行的，\n"
        +"故性能相当相当低，只能发挥出原生环境约1/10的性能，且延迟变大", 
        "./scripts/glmark2.sh",
        SWSOURCE.aptrepo,
))

# SoftWareList.append(
#     SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64],
#         "mesa.turnip(内测-不稳定)", 
#         "25.0",
#         "约4分钟(下载慢)",
#         "mesa是GPU 驱动程序(显卡驱动)，完全开源。\n"
#         "软件官网：https://docs.mesa3d.org/drivers/panfrost.html\n"
#         "三方仓库：https://github.com/MastaG/mesa-turnip-ppa\n"
#         "PPA_国外：https://launchpad.net/~mastag/+archive/ubuntu/mesa-turnip-kgsl\n"
#         "PPA_大陆：https://launchpad.proxy.ustclug.org/mastag/mesa-turnip-kgsl/ubuntu/pool/main/\n"
#         "\n"
#         "此版为第三方针对 Adreno 6xx/7xx 系列 GPU 的移植版\n"
#         "可用于proot环境，但实测并不稳定\n"
#         "\n"
#         "慎装！\n"
#         "慎装！\n"
#         "慎装！\n"
#         "\n"
#         "安装完成后，可通过 glmark2 指令进行验证及测试\n"
#         "\n",
#         "./scripts/mesa.turnip.sh",
#         SWSOURCE.aptrepo,
# ))
# SoftWareList[-1].viewlogInNewWindow=True

SoftWareList.append(
    SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64],
        "mesa.freedreno(内测)", 
        "24.3.0",
        "约4分钟(下载慢)",
        "mesa是GPU 驱动程序(显卡驱动)，完全开源。\n"
        "仓库地址：https://github.com/droidvm/mesa-freedreno-patchs\n"
        "\n"
        "此版为第三方针对 Adreno 6xx/7xx 系列 GPU 的移植版\n"
        "可用于proot环境，实测不多，稳定性待反馈\n"
        "\n"
        "安装完成后，可通过 glmark2 指令进行验证及测试\n"
        "\n",
        "./scripts/mesa.freedreno.sh",
        SWSOURCE.github,
))

# SoftWareList.append(
#     SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "steam-linux", 
#         "",
#         "",
#          "steam游戏商店\n  安装快结束时，会报错说找不到libc.so.6，\n"
#          "这是因为steam启动脚本不会自动以box86运行导致的，\n"
#          "但我们的安装脚本会处理这个问题，故此错误无需理会,\n"
#          "\n"
#          "请先安装box，以及开启proot-sysvipc功能\n"
#          "步骤：开始->控制台->proot-sysvipc功能\n"
#          "\n\n"
#          "此安装器安装的是linux-x86版的steam, 目前暂时无法运行\n"
#          "建议安装PlayOnLinux，并在PlayOnlinux中安装steam",
#         "./scripts/steam.sh",
#         SWSOURCE.thirdpary,
# ))

# SoftWareList.append(
#     SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "steam-win32", 
#         "",
#         "",
#          "steam游戏商店\n  这是windows版steam，用wine运行的，所以必须先安装box和wine!\n"
#          "请注意：\n"
#          "通过wine运行windows版steam相当吃运存，启动非常慢",
#         "./scripts/steam-win32.sh",
#         SWSOURCE.thirdpary,
# ))

# SoftWareList.append(
#     SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "steam-win64", 
#         "",
#         "",
#          "steam游戏商店\n  这是windows版steam，用wine运行的，所以必须先安装box和wine!\n"
#          "请注意：\n"
#          "通过wine运行windows版steam相当吃运存，启动非常慢",
#         "./scripts/steam-win64.sh",
#         SWSOURCE.thirdpary,
# ))

SoftWareList.append(
    SW( [SWGROUP.game, SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "jdk21", 
        "",
        "约8分钟",
        "jdk 包括java运行时和java sdk，用于开发、运行 java 程序\n"
        "\n"
        "大陆下载特别慢, 建议使用openjdk\n"
        "或进资源群获取，群号: 1030919016, 此群长期禁聊\n"
        "文件名: jdk-21_linux-aarch64_bin.tar.gz\n"
        "\n"
        "请注意：如果同时还安装了openjdk，则环境变量中java优先指向openjdk", 
        "./scripts/jdk21.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "HMCL", 
        "",
        "",
         "我的世界安装启动器\n"
        "\n\n"
        "安装成功后桌面上有两个启动图标\n"
        "一个带virgl-3D加速(不一定能顺利启动)\n"
        "一个不带3D加速\n"
        "\n",
        "./scripts/HMCL.sh",
        SWSOURCE.thirdpary,
))



SoftWareList.append(
    SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "aisleriot", 
        "",
        "",
         "LINUX 下的纸牌游戏，无中文界面。\n"
        "体积\n"
        "安装成功后，桌面上的软件目录有启动图标\n"
        "",
        "./scripts/aisleriot.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "pysolfc", 
        "",
        "",
         "LINUX 下的纸牌游戏，内带上千种纸牌玩法，无中文界面。\n"
        "从源码编译安装\n"
        "安装成功后，桌面上有启动图标\n"
        "",
        "./scripts/pysolfc.sh",
        SWSOURCE.thirdpary,
))




SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "gcc", 
        "",
        "",
        "gcc gdb make 三件套，不包含g++！\n"
        "建议安装vscode做为代码编辑器\n"
        "如何使用vscode调试C  项目，可以参考 ./scripts/res/vscode-demo-c-1\n"
        "如何使用vscode调试C++项目，可以参考 ./scripts/res/vscode-demo-cpp-1\n",
        "./scripts/gcc.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "vscode", 
        "",
        "",
        "非常有名的代码编辑器\n检测到中文环境会询问是否安装软件的中文包\n"
        "如何使用vscode调试C  项目，可以参考 ./scripts/res/vscode-demo-c-1\n"
        "如何使用vscode调试C++项目，可以参考 ./scripts/res/vscode-demo-cpp-1\n"
        "\n"
        " vscode使用源码目录中的.vscode文件夹来描述项目\n"
        " 打开其所在的目录即打开了 工程/项目\n"
        " 也可以在终端下进到源码目录，然后敲：code .\n"
        "\n"
        "2025.02.24 发现：\n"
        "=================\n"
        "vscode for arm64 中的 \"c/c++\" 插件，不能正常启动gdb了\n"
        "要改用  kylin 版的那个 c/c++ 插件才能顺利启动 gdb\n"
        "\n"
        "安装完成后，桌面有启动图标", 
        "./scripts/vscode.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "code-server", 
        "",
        "",
        "vscode的网页版，可以在其它设备上通过浏览器使用\n"
        "默认端口：5560"
        "\n"
        "安装完成后，桌面有启动图标", 
        "./scripts/code-server.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "IntelliJ-IDEA", 
        "",
        "",
        "idea是个非常有名的java代码编辑器\n"
        "这里安装的是免费的社区版(arm64架构)\n"
        "\n"
        "安装到能成功编译安卓项目，则存储空间占用约：7GB\n"
        "\n"
        "可以在其插件页面安装 \"Android\" 插件，以支持安卓app的开发\n"
        "可以在其插件页面安装 \"Chinese Simple\" 插件，以汉化界面\n"
        "\n"
        "第一次创建android项目时，idea的安卓插件可能要花10分钟来初始化项目\n"
        "包括创建索引，下载安装android-sdk、gradle、以及一堆的依赖库。。。\n"
        "当然，经过第一次的痛以后，就顺了\n"
        "\n"
        "如果项目编译报错说类重复，请在 build.gradle、或  build.gradle.kts 中添加：\n"
        "   implementation(platform(\"org.jetbrains.kotlin:kotlin-bom:1.8.0\"))\n"
        "\n"
        "如果需要使用adb来安装编译好的包，\n"
        "请在软件管家中安装adb并连接上设备\n，并执行：\n"
        " cp  -f  /usr/bin/adb  ./Android/Sdk/platform-tools/adb\n"
        "\n"
        "说明：\n"
        "在虚拟电脑中跑这种大型ide，极易被杀后台。\n"
        "最好在电脑上玩，或者有两台安卓设备的情况下使用"
        "", 
        "./scripts/idea.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "zig", 
        "0.11",
        "",
        "zig语言编译工具集，zig是基于llvm开发的跨平台编程语言，\n相对其它跨平台的编译工具来说，zig体积非常小\n目标是替代C, https://ziglang.org/learn/getting-started/", 
        "./scripts/zig.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "dotnet", 
        "6.0",
        "",
        "对，微软开发的用于linux平台的 C#/.NET !\n"
        "2023年了，dotnet很好用了的\n\n"
        "示例：\n"
        "mkdir   ~/mycode\n"
        "cd   ~/mycode\n"
        "dotnet   new   console # 创建一个最简单的项目源码\n"
        "dotnet   run           # 编译并运行\n"
        "\n"
        "发布应用：\n"
        "cd ~/mycode\n"
        "dotnet publish -c release\n"
        "或参考：https://learn.microsoft.com/zh-cn/dotnet/core/deploying/deploy-with-cli\n",
        "./scripts/dotnet.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "android-sdk", 
        "",
        "约1分钟",
        "android-sdk 用于开发安卓dex命令行程序/安卓APK应用\n"
        "依赖：openjdk-8-jdk 或以上\n"
        "安装完成后，以下指令用：\n"
        "adb\n"
        "aidl\n"
        "sdkmanager\n"
        "\n"
        "如何使用请参考示例： ./scripts/res/apk-demo1\n",
        "./scripts/android-sdk.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "android-ndk", 
        "r26b",
        "约10分钟",
        "android ndk 用于开发安卓原生动态库/安卓原生控制台程序\n"
        "但官方只发布了amd64架构的版本\n"
        "这里安装的是github上的aarch64版本\n"
        "\n"
        "仓库地址：https://github.com/lzhiyong/termux-ndk"
        "\n"
        "查看可用指令：ls -al /usr/bin/ndk*\n"
        "如何使用请参考示例： ./scripts/res/ndk-demo1\n",
        "./scripts/android-ndk.sh",
        SWSOURCE.thirdpary,
))

# SoftWareList.append(
#     SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "android-ndk", 
#         "r25c",
#         "约10分钟",
#         "android ndk 用于开发安卓原生动态库/安卓原生控制台程序, \n"
#         +"但官方只发布了amd64架构的版本,\n"
#         +"在 proot arm64 linux 环境中，可以通过box来启动编译器(效率还能接受)\n"
#         +"如何使用请参考示例： ./scripts/res/ndk-demo1\n"
#         +"\n"
#         +"必须启用：\n"
#         +"开始菜单->控制台->proot管理->proot-userland(支持ndk)\n"
#         +"才能在droidvm中通过box64调用ndk-clang", 
#         "./scripts/android-ndk.sh",
#         SWSOURCE.thirdpary,
# ))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "openjdk", 
        "",
        "约3分钟",
        "openjdk 包括java运行时和java sdk，用于开发、运行 java 程序", 
        "./scripts/openjdk.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "godot", 
        "4.2.1",
        "约1分钟",
        "godot\n"
        "仓库地址：https://github.com/godotengine/godot\n"
        "\n"
        "说明:\n"
        "1). 依赖 vulkan 接口，故只适用于骁龙设备\n"
        "2). 装完 godot 后, 要装骁龙设备的GPU驱动: mesa.freedreno, 否则创建项目时闪退\n"
        "",
        "./scripts/godot.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "pycharm", 
        "",
        "",
        "pycharm 是个流行的 python 代码编写工具，集成编辑器、打包器等于一体\n"
        "官方网站：https://www.jetbrains.com.cn/pycharm/download/download-thanks.html?platform=linuxARM64\n"
        "\n"
        "安装包需要自行下载 (linux-arm64 版) \n"
        "\n"
        "安装完成后，桌面有启动图标", 
        "./scripts/pycharm.sh",
        SWSOURCE.officialwebsite,
))



SoftWareList.append(
    SW( [SWGROUP.sys], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "systemctl", 
        "",
        "",
        "systemd 脚本模拟版\n"
        "\n"
        "安装成功后 systemctl 指令可用\n"
        "使用示例：\n"
        "sudo systemctl start      ssh # 启动服务\n"
        "sudo systemctl stop       ssh # 停止服务\n"
        "sudo systemctl enable     ssh # 添加为自启动项\n"
        "sudo systemctl disable    ssh # 取消自启动\n"
        "sudo systemctl is-enabled ssh # 查询虚拟系统启动时，是否自动运行指定的服务\n"
        "\n"
        ".service 文件保存目录：\n"
        "==========================\n"
        "已安装的服务：/lib/systemd/system\n"
        "自启动的服务：/etc/systemd/system/multi-user.target.wants\n"
        "",
        "./scripts/systemctl.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.sys], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "udocker", 
        "",
        "",
        "用Python写的userspace docker，仅能运行部分docker镜像\n"
        "软件官网：https://github.com/indigo-dc/udocker\n"
        "\n\n"
        "安装成功后 udocker 指令可用\n"
        "使用示例：\n"
        "udocker --help\n"
        "udocker install\n"
        "udocker run busybox\n"
        "",
        "./scripts/udocker.sh",
        SWSOURCE.github,
))


SoftWareList.append(
    SW( [SWGROUP.sys, SWGROUP.rdp], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "xpra", 
        "",
        "",
        "通过网页控制虚拟电脑\n"
        "\n"
        "安装成功后，依次点击 开始菜单->远程控制->通过WbnXpra 启动"
        "",
        "./scripts/xpra.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.sys, SWGROUP.rdp], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        # kasmvnc 效率可能更高, 但还未适配
        "webvnc", 
        "1.14.1",
        "",
        "图形界面远程控制工具，会同时安装 tigerVNC 和 novnc(网页控制端)\n"
        "安装并启动webvnc后\n"
        "可以在电脑端通过 VNC客户端，或者 网页浏览器 远程控制虚拟电脑\n"
        "\n"
        "默认端口请查看启动时的弹窗提示\n"
        "\n"
        "启动步骤：\n"
        "　开始使用->远程控制->通过webvnc->启动VNC服务端\n"
        "\n"
        "设置密码：\n"
        "　开始使用->远程控制->通过webvnc->修改密码\n"
        "\n"
        "调分辨率：\n"
        "　开始使用->远程控制->通过webvnc->调整VNC分辨率\n"
        "",
        "./scripts/webvnc.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.sys, SWGROUP.rdp], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "remmina", 
        "",
        "",
        "图形界面远程控制工具\n"
        "支持的远程连接协议包括：vnc, rdp, ssh\n"
        "可以在虚拟电脑中连接到其它的windows桌面\n"
        "\n"
        "要连接windows\n"
        "windows上要安装vnc协议的 TightVNC\n"
        "下载地址：https://www.tightvnc.com/download.php\n"
        "\n\n"
        "安装成功后，桌面上的软件目录中有启动图标，双击可以启动(音量减键)"
        "",
        "./scripts/remmina.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.sys, SWGROUP.rdp], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "rustdesk", 
        "",
        "",
        "图形界面远程控制工具\n"
        "可以在虚拟电脑中连接到其它的windows桌面\n"
        "\n"
        "要连接windows\n"
        "windows上要安装rustdesk\n"
        "下载地址：https://github.com/rustdesk/rustdesk\n"
        "\n\n"
        "安装成功后，桌面上的软件目录中有启动图标，双击可以启动(音量减键)"
        "",
        "./scripts/rustdesk.sh",
        SWSOURCE.thirdpary,
))


# SoftWareList.append(
#     SW( [SWGROUP.sys, SWGROUP.vir, SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "termux", 
#         "",
#         "",
#         "以proot加载termux-rootfs的方式运行termux\n"
#         "虚拟电脑中引入的termux不是完整版本，主要是供开发人员和游戏玩家使用!\n"
#         "\n"
#         "对于游戏玩家来说，可以在termux里面安装mobox:\n"
#         "  ~/mobox-installer/setup.sh\n"
#         "\n"
#         "对于开发人员来说，运行于termux中的软件:\n"
#         "  可以调用 termux 移植的三方库(可在termux中使用pkg指令从镜像仓库下载)\n"
#         "  可以调用安卓原生的系统库(在安卓系统的库目录中)\n\n"
#         "  pkg install clang 安装gcc后，可用于开发需要直接调用宿主GPU的带界面软件\n"
#         "\n"
#         "安装完成后，termux指令可用，桌面也有启动图标", 
#         "./scripts/termux.sh",
#         SWSOURCE.thirdpary,
# ))

SoftWareList.append(
    SW( [SWGROUP.sys], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "星火应用商店", 
        "4.7.0-1",
        "约2分钟",
        "为deepin等全功能电脑版linux系统设计的软件包管理工具\n"
        "软件官网：https://gitee.com/spark-store-project/spark-store\n"
        "\n"
        "提示，星火应用商店里面收录的软件，不一定都能在虚拟电脑中运行(虚拟电脑是proot环境)\n"
        "\n"
        "\n"
        "安装完成后，桌面有启动图标", 
        "./scripts/spark-store.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.sys], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "tmoe", 
        "",
        "",
        "软件管理工具，运行于控制台，使用TAB键、方向键、回车键进行操作\n收录了很多软件", 
        "./scripts/tmoe.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.sys], [],  [SWARCH.arm64, SWARCH.amd64],
        "build_mylinux", 
        "",
        "",
        " 《半小时，无痛体验一次自己编译并运行linux-6.6主线内核》\n"
        " ---- x86_64 架构 qemu-virt机型\n"
        "\n"
        " 因内核设计为启动完成后必须降权跳到用户空间运行第一个进程\n"
        " 所以除了编译内核源码的脚本外，还包含了创建rootfs的脚本\n"
        " 以便实现内核的全流程启动\n"
        " (不包括内核打补丁[kernel-patch]，也不包括启动文件出处的查验[secure-boot])"
        "\n\n"
        "安装完成后，在桌面上会有启动图标", 
        "./scripts/build_mylinux.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.sys, SWGROUP.bootdisk], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "qemu-linux-amd64", 
        "",
        "",
        "可用qemu启动的超小型、不带图形界面的linux系统\n"
        "结合安卓端的虚拟电脑app，可以在此系统中通过 usbip 操作安卓端的USB设备!\n"
        "\n"
        "此镜像的目标机型为 amd64(x86_64) 架构的 qemu-virt 机型\n"
        "内核使用自行编译的 linux-6.6 主线源码\n"
        "核心文件组基于amd64版的ubuntu-base-rootfs创建，可以方便的使用apt指令安装软件\n"
        "\n\n"
        "安装完成后，在桌面上会有启动图标", 
        "./scripts/qemu-linux-amd64.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.sys, SWGROUP.bootdisk], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "mkbootudisk", 
        "",
        "",
        " 制作winpe启动U盘的小工具\n"
        " winpe版本为win10pe，相关文件来自 https://gitee.com/duanwujie88/WinPE \n"
        " 支持BIOS(老)/UEFI(新)两种启动模式！\n"
        "\n"
        "请注意：\n"
        "  网友反馈此工具有风险，部分U盘可能会损坏！！！\n"
        "\n"
        "如果PE启动盘制作失败，可尝试专用的app: EtchDroid\n"
        "\n"
        "制作成功后\n"
        "U盘会被划分成两个分区：\n"
        " 一个小容量分区(存放pe系统启动文件)\n"
        " 一个大容量分区(镜像存放分区)\n"
        "\n"
        " 如需要使用自定义的PE镜像，请替换 /opt/apps/mkbootudisk/winpe.zip(只支持zip格式) "
        " 如用于启动BIOS模式的电脑，替换镜像时请注意保留 grub 相关文件"
        "\n\n"
        "此软件不包含 windows 安装程序、windows恢复镜像，请自行下载"
        "\n\n"
        "安装完成后，在桌面上会有启动图标", 
        "./scripts/mkbootudisk.sh",
        SWSOURCE.thirdpary,
))
SoftWareList[-1].deprecated = True




SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "nginx", 
        "",
        "",
        "网页服务器，包括：\n"
        "nginx php-fpm redis php-redis\n"
        "\n"
        "请注意，proot环境中，php8.3中的php-fpm无法正常启用zend.opcache功能\n"
        "\n"
        "如需将网站发布到公网，可使用免费的内网穿透工具:\n"
        "免费、提供网址：https://natapp.cn/\n"
        "免费、要买域名：https://freefrp.net/\n"
        "\n\n"
        "安装成功后可以在桌面上的软件目录里打开\n",
        "./scripts/nginx.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "caddy", 
        "v2.9.0-beta.3",
        "",
        "网页服务器(近年新出的开源项目)，包括：\n"
        "caddy\n"
        "启动指令：caddy run -c /etc/caddy/Caddyfile\n"
        "默认端口号：2019\n"
        "默认配置文件：/etc/caddy/Caddyfile\n"
        "默认主页路径：/usr/share/caddy\n"
        "\n"
        "\n"
        "\n"
        "如需将网站发布到公网，可使用免费的内网穿透工具:\n"
        "免费、提供网址：https://natapp.cn/\n"
        "免费、要买域名：https://freefrp.net/\n"
        "\n\n"
        "安装成功后可以在桌面上的软件目录里打开\n",
        "./scripts/caddy.sh",
        SWSOURCE.github,
))


SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "mysql-server", 
        "",
        "",
        "linux系统中常用的数据库服务器，分为服务端和客户端\n"
        "服务端程序为：mysqld\n"
        "客户端程序为：mysql，用于在控制台终端中连接到 mysql-server\n"
        "\n"
        "客户端程序也可以是支持mysql访问接口的其它任意类型的编程语言\n"
        "比如: php，C...\n"
        "或者: 其它专用的数据库连接、管理工具\n"
        "\n"
        "安装时会随机生成用户名及密码，保存在这个文件中：\n"
        "/etc/mysql/debian.cnf\n"
        "\n"
        "如需启用root用户，请运行：\n"
        "sudo mysqld_passwd_root\n"
        "\n"
        "安装成功后可以运行指令 mysqld 来启动mysql服务端\n"
        "\n"
        "默认安装的mysql客户端使用示例: mysql -u *** -p，回车后输入密码即可\n"
        "\n"
        "若需要带图形界面的连接工具，请\n"
        "安装下面的 dbeaver\n"
        "或自行安装 adminer、phpMyAdmin 等基于浏览器的数据库管理工具\n"
        "除此之外，目前没有更好的 适用于 arm64-linux 的原生的 mysql数据库管理工具"
        "",
        "./scripts/mysql.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "adminer", 
        "",
        "",
        "使用php写的基于浏览器的mysql连接工具\n"
        "超轻量，仅一个php文件\n"
        "\n"
        "会被下载到这个路径：\n"
        "/var/www/html/adminer.php\n"
        "\n"
        "访问网址为 http://\"nginx 网址\"/adminer.php\n"
        "",
        "./scripts/adminer.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "dbeaver", 
        "",
        "",
        "带图形界面的mysql连接工具\n"
        "需要先安装jdk\n"
        "\n"
        "若连接不上数据库\n"
        "请右击并编辑你新创建的连接，将 \"allowPublicKeyRetrieval\" 设置为true\n"
        ""
        "安装完成后，桌面上会有启动图标", 
        "./scripts/dbeaver.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "x-ui(内部测试)", 
        "0.3.4.4",
        "",
        "Xray封装版,带网页控制面板\n"
        "仓库地址：https://github.com/FranzKafkaYu/x-ui\n" # https://github.com/alireza0/x-ui
        "\n"
        "深度加密代理协议的服务器端，客户端推荐 v2rayN\n"
        "控制面板默认走明文的http! 非https，不安全!\n"
        "\n"
        "仅限于外网资料查阅、下载场景!!!\n"
        "仅限于外网资料查阅、下载场景!!!\n"
        "仅限于外网资料查阅、下载场景!!!\n"
        "仅限于外网资料查阅、下载场景!!!\n"
        "\n"
        "一般来说，要在公网机器上安装\n"
        "要不就得结合nps、frp等穿透工具使用，否则没意义\n"
        "面板地址：http://IP:54321/\n"
        "面板密码：admin   admin\n"
        "\n"
        "深度加密代理协议大致的实现原理：\n"
        "1).　用户电脑需要安装专用客户端(如v2rayN)\n"
        "　　客户端软件对电脑上的浏览器等连网软件提供socks/http代理\n"
        "　　会识别连网软件的网络请求，并将请求包深度加密后传给远端的代理服务端\n"
        "2).　远端代理服务器上要运行服务端软件(如xray), 侦听公网IP及端口\n"
        "　　并接受深度加密后的请求包，然后代为请求真实的目标服务器\n"
        "　　最后将收到的目标服务器的响应包，深度加密后传回客户端\n"
        "3).　客户端软件做深度解密后，通过环回代理响应本地的连网软件\n"
        "　　客户端软件和连网软件之间的通道，属于同设备环回的传统代理\n"
        "　　客户端软件和服务器端之间的通道，属于公网中的深度加密代理\n"
        "\n"
        "深度加密代理，结合应用层实现的dns协议\n"
        "可做到用户电脑外发到公网环境的数据包都是深度加密过的, 很难被识别\n"
        "\n"
        "安装完成后，桌面上会有启动图标", 
        "./scripts/x-ui.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "frp-client", 
        "0.61.1",
        "",
        "内网穿透客户端\n"
        "仓库地址：https://github.com/fatedier/frp\n"
        "\n"
        "需结合位于公网的frp服务端使用，可自建服务器或购买年付的frp通道\n"
        "无控制面板，使用配置文件进行配置\n"
        "\n"
        "安装完成后，桌面上会有启动图标、配置文件图标", 
        "./scripts/frp-client.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "nps-client", 
        "0.26.10",
        "",
        "内网穿透客户端\n"
        "仓库地址：https://github.com/ehang-io/nps\n"
        "\n"
        "无控制面板，使用配置文件进行配置\n"
        "\n"
        "安装完成后，桌面上会有启动图标、配置文件图标", 
        "./scripts/nps-client.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "ddns-client", 
        "6.8.1",
        "",
        "内网穿透客户端\n"
        "仓库地址：https://github.com/jeessy2/ddns-go\n"
        "\n"
        "动态域名解析服务, 用于将域名解析到有动态公网IP的住宅电脑\n"
        "需要购买付费通道\n"
        "\n"
        "面板地址：http://IP:9876/\n"
        "面板密码：admin   admin(可设置为任意组合)\n"
        "\n"
        "安装完成后，桌面上会有启动图标", 
        "./scripts/ddns-client.sh",
        SWSOURCE.github,
))

SoftWareList.append(
    SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "clash", 
        "2.2.2",
        "",
        "科学上网工具, 深度加密型代理的客户端软件\n"
        "仓库地址：https://github.com/clash-verge-rev/clash-verge-rev\n"
        "\n"
        "使用说明：\n"
        "==================================\n"
        "1). 线路及流量需要自行购买\n"
        "\n"
        "2). 安卓上测试过的平台\n"
        "　　　GGDD, 不限制客户端软件: https://ggdd.link\n"
        "　　优信云, 得使用专用客户端: https://www.youxincloud.net/\n"
        "\n"
        "3). 如需让同一局域网内的其它设备连接\n"
        "　　请在 clash 设置界面中打开 \"允许局域网连接\" 的开关\n"
        "\n"
        "导入购买的线路(付费后通常会得到一个链接地址)：\n"
        "==================================\n"
        "1). 先从平台复制好购买的链接\n"
        "2). 再打开clash 并切换到 订阅 界面\n"
        "3). 粘贴链接, 点击 \"导入\" 按钮即可\n"
        "\n"
        "相关环境变量(专用客户端一般也会侦听网络端口对外开放代理服务)：\n"
        "==================================\n"
        "export  http_proxy=http://127.0.0.1:7890\n"
        "export https_proxy=http://127.0.0.1:7890\n"
        "clash侦听的端口号请自行在 clash 设置界面中设置\n"
        "\n"
        "软件本体配置文件路径：\n"
        "==================================\n"
        "~/.local/share/io.github.clash-verge-rev.clash-verge-rev/config.yaml\n"
        "\n"
        "特别声明：\n"
        "==================================\n"
        "购买使用的风险自担，不做任何形式的推荐\n"
        "访问受限网站属于非法行为，仅限于外网资料查阅、下载场景!!!\n"
        "访问受限网站属于非法行为，仅限于外网资料查阅、下载场景!!!\n"
        "访问受限网站属于非法行为，仅限于外网资料查阅、下载场景!!!\n"
        "访问受限网站属于非法行为，仅限于外网资料查阅、下载场景!!!\n"
        "\n"
        "安装完成后，桌面上有 clash 的启动图标\n"
        "桌面上的chrome图标, 也被复制出一个 \"使用代理\" 的启动图标", 
        "./scripts/clash.sh",
        SWSOURCE.github,
))


# SoftWareList.append(
#     SW( [SWGROUP.repair], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "apt仓库切换", 
#         "",
#         "",
#         "切换APT软件仓库地址。若显示已安装，请重装",
#         "./scripts/apt-repo-switcher.sh",
#         SWSOURCE.aptrepo,
# ))

SoftWareList.append(
    SW( [SWGROUP.repair], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "apt仓库刷新", 
        "",
        "",
        "执行指令：sudo apt update。若显示已安装，请重装",
        "./scripts/rp0.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.repair], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "修复1-补配置", 
        "",
        "",
        "执行指令：sudo dpkg --configure -a。若显示已安装，请重装\n"
        "通常对应于apt的错误码100",
        "./scripts/rp1.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.repair], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "修复2-修依赖", 
        "",
        "",
        "执行指令：sudo apt --fix-broken install -y。若显示已安装，请重装\n"
        "通常对应于apt的错误码100",
        "./scripts/rp2.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.repair], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "修复3-补缺包", 
        "",
        "",
        "执行指令：sudo apt-get install --fix-missing -y。若显示已安装，请重装",
        "./scripts/rp3.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.repair], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "修复4-清除坏包", 
        "",
        "",
        "清除系统中只安装到一半的损坏包。若显示已安装，请重装\n"
        "适用于这类错误提示：xxx需要重新安装，但我无法找到它的安装包\n"
        "",
        "./scripts/rp4.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.repair], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "修复5-修复文件夹打开方式异常", 
        "",
        "",
        "执行指令：xdg-mime default pcmanfm.desktop \"inode/directory\"。\n"
        "若显示已安装，请重装"
        "",
        "./scripts/rp5.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "大鼠标指针", 
        "",
        "小于1分钟",
        "觉得鼠标指针过小的，可以安装这个软件包\n"
        "",
        "./scripts/bigpointer.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "Xfce终端", 
        "",
        "",
        "支持拖入文件夹获取路径",
        "./scripts/xfce-terminal.sh",
        SWSOURCE.thirdpary,
))


SoftWareList.append(
    SW( [SWGROUP.printe3d], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "klipper", 
        "",
        "",
        # "klipper 用于控制3D打印机。项目开源免费，在国内很流行，它包括两个部分：\n"
        # "一部分是上位机软件，用python开发，通常运行于性能不弱的linux系统上\n"
        # "一部分是固件源码，可编译烧录到3D打印机控制板中，固件也叫 firmware\n"
        # "\n"
        # "从固件源码看，目前支持的mcu主要的: ar、at、avr、hc、lpc、pru、rp、stm32各系列\n"
        # "对特定的控制板、mcu，需要下载源码、配置源码(即选择要编译哪些功能、编译哪颗芯片的代码)\n"
        # "源码配置好以后，编译生成的 .bin/.hex 文件，就可以将其传送到控制上的芯片内，即烧写、下载、刷新固件\n"
        # "\n"
        # "固件的烧写，不同的芯片支持不同的数据传送通道，大概这几类：\n"
        # "用usb数据线，用串口线(或usb转串口线),用SD卡\n"
        # "不同的芯片，烧写固件所用的工具不相同，固件代码的打包格式、传送协议也不同\n"
        # "\n\n"
        # "安装成功后桌面会有klipper图标，双击即可启动\n"
        # "也可以在终端用 klipper 指令启动。klipper 通常要结合 moonraker + mainsail 两个软件才能使用！"
        # "\n"
        # "如果启动失败，可尝试专用的app: BeamKlipper (维护较积极)\n"
        # "BeamKlipper仓库地址: https://github.com/utkabobr/BeamKlipper\n"
        "2025.05.15起不再维护\n"
        "请换用BeamKlipper, 仓库地址: https://github.com/utkabobr/BeamKlipper\n"
        "\n",
        "./scripts/klipper.sh",
        SWSOURCE.thirdpary,
))
SoftWareList[-1].deprecated = True

SoftWareList.append(
    SW( [SWGROUP.printe3d], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "moonraker", 
        "",
        "",
        "moonraker是一个pythone程序，它通过一个 \"Unix Domain Socket\" 文件连接到运行中的 klipper上位机软件\n"
        "并将 klipper 对其它程序开放的TCP控制接口转换成 websocket 协议控制的接口\n"
        "以便 Mainsail/Fluidd/KlipperScreen/mooncord 一类的软件能对用户提供更友好的klipper控制界面\n"
        "\n\n"
        "安装成功后可以执行 moonraker 指令启动moonraker\n"
        "启动后可以访问 http://设备IP:7125/ 这个网址查看运行状态\n"
        "这是json版本的 http://设备IP:7125/server/info\n",
        "./scripts/moonraker.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.printe3d], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "mainsail", 
        "",
        "",
        "mainsail 是klipper网页端的控制界面，安装此软件会自动安装nginx\n"
        "\n\n"
        "安装成功后可以执行 mainsail 指令启动mainsail\n"
        "启动后可以访问 http://设备IP:8888/ 这个网址查看控制界面",
        "./scripts/mainsail.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.printe3d], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "fluidd", 
        "",
        "",
        "fluidd 也是klipper网页端的控制界面，安装此软件会自动安装nginx，和mainsail二选一即可！\n"
        "\n\n"
        "安装成功后可以执行 fluidd 指令启动fluidd\n"
        "启动后可以访问 http://设备IP:9999/ 这个网址查看控制界面",
        "./scripts/fluidd.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.printe3d], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "klipperscreen", 
        "",
        "",
        "klipperscreen 是用pythone + gtk库写的本地klipper控制端"
        "\n\n"
        "安装成功后可以在桌面上双击klipperscreen图标打开\n"
        "\n",
        "./scripts/klipperscreen.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.printe3d], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "cura", 
        "",
        "",
        "cura 是流行的3D打印切片软件\n"
        "默认为英文，可以在菜单栏->preference中设置成中文"
        "\n\n"
        "安装成功后可以在桌面上的软件目录里打开\n"
        "\n",
        "./scripts/cura.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.printe3d], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "prusaslicer", 
        "",
        "",
        "prusaslicer 是流行的3D打印切片软件\n"
        "提示：\n"
        "　此软件的窗口，宽高比是锁死的\n"
        "　在非4:3、非16:9的屏幕上显示效果可能不太好\n"
        "\n\n"
        "安装成功后可以在桌面上的软件目录里打开\n"
        "\n",
        "./scripts/prusaslicer.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.printe3d], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "中望CAD", 
        "2024.1.3.4",
        "",
        "国产cad软件\n"
        "官方网站: https://www.zwsoft.cn/product/zwcad/linux?year=2024"
        "\n"
        "安装包需要自行下载(ubuntu-麒麟 版)\n"
        "建议进资源群获取，群号: 1030919016, 此群长期禁聊\n"
        "文件名: zwcad2024_24.1.3.4_arm64.deb\n"
        "\n\n"
        "安装成功后可以在桌面上的软件目录里打开\n"
        "\n",
        "./scripts/zwcad.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.printe3d], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "freecad", 
        "",
        "",
        "linux中常用的cad软件\n"
        "ubuntu-24.04 中, freecad 已从apt仓库移除\n"
        "默认为英文，可以在菜单栏->edit->preference中设置成中文"
        "\n\n"
        "安装成功后可以在桌面上的软件目录里打开\n"
        "\n",
        "./scripts/freecad.sh",
        SWSOURCE.aptrepo,
))
SoftWareList[-1].deprecated = True



SoftWareList.append(
    SW( [SWGROUP.art], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "gimp", 
        "",
        "",
        "linux系统中的图片处理工具，GNU Image Manipulation Program，", 
        "./scripts/gimp.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.art], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "krita", 
        "",
        "",
        "linux系统中的图片处理工具，网友说可以替代photoshop", 
        "./scripts/krita.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.art], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "imagemagick", 
        "",
        "",
        "命令行下的图片格式转换工具", 
        "./scripts/imagemagick.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.art], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "shotcut", 
        "",
        "",
        "linux系统中的视频剪辑软件", 
        "./scripts/shotcut.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.art], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "Kdenlive", 
        "",
        "",
        "linux系统中的视频剪辑软件\n"
        "软件官网：https://launchpad.net/~kdenlive\n"
        "\n"
        "安装完成后，请到桌面上的软件目录打开"
        "",
        "./scripts/kdenlive.sh",
        SWSOURCE.officialwebsite,
))


SoftWareList.append(
    SW( [SWGROUP.art], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "blender", 
        "",
        "",
        "跨平台的3D设计神器\n"
        "目前虚拟系统只能发挥物理显卡约1/3的效率，所以在手机上跑比较吃力\n"
        "默认为英文，可以加载窗中调为中文\n"
        "\n"
        "安装成功后软件目录中会有两个启动图标\n"
        "一个带加速(不一定能顺利启动)\n"
        "一个不带加速(都能启动)\n"
        "",
        "./scripts/blender.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.art], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "starUML", 
        "",
        "",
        "开源的UML设计工具\n"
        "\n"
        "安装成功后桌面上有启动图标\n"
        "一个带加速(不一定能顺利启动)\n"
        "一个不带加速(都能启动)\n"
        "",
        "./scripts/starUML.sh",
        SWSOURCE.aptrepo,
))


SoftWareList.append(
    SW( [SWGROUP.nas], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "PyWebDAV3", 
        "",
        "",
        "PyWebDAV3运行后，可以在windows电脑上访问、编辑虚拟电脑中的文件\n"
        "默认端口: 5562\n"
        "\n"
        "安装完成后，在开始菜单->文件共享菜单中启动"
        "",
        "./scripts/PyWebDAV3.sh",
        SWSOURCE.thirdpary,
))




SoftWareList.append(
    SW( [SWGROUP.nas], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "filebrowser", 
        "",
        "",
        "filebrowser运行后，可以通过网页浏览器访问、编辑文件\n"
        "默认用户: droidvm\n"
        "默认密码: droidvm\n"
        "默认端口: 5561\n"
        "\n"
        "安装完成后，桌面上有启动图标"
        "",
        "./scripts/filebrowser.sh",
        SWSOURCE.thirdpary,
))


SoftWareList.append(
    SW( [SWGROUP.nas], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "alist", 
        "",
        "",
        "alist可以将当前设备当成本地网盘、家庭网络存储\n"
        "也可以挂载商业网盘\n"
        "暂不支持离线下载功能，请使用虚拟系统自带的下载工具下载\n"
        "\n"
        "默认用户：admin\n"
        "默认密码：droidvm\n"
        "\n"
        "首次通过网页登录，需要手动添加存储路径，步骤为：\n"
        "点底部的 管理 按钮\n"
        "管理面板左侧，点击 存储\n"
        "存储管理面板，点击 添加\n"
        "驱动选 本机存储\n"
        "挂载路径填 /\n"
        "文件路径填 /home/droidvm/Desktop\n"
        "提交后，点左侧面板的 主页"
        "",
        "./scripts/alist.sh",
        SWSOURCE.thirdpary,
))

SoftWareList.append(
    SW( [SWGROUP.game], [SWPROPS.sysdir],  [SWARCH.arm64],
        "electron", 
        # "28.1.3",
        "18.2.3",
        "",
        "electron是个基础运行库，有很多近年开发的跨平台软件都是基于electron开发的\n"
        "软件官网：https://www.electronjs.org/zh/\n"
        "镜像站点：https://registry.npmmirror.com/binary.html?path=electron/v28.1.3/\n"
        "", 

        "./scripts/electron.sh",
        SWSOURCE.officialwebsite,
))

SoftWareList.append(
    SW( [SWGROUP.swcompile], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "mesa.freedreno(编译)", 
        "24.3.0",
        "约10分钟",
        "mesa是GPU 驱动程序(显卡驱动)，完全开源。\n"
        "软件官网：https://gallo.pages.freedesktop.org/mesa/drivers/freedreno.html\n"
        "源码地址：https://archive.mesa3d.org/\n"
        "补丁来源：https://github.com/droidvm/mesa-freedreno-patchs\n"
        "\n"
        "编译完成后，可打开日志查看tar.xz包存放位置\n"
        "不会自动安装，需要自行将编译好的tar.xz包解压到根目录进行安装\n"
        "\n",
        "./scripts/compile-mesa.freedreno.sh",
        SWSOURCE.github,
))
SoftWareList[-1].viewlogInNewWindow=True

SoftWareList.append(
    SW( [SWGROUP.swcompile], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "mesa.panfrost(内测专用, 编译)", 
        "23.2.1",
        "约16分钟",
        "mesa是GPU 驱动程序(显卡驱动)，完全开源。\n"
        "软件官网：https://docs.mesa3d.org/drivers/panfrost.html\n"
        "\n"
        "mesa支持多种CPU架构的多种GPU型号。\n"
        "编译成功会生成一堆动态库(具体生成哪些库，由编译时所下的参数决定)，包括：\n"
        "openGL、openGLES、dri、vulkan...\n"
        ""
        "\n"
        "对于比较老的arm架构的GPU，mesa有lima    驱动库\n"
        "对于比较新的arm架构的GPU，mesa有panfrost驱动库\n"
        "\n"
        "更详细的信息，请自行查阅MESA的官方网站\n"
        "\n"
        "此软件包在安装时，会从apt源码仓库下载mesa源码，加参数启用panfrost功能后编译安装\n"
        "\n"
        "编译成功后，桌面上会有测试图标，且驱动程序会被安装到以下目录：\n"
        "/usr/lib/mesa.panfrost"
        "\n",
        "./scripts/compile-mesa.panfrost.sh",
        SWSOURCE.aptrepo,
))
SoftWareList[-1].viewlogInNewWindow=True

SoftWareList.append(
    SW( [SWGROUP.swcompile], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "mesa.panfrost(内测专用-G610专版, 编译)", 
        "23.0.0",
        "约16分钟",
        "此版源码中的panfrost库，仅支持G610、G710两个GPU型号！\n"
        "仓库地址：https://github.com/Saikatsaha1996/mesa-Panfrost-G610\n"
        "\n"
        "此软件包在安装时，会从github仓库下载mesa源码，加参数启用panfrost功能后编译安装\n"
        "\n"
        "编译成功后，桌面上会有测试图标，且驱动程序会被安装到以下目录：\n"
        "/usr/lib/mesa.panfrost"
        "\n",
        "./scripts/compile-mesa.panfrost.github.sh",
        SWSOURCE.github,
))
SoftWareList[-1].viewlogInNewWindow=True

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "kde-plasma", 
        "",
        "约10分钟",
        "kde 是一个常用的linux桌面环境\n"
        "体积1.6GB，比xfce4更大，启动的进程也更多\n"
        "界面比精简桌面漂亮，但是启动慢很多\n"
        "由于该桌面启动的进程数量很多，容易被杀进程、出现黑屏的现象\n"
        "所以，在进程杀得比较狠的手机上，[ 不建议 ] 安装\n"
        "\n"
        "实测发现，桌面启动完成还没运行任何软件进程数量就超过了50个以上\n"
        "依照proot的工作原理，进程越多其效率会加速降低，请自行决定是否安装\n"
        "\n"
        "安装完成后，桌面上有切换桌面的图标\n"
        , 
        "./scripts/kde-plasma.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "enlightenment", 
        "",
        "约5分钟",
        "enlightenment 是一个稍冷门的linux桌面环境\n"
        "体积约500MB，比xfce4稍轻量, 自带少量动效\n"
        "首次启动很慢，且需要自行配置国别、键盘布局等\n"
        "\n"
        "安装完成后，桌面上有切换桌面的图标\n"
        , 
        "./scripts/enlightenment.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.desktop], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "gnome", 
        "",
        "约半小时",
        "gnome桌面环境\n"
        "体积约1.7G，仅供体验！\n"
        "目前在手机上的测试结果：\n"
        "1). 非全功能版\n"
        "2). 运行也不稳定\n"
        "3). 无桌面图标\n"
        "\n"
        "安装完成后，桌面上有切换桌面的图标\n"
        , 
        "./scripts/gnome.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "scratch", 
        "1.4.0",
        "",
        "少儿图形化编程工具（语言）\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/scratch.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.dev], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
        "mixly", 
        "3.0 rc0",
        "",
        "可视化编程工具（语言）\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/mixly.sh",
        SWSOURCE.aptrepo,
))

SoftWareList.append(
    SW( [SWGROUP.ai], [SWPROPS.sysdir],  [SWARCH.arm64],
        "chatbox", 
        "1.5.1",
        "",
        "可用于安装chatgpt\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/chatbox.sh",
        SWSOURCE.officialwebsite,
))

# SoftWareList.append(
#     SW( [SWGROUP.server], [SWPROPS.sysdir],  [SWARCH.arm64, SWARCH.amd64],
#         "homeassistant", 
#         "2023.6.3",
#         "",
#         "智能家居控制中心软件\n"
#         "\n\n"
#         "安装成功后可以在桌面上的软件目录里打开\n",
#         "./scripts/homeassistant.sh",
#         SWSOURCE.pip,
# ))

SoftWareList.append(
    SW( [SWGROUP.industry], [SWPROPS.none],  [SWARCH.arm64],
        "嘉立创EDA专业版", 
        "2.2.36.7",
        "",
        "嘉立创EDA专业版，用于设计电路板\n"
        "设计好的电路板, 可以很方便的交由工厂生产\n"
        "不定期的还会有免费打样服务\n"
        "\n"
        "安装完成后，桌面上有启动图标", 
        "./scripts/lceda-pro.sh",
        SWSOURCE.officialwebsite,
))
