
from enum import Enum

SWGROUPNAMES =      ["常用软件", "本地安装包", "==>  修复类  <==", "输入法-外接键盘", "文本编辑器",  "桌面环境", "上网工具", "办公软件", "影音娱乐", "压缩工具", "下载工具", "虚拟类", "游戏", "软件开发", "系统", "服务器类",  "3D打印",    "图影动漫", "远程桌面", "NAS网盘", "启动U盘", "编译安装", "AI类", "工业设计"]
# SWGROUP = .freeze({ none        localdeb           repair            input           editor          desktop    internet      office      media     compress     download      vir    game       dev      sys      server     printe3d         art         rdp       nas       bootdisk   swcompile   ai      industry})


class SWGROUP(Enum):
    none = 0
    localdeb = 1
    repair = 2
    input = 3
    editor = 4
    desktop = 5
    internet = 6
    office = 7
    media = 8
    compress = 9
    download = 10
    vir = 11
    game = 12
    dev = 13
    sys = 14
    server = 15
    printe3d = 16
    art = 17
    rdp = 18
    nas = 19
    bootdisk = 20
    swcompile = 21
    ai = 22
    industry = 23

SoftWareProps = ["", "需安装到系统目录"]
class SWPROPS(Enum):
    none = 0
    sysdir = 1

SoftWareSource = ["本地deb安装包", "apt仓库", "第三方", "软件官网", "pip仓库", "github仓库 [网络不稳定]"]
class SWSOURCE(Enum):
    localdeb = 0
    aptrepo = 1
    thirdpary = 2
    officialwebsite = 3
    pip = 4
    github = 5

SoftWareArch = ["arm64", "amd64"]
class SWARCH(Enum):
    arm64 = 0
    amd64 = 1

SoftWareOP = ["none", "installing", "reinstalling", "removing", "fail"]
class SWOP(Enum):
    none = 0
    installing = 1
    reinstalling = 2
    removing = 3
    fail = 4
