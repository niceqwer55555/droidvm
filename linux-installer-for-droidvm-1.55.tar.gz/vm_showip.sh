#!/bin/bash



cat <<- EOF > /tmp/ip.txt

私网IP：
================================
EOF

/exbin/tools/vm_ip2link.sh >>/tmp/ip.txt

if [ -f ${app_home}/tmp/my_internet_ip.txt ]; then
    echo -e "\n\n公网信息："                >> /tmp/ip.txt
    echo "================================" >> /tmp/ip.txt
    cat ${app_home}/tmp/my_internet_ip.txt  >> /tmp/ip.txt
fi

cat <<- EOF >> /tmp/ip.txt


EOF

gxmessage -title "本机IP" -file /tmp/ip.txt -center
