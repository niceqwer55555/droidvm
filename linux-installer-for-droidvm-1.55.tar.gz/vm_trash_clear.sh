#!/bin/bash

gxmessage -title "清空回收站"  $'\n请注意，清空后，回收站中的内容无法恢复，确定要清空吗\n\n' -center -buttons "我确定:1,取消:0"
if [ $? -eq 1 ]; then
	rm -rf /home/droidvm/.local/share/Trash/*
fi

