#!/bin/bash

pkill pcmanfm

pcmanfm --desktop &
