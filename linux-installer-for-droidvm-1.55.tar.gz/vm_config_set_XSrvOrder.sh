#!/bin/bash

action=$1

gui_title="XServer管理"

if [ "$action" == "" ]; then
	action="Xvfb xlorie Xtigervnc"
fi

if [[ "$action" == "Xtigervnc"* ]]; then
	command -v Xtigervnc
	if [ $? -ne 0 ]; then
		gxmessage -title "设置失败" "Xtigervnc 未安装，请先在桌面上的软件管家中搜索并安装 webvnc "  -center
		exit 1
	fi
fi

# if [[ "$action" == "xlorie"* ]]; then
# 	gxmessage -title "设置失败" "虚拟电脑 1.51 版尚未适配好 xlorie!"  -center
# 	exit 1
# fi

echo "$action">${DirGuiConf}/xserver_order.txt
gxmessage -title "${gui_title}" "XServer优先级已设置为 ${action}  ，重启生效"  -center
