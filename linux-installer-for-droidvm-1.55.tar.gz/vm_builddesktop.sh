#!/bin/bash

source ${tools_dir}/vm_config.sh

mkdir -p /home/droidvm/Desktop/           2>/dev/null
mkdir -p /home/droidvm/.local/share/Trash 2>/dev/null
mkdir -p /home/droidvm/.config/gtk-3.0    2>/dev/null

echo "file:/// 根目录"                      > /home/droidvm/.config/gtk-3.0/bookmarks
echo "file:///usr/share/applications 软件"  > /home/droidvm/.config/gtk-3.0/bookmarks

cp -f ${tools_dir}/zzswmgr/zzswmgr.desktop  /home/droidvm/Desktop/
ln -sf ${app_home}/doc/教程                 /home/droidvm/Desktop/教程

cat <<- EOF > /home/droidvm/Desktop/软件.desktop
	[Desktop Entry]
	Encoding=UTF-8
	Version=0.9.4
	Type=Application
	Exec=open /usr/share/applications
	Icon=folder
	Name=软件
EOF

cat <<- EOF > /home/droidvm/Desktop/3dtest.desktop
    [Desktop Entry]
    Encoding=UTF-8
    Version=0.9.4
    Type=Application
    Name=3D测试
    Comment=3D测试
    Icon=/exbin/tools/zzswmgr/appicons/mesa.svg
    Exec=/exbin/tools/misc/helper/3dtest.sh
    Terminal=true
EOF

cat <<- EOF > /home/droidvm/Desktop/我的电脑.desktop
	[Desktop Entry]
	Encoding=UTF-8
	Version=0.9.4
	Type=Application
	Exec=open /
	Icon=/exbin/tools/zzswmgr/appicons/ic_launcher.png
	Name=我的电脑
EOF

cat <<- EOF > /home/droidvm/Desktop/terminal.desktop
	[Desktop Entry]
	Encoding=UTF-8
	Version=0.9.4
	Type=Application
	Name=xf终端
	Terminal=false
	Icon=/exbin/tools/zzswmgr/appicons/ic_terminal.png
	Categories=System;
	Exec=cmd -e bash
	Path=~/
EOF


if [ "${LINUX_DISTRIBUTION}" != "ubuntu" ]; then
	cat <<- EOF > /home/droidvm/Desktop/bk2ubuntu.desktop
		[Desktop Entry]
		Encoding=UTF-8
		Version=0.9.4
		Type=Application
		Exec=/exbin/tools/vm_OSRebootto.sh ubuntu-arm64
		# Icon=computer
		Icon=/exbin/tools/zzswmgr/appicons/ic_launcher.png
		Name=返回ubuntu
	EOF

	# cat <<- EOF > /home/droidvm/Desktop/调大xfce4字体.desktop
	# 	[Desktop Entry]
	# 	Encoding=UTF-8
	# 	Version=0.9.4
	# 	Type=Application
	# 	Name=xfce4调大字体
	# 	Comment=其实是将xfce的dpi调高到180
	# 	Exec=/exbin/tools/misc/helper/fontsize_grow.sh
	# 	Terminal=true
	# EOF
fi

chmod a+x        /home/droidvm/Desktop/*.desktop
chown -R droidvm /home/droidvm/Desktop/*.desktop
chown -R droidvm /home/droidvm/
