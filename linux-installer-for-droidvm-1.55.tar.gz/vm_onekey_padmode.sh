#!/bin/bash

echo "#vmSHFloatingLayout_ff" > ${NOTIFY_PIPE}

echo "xlorie Xvfb Xtigervnc"	>${DirGuiConf}/xserver_order.txt
echo '0.1'						>/exbin/app_boot_config/cfg_xserver_wait_seconds.txt
/exbin/tools/vm_setuimode.sh pc    1
