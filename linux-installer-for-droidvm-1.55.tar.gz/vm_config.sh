######## !/bin/bash


export DROIDVM_PULSEPORT=4713
export APP_QQ_QUN="6群: 993606485"
export APP_QQ_Qzy="群号:1030919016"

# 2025.03.18 已改为由用户控制 => ${app_home}/droidvm_vars_github_proxy_http.rc
export GITHUB_PROXY_HOST_DEFAULT="wget.la"
export GITHUB_PROXY_HTTP_DEFAULT="https://${GITHUB_PROXY_HOST_DEFAULT}/"

if [ ! -d /exbin/vm ]; then
    export tools_dir=$app_home/tools
	source ${app_home}/droidvm_vars.sh
	source ${app_home}/droidvm_vars_setup.sh
    if [ "${vmDistribution}" == "1" ] || [ "${vmDistribution}" == "" ]; then
        export vmDistribution=debian
    fi

    export LINUX_FAKE_PROC_DIR=${tools_dir}/fake_proc
    export LINUX_LOGIN_COMMAND='/exbin/tools/vm_init.sh'
    # export LINUX_LOGIN_COMMAND='/bin/bash --login'
    # export LINUX_LOGIN_COMMAND='/exbin/tools/vm.sh'

    tmpscript=${tools_dir}/distributions/${vmDistribution}/4_init.sh
    if [ -f ${tmpscript} ]; then
        chmod a+x ${tmpscript}
        export LINUX_LOGIN_COMMAND=/exbin/tools/distributions/${vmDistribution}/4_init.sh
    fi

    # echo "LINUX_LOGIN_COMMAND: ${LINUX_LOGIN_COMMAND}"
    # echo ""

else
    export app_home=/exbin

    export tools_dir=$app_home/tools
	source ${app_home}/droidvm_vars.sh
	source ${app_home}/droidvm_vars_setup.sh
    if [ "${vmDistribution}" == "1" ] || [ "${vmDistribution}" == "" ]; then
        export vmDistribution=debian
    fi

    # 2025.03.11
    unset pmadd
    unset pmdel

    # 2024.06.09
    export PULSE_SERVER=tcp:127.0.0.1:${DROIDVM_PULSEPORT}

    export ZZEXE_VERBOSE_ON=1
    export DirGuiConf=~/.droidvm
    export DirBakConf=/etc/droidvm/def_xconf
    export PATHUIMODE=${DirGuiConf}/uimode.txt
    export PATH_VMDPI=${DirGuiConf}/vm_dpi.txt
    export PATH_VmColorscheme=${app_home}/app_boot_config/vm_color_scheme.txt
    export PATH_GETIFADDRS_CLIENT=${tools_dir}/getifaddrs/getifaddrs_bridge_client_lib.so

    # 2025.04.17
    export NO_AT_BRIDGE=1
    export DBUS_VERBOSE=1

    # 2025.02.23
    export XDG_RUNTIME_DIR=~

    # 2025.03.11
    export XDG_SESSION_TYPE=x11

fi

if [ $APP_SDKTar -gt 28 ]; then
    export ASCRIPTER=/system/bin/sh
    export ALINKER64=linker64
else
    export ASCRIPTER=
    export ALINKER64=
fi

source ${APP_FILENAME_URLDLSERVER}

if [ -f ${app_home}/droidvm_vars_github_proxy_http.rc ]; then
    source ${app_home}/droidvm_vars_github_proxy_http.rc
fi

if [ "${LINUX_DISTRIBUTION}" == "" ] || [ "${LINUXVersionName}" == "" ] ; then
    source  ${tools_dir}/distributions/${vmDistribution}/0_ver_info.rc 2>/dev/null
fi

case "${vmCpuArchId}" in
    "1" | "amd64")
        export CURRENT_VM_ARCH="amd64"
        export KSTRING_VM_ARCH="x86_64"
        export CURRENT_OS_NAME="${LINUX_DISTRIBUTION}-${CURRENT_VM_ARCH}"
        ;;
    *)
        export CURRENT_VM_ARCH="arm64"
        export KSTRING_VM_ARCH="aarch64"
        export CURRENT_OS_NAME="${LINUX_DISTRIBUTION}-${CURRENT_VM_ARCH}"
        ;;
esac
export EX_NDK_TOOLS_VERSION=1.55

if [ ! -d /exbin/vm ]; then
	# export LINUX_DIR="${files_dir}/vm/${CURRENT_OS_NAME}"
	if [ -d "${files_dir}/exbin" ]; then
		export LINUX_DIR="../../vm/${CURRENT_OS_NAME}"
	else
		export LINUX_DIR="../vm/${CURRENT_OS_NAME}"
	fi

    # PROOT_VERBOSE 值越大，proot 输出的信息越多
    # export PROOT_VERBOSE=1

    export PROOT_BINARY_DIR=${tools_dir}/ndkproot
    export PROOT_LOADER=${app_home}/pr-loader64
    export PROOT_LOADER_32=${app_home}/pr-loader32
    # export PROOT_LOADER=${PROOT_BINARY_DIR}/pr-loader64
    # export PROOT_LOADER_32=${PROOT_BINARY_DIR}/pr-loader32

    export PROOT_TMP_DIR=${tools_dir}/tmp
    export PROOT_HOST_ABIS=`/system/bin/getprop ro.product.cpu.abilist`
    export PROOT_USER_BINFMT_DIR=/etc/binfmt.d

    # for hostrun  => 2025.06.18 放弃，只能做到从调试器脱离, 但做不到 seccomp 沙盒逃逸
    # export PROOT_NO_SECCOMP=1
    # export PROOT_HOSTRUN_LOADER=/data/user/0/com.zzvm/files/tools/ndkproot/zzhostrun-arm64

    export TMPDIR=$PROOT_TMP_DIR
fi

if [[ $PATH != *"/usr/sbin\:"* ]]
then
    export PATH=$PATH:/usr/sbin
fi
if [[ $PATH != *"/usr/local/sbin\:"* ]]
then
    export PATH=$PATH:/usr/local/sbin
fi

if [[ $PATH != *$app_home* ]]
then
    export PATH=$PATH:$app_home
fi

if [[ $PATH != *$tools_dir* ]]
then
    export PATH=$PATH:$app_home/tools
fi

function echo2apk() {
        echo $1
        echo $1>$NOTIFY_PIPE
}

export ANDROID_ART_ROOT=/apex/com.android.art
export ANDROID_DATA=/data
export ANDROID_I18N_ROOT=/apex/com.android.i18n
export ANDROID_ROOT=/system
export ANDROID_TZDATA_ROOT=/apex/com.android.tzdata
export X_DAEMON_PIPE=${app_home}/ipc/zzXio


export BOX64_NOBANNER=1
export BOX64_LOG=0
export BOX64_DYNAREC_LOG=0
export BOX64_SHOWSEGV=0
