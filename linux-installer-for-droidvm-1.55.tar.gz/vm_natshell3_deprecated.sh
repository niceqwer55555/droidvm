#!/bin/bash

: '

在公网服务器运行：
port4controller=7000 # 主控制端请主动连接这个端口
port4controllee=6000 # 被控制端请主动连接这个端口
for num in {1..5}  
do  
	nc -ll -p ${port4controller}  < tmpfifo  | nc -ll -p ${port4controllee} > tmpfifo
done  



在控制端运行：
telnet 124.221.123.125 7000
或
http://124.221.123.125:7000

gmessage -title "提示" " 请让我操作，操作完我会关闭这个弹窗 " -center &
gmessage -title "提示" " 在操作 " -center &
gmessage -title "提示" " 你放着就好 " -center &

/exbin/tools/vm_updateBootScript.sh

./ezapp/zzllq/bin/python ./tmp/dl_wps_via_playwright.py
DISPLAY= sudo ./scripts/wps.sh

重新识别U盘
/etc/autoruns/autoruns_after_gui/map_otg_udisk.sh


制作启动盘
DISPLAY= /opt/apps/mkbootudisk/mkbootudisk.sh
cd /opt/apps/qemu-linux-amd64
DISPLAY= ./qemu-linux-amd64.sh ../mkbootudisk

mkdir -p /udiskpart1
mount /dev/sda1 /udiskpart1

usbip detach -p 00

usbip attach -r 192.168.1.6 -b 1-2

unzip -oq /mnt/shared/winpe.zip -d /udiskpart1/




'

# 在安卓端启动B站app:
# ActivityName="tv.danmaku.bili/.MainActivityV2"
# virDisplayid=`adb shell dumpsys window displays|grep mDisplayId|grep -v mDisplayId=0|grep -v "organized"|awk '{ printf($2);  }'|cut -c 12-`
# am start --display $virDisplayid -S ${ActivityName}


natshell_addr=124.221.123.125
natshell_port=6000


gmessage -title "远程协助" $'\n 此功能需要联系开发者，开发者开启服务端后才能使用！ \n\n' -center  -buttons "我已联系:1,取消:0"


telnetd_port=6789




needtoDownload=0
if [ ! -x ${app_home}/ttyd.aarch64 ]; then
	needtoDownload=1
else
	${app_home}/ttyd.aarch64 -v|grep "1.6.3"
	if [ $? -eq 0 ]; then
	needtoDownload=1
	fi
fi

if [ $needtoDownload -eq 1 ]; then
	wget ${GITHUB_PROXY_HTTP}https://github.com/tsl0922/ttyd/releases/download/1.7.7/ttyd.aarch64  -O ${app_home}/ttyd.aarch64
	chmod a+x ${app_home}/ttyd.aarch64
fi

FONTSIZE=16
nohup ttyd.aarch64 -W -p ${telnetd_port} -t enableZmodem=true -t enableTrzsz=true -t fontSize=${FONTSIZE} bash  2>/tmp/ttyd.log &
sleep 1



for num in {1..60}  
do  

	socat TCP:124.221.123.125:${natshell_port} TCP:127.0.0.1:${telnetd_port} 2>/dev/null
	if [ $? -ne 0 ]; then
		echo -e "${num} 请稍等，远程协助的控制端正在启动。。。\n";
		sleep 1
	fi

done

echo "已停止连接"
