#!/bin/bash

action=$1

gui_title="fcitx补丁"

if [ "$action" == "" ]; then
	action=stop
fi

if [ "$action" == "stop" ]; then
	rm -rf ${app_home}/app_boot_config/fcitx_patch_enable
	gxmessage -title "${gui_title}" "输入法补丁已禁用，重启生效"  -center
	exit 0
else
	touch ${app_home}/app_boot_config/fcitx_patch_enable
	gxmessage -title "${gui_title}" "输入法补丁已启用，重启生效"  -center
fi
