#!/system/bin/sh


source vm_config.sh
# source ${app_home}/droidvm_vars_setup.sh





#################################################################################
echo2apk "正在生成 fake_proc"
if [ ! -f ${LINUX_FAKE_PROC_DIR}/.loadavg ]; then
    . ./setup_fake_proc.sh
fi


# ==============================================
# virgl_srv打包(cd到/exbin/virglrenderer-android/)：
# tar -czvf ../virglrenderer-android.tar.gz  .
# ==============================================

function start_virgl_srv() {
    # echo onetime>>v.txt
    # mkdir ./virglrenderer-android/
    # tar -xzvf misc/virglrenderer-android.tar.gz -C ./virglrenderer-android/
    # chmod a+x ./virglrenderer-android/bin/*
    chmod a+x ${tools_dir}/virglrenderer-android/bin/*
    
    # # ./virglrenderer-android/bin/virgl_srv --use-egl-surfaceless --use-gles 2>&1 &
    # # ${tools_dir}/virglrenderer-android/bin/virgl_test_server.cp_from_termux --socket-path="${LINUX_DIR}/tmp/.virgl_test" --use-egl-surfaceless --use-gles 2>&1 &
    # virglrenderer-android/bin/virgl_test_server.cp_from_termux --socket-path="${LINUX_DIR}/tmp/.virgl_test" --use-egl-surfaceless --use-gles 2>&1 &

    tmpfile=./svc_virgl
	cat <<- EOF > ${tmpfile}
		#!/system/bin/sh
		exec -a svc_virgl ${ALINKER64} ${tools_dir}/virglrenderer-android/bin/virgl_test_server.cp_from_termux --socket-path="${LINUX_DIR}/tmp/.virgl_test" --use-egl-surfaceless --use-gles 2>&1
	EOF
    chmod a+x ${tmpfile}
    ${ASCRIPTER} ${tmpfile} &

    # # 自己编译的，运行失败
    # # vtest_srv --socket-path="./linux/tmp/.virgl_test" --use-egl-surfaceless --use-gles 2>&1 &
}

function start_pulseaudio_srv() {
    : '
        相关环境变量
        PULSE_RUNTIME_PATH
        XDG_RUNTIME_DIR
        PULSE_CONFIG_PATH
        PULSE_STATE_PATH
    '

    rm -rf ./tmp/pulse-*


    tmpfile=./svc_audio
    if [ -d ${tools_dir}/tmx_pulseaudio ]; then
		chmod a+x ${tools_dir}/tmx_pulseaudio/*
		cat <<- EOF > ${tmpfile}
			#!/system/bin/sh
			exec -a svc_audio ${ALINKER64} ${tools_dir}/tmx_pulseaudio/pulseaudio -n --disable-shm --load="module-aaudio-sink" --load="module-native-protocol-tcp auth-anonymous=1 port=${DROIDVM_PULSEPORT}" --exit-idle-time=7200 2>&1
		EOF
    else
		chmod a+x ${tools_dir}/ndkpulseaudio/bin/*

		# # -v
		# ${tools_dir}/ndkpulseaudio/bin/pulseaudio -n --disable-shm --load="module-sles-sink" --load="module-native-protocol-tcp auth-anonymous=1" --exit-idle-time=7200 --dl-search-path=${tools_dir}/ndkpulseaudio/libs 2>&1 &

		cat <<- EOF > ${tmpfile}
			#!/system/bin/sh
			exec -a svc_audio ${ALINKER64} ${tools_dir}/ndkpulseaudio/bin/pulseaudio -n --disable-shm --load="module-sles-sink" --load="module-native-protocol-tcp auth-anonymous=1 port=${DROIDVM_PULSEPORT}" --exit-idle-time=7200 --dl-search-path=${tools_dir}/ndkpulseaudio/libs 2>&1
		EOF
    fi
    chmod a+x ${tmpfile}
    ${ASCRIPTER} ${tmpfile} &

}

function start_getifaddrs_srv() {
    if [ ! -d ${tools_dir}/getifaddrs ]; then
        return
    fi

    chmod a+x ${tools_dir}/getifaddrs/*

    # ${tools_dir}/getifaddrs/getifaddrs_bridge_server "${LINUX_DIR}/tmp/.getifaddrs-bridge" 2>&1 &

    tmpfile=./svc_netif
	cat <<- EOF > ${tmpfile}
		#!/system/bin/sh
        exec -a svc_netif ${ALINKER64} ${tools_dir}/getifaddrs/getifaddrs_bridge_server "${LINUX_DIR}/tmp/.getifaddrs-bridge" 2>&1
	EOF
    chmod a+x ${tmpfile}
    ${ASCRIPTER} ${tmpfile} &

    # 设置客户端so库为自动加载
    so_file_for_vm=${tools_dir}/getifaddrs/getifaddrs_bridge_client_lib.so
    envpath_for_vm=${LINUX_DIR}/etc/profile.d/getifaddrs_hook.sh
    if [ -f "${so_file_for_vm}" ]; then
        chmod a+x "${so_file_for_vm}"
        echo "LD_PRELOAD=/exbin/tools/getifaddrs/getifaddrs_bridge_client_lib.so" > "${envpath_for_vm}"
    fi
}

function start_vpntr_srv() {
    chmod a+x ${tools_dir}/hev-socks5-server/*
    chmod a+x ${tools_dir}/tinyproxy/*

    tmpfile=./svc_vpntr
	# cat <<- EOF > ${tmpfile}
	# 	#!/system/bin/sh
	# 	exec -a svc_vpntr ${ALINKER64} ${tools_dir}/hev-socks5-server/hev-socks5-server ${tools_dir}/hev-socks5-server/conf.conf 2>&1
	# EOF
    PROXY_PROTOCAL=socks5
    PROXY_PORT=`cat ${tools_dir}/hev-socks5-server/conf.conf|grep port:|head -n 1|awk '{print \$2}'`

	cat <<- EOF > ${tmpfile}
		#!/system/bin/sh
		exec -a svc_vpntr ${ALINKER64} ${tools_dir}/tinyproxy/tinyproxy -d -c ${tools_dir}/tinyproxy/tinyproxy.conf 2>&1
	EOF
    PROXY_PROTOCAL=http
    PROXY_PORT=`cat ${tools_dir}/tinyproxy/tinyproxy.conf|grep Port|grep -v :|head -n 1|awk '{print \$2}'`

    chmod a+x ${tmpfile}
    ${ASCRIPTER} ${tmpfile} &

    envpath_for_vm=${LINUX_DIR}/etc/profile.d/vpn2proxy.sh
    echo "export http_proxy=${PROXY_PROTOCAL}://127.0.0.1:${PROXY_PORT}" > ${envpath_for_vm}    # HTTP 流量走 SOCKS5
    echo "export https_proxy=${PROXY_PROTOCAL}://127.0.0.1:${PROXY_PORT}">>${envpath_for_vm}    # HTTPS 流量走 SOCKS5
    echo "export ALL_PROXY=${PROXY_PROTOCAL}://127.0.0.1:${PROXY_PORT}"  >>${envpath_for_vm}    # 所有流量走 SOCKS5（通用变量）
}



function generate_jwm_menu_oslist() {


    curr_osname=`basename $LINUX_DIR`
    echo ""
    echo "正在查找已安装的虚拟系统"
    echo "  \$LINUX_DIR: $LINUX_DIR"
    echo "\$curr_osname: $curr_osname"

    OSList=""
	dir_VMs=${app_home}/vm
    for osname in ${dir_VMs}/*-*; do
        echo "$osname"

        if [ ! -r $osname ]; then
            continue
        fi

        osname=`basename $osname`
        if [ "$curr_osname" == "$osname" ]; then
            continue
        fi

        OSList+="<Program label=\"重启到 $osname\" >/exbin/tools/vm_OSRebootto.sh $osname</Program>\n"
    done
    echo ""

    rm -rf ${app_home}/jwm_menu_oslist
    if [ "${OSList}" != "" ]; then
        echo '<JWM>'                                                                                                    > ${app_home}/jwm_menu_oslist
        echo '<Menu label="重启至其它系统">'                                                                            >>${app_home}/jwm_menu_oslist
        echo '<!-- Automatically generated and updated. Do not touch -->'                                               >>${app_home}/jwm_menu_oslist
        echo "${OSList}"                                                                                                >>${app_home}/jwm_menu_oslist
        echo '</Menu>'                                                                                                  >>${app_home}/jwm_menu_oslist
        echo '</JWM>'                                                                                                   >>${app_home}/jwm_menu_oslist
    else
        echo '<JWM>'                                                                                                    > ${app_home}/jwm_menu_oslist
        echo ''                                                                                                         >>${app_home}/jwm_menu_oslist
        echo '</JWM>'                                                                                                   >>${app_home}/jwm_menu_oslist
    fi

    unset osname
    unset curr_osname
    unset OSList
    unset dir_VMs
}

function generate_jwm_menu_debug_xserverOrder() {
    chmod a+x ${tools_dir}/misc/dyn_menu/*
}


function create_dir_filerecv() {

    rm -rf ${files_dir}/filerecv
    ln -s ./vm/${CURRENT_OS_NAME}/home/droidvm/Desktop ${files_dir}/filerecv

}

function get_my_internet_ip() {
    rm -rf ${app_home}/tmp/my_internet_ip.txt
    UA_WGET="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"

    URL_TO_GETIP=https://ipinfo.io/ip
    URL_TO_GETIP=http://myip.ipip.net
    for tmpi in 1 2 3 4 5
    do
		# echo2apk "第${tmpi}次 get_my_internet_ip"

        ndkwget ${URL_TO_GETIP} ${app_home}/tmp/my_internet_ip.txt  2>/dev/null
        if [ $? -ne 0 ]; then
            if [ $tmpi -ge 5 ]; then
                rm -rf ${app_home}/tmp/my_internet_ip.txt
            fi
        else
            break;
        fi
    done


}

function remove_flag_files() {
    if [ ! -d $LINUX_DIR/tmp ]; then
        mkdir -p $LINUX_DIR/tmp 2>/dev/null
    fi
    chmod 777 $LINUX_DIR/tmp

    rm -rf $LINUX_DIR/tmp/req_reboot
    rm -rf $LINUX_DIR/tmp/LinuxStarted
    rm -rf $LINUX_DIR/tmp/xstarted
    rm -rf $LINUX_DIR/tmp/enable_webctrl
    rm -rf $LINUX_DIR/tmp/zzswmgr.running
}


#################################################################################
chmod a+x ${tools_dir}/cputrans/*       2>/dev/null
chmod a+x ${tools_dir}/misc/dyn_menu/*  2>/dev/null


#################################################################################
generate_jwm_menu_oslist

# 安卓端自启动进程
#################################################################################
if [ "$VM_BOOTTYPE" == "cold" ]; then

    if [ "${HOST_CPU_ARCH}" == "arm64" ]; then
        BOOL_START_VIRGL_SERVER=`cat ${app_home}/app_boot_config/cfg_autostart_virgl_service.txt 2>/dev/null`
        BOOL_START_AUDIO_SERVER=`cat ${app_home}/app_boot_config/cfg_autostart_audio_service.txt 2>/dev/null`
        BOOL_START_IFBRG_SERVER=`cat ${app_home}/app_boot_config/cfg_autostart_ifbrg_service.txt 2>/dev/null`
        BOOL_START_VPNTR_SERVER=`cat ${app_home}/app_boot_config/cfg_autostart_vpntr_service.txt 2>/dev/null`

        if [ "$BOOL_START_VIRGL_SERVER" == "" ] || [ $BOOL_START_VIRGL_SERVER -ne 0 ]; then
            echo2apk 'starting virgl server...'
            start_virgl_srv
        fi

        if [ "$BOOL_START_AUDIO_SERVER" == "" ] || [ $BOOL_START_AUDIO_SERVER -ne 0 ]; then
            echo2apk '正在启动音频播放服务...'
            start_pulseaudio_srv
        fi

        if [ "$BOOL_START_IFBRG_SERVER" == "" ] || [ $BOOL_START_IFBRG_SERVER -ne 0 ]; then
            echo2apk '正在启动 getifaddrs 服务...'
            start_getifaddrs_srv
        else
            rm -rf ${LINUX_DIR}/etc/profile.d/getifaddrs_hook.sh
        fi

        if [ "$BOOL_START_VPNTR_SERVER" == "" ] || [ $BOOL_START_VPNTR_SERVER -ne 0 ]; then
            echo2apk '正在启动 vpn2socks5 服务...'
            start_vpntr_srv
        else
            rm -rf ${LINUX_DIR}/etc/profile.d/vpn2proxy.sh
        fi

        if [ -x ${app_home}/xlorie_quickup.sh ]; then
            echo2apk '正在启动 xserver(xlorie)...'
            source ${app_home}/xlorie_quickup.sh
        fi
    fi

    echo2apk 'chmod helper scripts...'
    chmod 755 ${tools_dir}/misc/helper/*.sh
fi

function dump_proot_cmd() {
	cat <<- EOF >proot_vmboot_cmd.sh
		#!/system/bin/sh
		# 警告！这个文件由 \${tools_dir}/startvm.sh 自动生成，重启后所有修改自动失效

		export tools_dir=\${app_home}/tools
		. \${tools_dir}/vm_config.sh

		echo ""
        echo "您可以执行以下动作："
		echo "1 启动虚拟系统"
		echo "2 仅设置proot运行环境"
		echo ""
		echo "要执行上述动作，输入对应的数字并回车即可"
		echo -n "请输入："
		read -t 180 readrlt

		case "\${readrlt}" in
			"1")
				cd \${tools_dir}
				unset LD_PRELOAD
				$command
				;;
			*)
				echo "PROOT_BINARY_DIR:      \${PROOT_BINARY_DIR}"
				echo "PROOT_LOADER:          \${PROOT_LOADER}"
				echo "PROOT_LOADER_32:       \${PROOT_LOADER_32}"
				echo "PROOT_TMP_DIR:         \${PROOT_TMP_DIR}"
				echo "PROOT_HOST_ABIS:       \${PROOT_HOST_ABIS}"
				echo "PROOT_USER_BINFMT_DIR: \${PROOT_USER_BINFMT_DIR}"
				# export PATH=\$PATH:\$PROOT_BINARY_DIR
				;;
		esac
	EOF
}

function startvm_using_proot() {

    chmod 755 ${PROOT_BINARY_DIR}/*
    # chmod 755 ${PROOT_BINARY_DIR}/loader/*

    sysvipc_function_test=`${ALINKER64} ${PROOT_BINARY_DIR}/proot --help|grep sysvipc`

    VM_HOSTNAME=`cat ${LINUX_DIR}/etc/hostname 2>/dev/null`
    if [ "$VM_HOSTNAME" == "" ]; then
        VM_HOSTNAME=DroidVM
    fi


    ANDROID_KERNEL_RELEASE=`uname -r`
    ANDROID_KERNEL_VERSION=`uname -v`
    ANDROID_KERNEL_VERSION="#1"
    # echo "ANDROID_KERNEL_VERSION: ${ANDROID_KERNEL_VERSION}"

    # '\sysname\nodename\release\version\machine\domainname\hwcap\'

    # KERNEL_STRING_WITHIN_HOSTNAME='\Linux\'"${VM_HOSTNAME}"'\'"${ANDROID_KERNEL_RELEASE}"'\'"${ANDROID_KERNEL_VERSION}"'\'"${KSTRING_VM_ARCH}"'\domainname\-1\'    # 参考：https://github.com/termux/proot/issues/80 以及 proot 源码中的 src\extension\kompat\kompat.c
    KERNEL_STRING_WITHIN_HOSTNAME="\\Linux\\${VM_HOSTNAME}\\${ANDROID_KERNEL_RELEASE}\\${ANDROID_KERNEL_VERSION}\\${KSTRING_VM_ARCH}\\domainname\\-1\\"    # 参考：https://github.com/termux/proot/issues/80 以及 proot 源码中的 src\extension\kompat\kompat.c
    # KERNEL_STRING_WITHIN_HOSTNAME='Linux DroidVM 4.14.186+ #1 SMP PREEMPT Thu Oct 19 10:39:41 CST 2023 aarch64'
    # Linux localhost 4.14.186+ #1 SMP PREEMPT Thu Oct 19 10:39:41 CST 2023 aarch64 aarch64 aarch64 GNU/Linux

    unset LD_PRELOAD
    # export PATH=${PROOT_BINARY_DIR}:$PATH
    command="${ALINKER64} ${PROOT_BINARY_DIR}/proot"
    command+=" -H"
    command+=" --kernel-release=${KERNEL_STRING_WITHIN_HOSTNAME}"
    command+=" --link2symlink"
    command+=" --kill-on-exit"
    command+=" -0"
    # command+=" --change-id=999:999"
    command+=" -r $LINUX_DIR"

    #### 注意 ####
    #########################################################################
    # proot-termux 的 --sysvipc 参数会影响 virgl, 也会影响 box64 运行 ndk() ！！！
    # 
    # 2023-08-04 确认：
    # 带 --sysvipc 参数启动proot-termux，vscode就白屏(vscoce基于Electron)
    # 带 --sysvipc 参数启动proot-termux，box64 + ndk 内存分配出错
    # 无 --sysvipc 参数启动proot-termux，vscode正常
    # 无 --sysvipc 参数启动proot-termux，box64 + ndk 内存分配也出错
    #
    # 使用自己编译的proot-userland, vscode正常
    # 使用自己编译的proot-userland, box64 + ndk 内存分配也出错, box64+wine64正常, box86+wine32正常
    #
    # 使用网上下载的proot-userland, vscode正常
    # 使用网上下载的proot-userland, box64 + ndk 正常,           box64+wine64正常, box86+wine32卡死->sendmsg not implement
    # 
    #########################################################################

	if [ -f ${app_home}/sysvipc ]; then
        if [ "${sysvipc_function_test}" != "" ]; then
            echo "有：$sysvipc_function_test"
            command+=" --sysvipc"
        else
            echo "无 --sysvipc 参数"
        fi
    fi

    ## 为了能在proot环境中使用opengles (2024.04.09添加，proot中的gl4es待测试)
    tmpdir="/apex"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/acct"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/odm"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/odm_dlkm"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/oem"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/product"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/sys"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/system"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/system_ext"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/vendor"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    tmpdir="/vendor_dlkm"; if [ -d ${tmpdir} ]; then command+=" -b ${tmpdir}"; fi
    ## end of opengles

    # ## start of vulkan test，在这里加上的话，会导致 sudo -D 失败，所以这里不能加！
    # command+=" -b ${app_home}/n"
    # ## end of vulkan

    # # uos-fake
    # if [ -f $LINUX_DIR/etc/lsb-release.uos ]; then
    #     command+=" -b $LINUX_DIR/etc/lsb-release.uos:/etc/lsb-release"
    # fi
    # if [ -f $LINUX_DIR/etc/lsb-release.uos ]; then
    #     command+=" -b $LINUX_DIR/usr/lib/os-release.uos:/usr/lib/os-release"
    # fi

    # if [ -d /linkerconfig ]; then
    command+=" -b /linkerconfig"
    # fi
    # if [ -d $LINUX_DIR/opt/apps/termux ]; then
    # command+=" -b $LINUX_DIR/opt/apps/termux:/data/data/com.termux/files"
    # fi
    command+=" -b /system -b /dev -b /:/host-rootfs"
    # command+=" -b /mnt/media_rw"
    command+=" -b /dev/urandom:/dev/random"
    command+=" -b /dev"
    command+=" -b /proc"
    # command+=" -b /proc/self/fd:/dev/fd"
    # command+=" -b /proc/self/fd/0:/dev/stdin"
    # command+=" -b /proc/self/fd/1:/dev/stdout"
    # command+=" -b /proc/self/fd/2:/dev/stderr"

    command+=" -b ${LINUX_FAKE_PROC_DIR}/.loadavg:/proc/loadavg"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.stat:/proc/stat"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.uptime:/proc/uptime"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.version:/proc/version"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.vmstat:/proc/vmstat"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.overflowgid:/proc/sys/kernel/overflowgid"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.overflowuid:/proc/sys/kernel/overflowuid"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/mounts:/proc/self/mounts"

    # command+=" -b ${LINUX_FAKE_PROC_DIR}/stat:/proc/stat"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/version:/proc/version"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/bus:/proc/bus"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/buddyinfo:/proc/buddyinfo"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/cgroups:/proc/cgroups"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/consoles:/proc/consoles"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/crypto:/proc/crypto"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/devices:/proc/devices"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/diskstats:/proc/diskstats"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/execdomains:/proc/execdomains"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/fb:/proc/fb"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/filesystems:/proc/filesystems"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/interrupts:/proc/interrupts"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/iomem:/proc/iomem"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/ioports:/proc/ioports"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/kallsyms:/proc/kallsyms"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/keys:/proc/keys"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/key-users:/proc/key-users"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/kpageflags:/proc/kpageflags"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/loadavg:/proc/loadavg"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/locks:/proc/locks"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/misc:/proc/misc"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/modules:/proc/modules"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/pagetypeinfo:/proc/pagetypeinfo"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/partitions:/proc/partitions"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/sched_debug:/proc/sched_debug"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/softirqs:/proc/softirqs"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/timer_list:/proc/timer_list"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/uptime:/proc/uptime"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/vmallocinfo:/proc/vmallocinfo"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/vmstat:/proc/vmstat"
    # command+=" -b ${LINUX_FAKE_PROC_DIR}/zoneinfo:/proc/zoneinfo"

    # # for vulkan test => 实测失败！
    # command+=" -b ${LINUX_DIR}/home"

    command+=" -b /sys"
    command+=" -b $PROOT_TMP_DIR:/dev/shm"
    command+=" -b $app_home:/exbin" # 这一行会导致ndk-vulkan-demo运行失败！ 改成在下面创建链接了，实测这样可能会导致安装不了软件，又改回了
    command+=" -b $app_home"          # 映射了这个目录后 dotnet 才可以运行！
    command+=" -b /data"
    # command+=" -b /system/fonts:/usr/share/fonts/truetype/droid"
    command+=" -b /sdcard"
    command+=" -b /storage"     # 安卓外接的otg U盘会挂在这个路径下，权限与 /sdcard 共享
    command+=" -w /"
    command+=" ${ARG_QEMU}"

    # 虚拟串口测试, id 目前只用10个，且必须<100
    for i in 0 1 2 3 4 5 6 7 8 9
    do
        tmpfn="$app_home/ipc/ttyUSB$i";
        rm -rf "${tmpfn}"
        touch  "${tmpfn}"
        command+=" -b ${tmpfn}:/dev/ttyUSB$i"
    done
    command+=" -b $app_home/ipc/serial_by-id:/dev/serial/by-id"

    # command+=" /usr/bin/env -i"
    # command+=" APP_INTERNAL_DIR=$app_home"
    # command+=" HOME=/root"
    # command+=" TMPDIR=/tmp"
    # command+=" PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games:/exbin"
    # command+=" TERM=vt100"	#不同的终端类型支持不同的功能，比如：终端文字着色，光标随意定位。。。，不设置的话不能在终端中运行 reset 指令
    # command+=" LANG=C.UTF-8"
    # command+=" APP_STDIO_NAME=${APP_STDIO_NAME}"

    command+=" $LINUX_LOGIN_COMMAND"
    # command+=" /bin/bash --login"


    # # proot有路径绑定vulkan就识别不到GPU
    # rm -rf $LINUX_DIR/exbin
    # ln -sf $app_home $LINUX_DIR/exbin

    remove_flag_files

    echo ""
    echo2apk 'starting linux bash...'

    # $command 2>&1
    # $command 2>&1 >$APP_STDIO_NAME <$APP_STDIO_NAME &
    dump_proot_cmd
    ${EXEC_PROOT} $command 2>&1
}


function startvm_using_proot_with_ndk_vulkan() {

    # 目前的测试发现，要能在proot环境中调用ndk编译的vulkan程序，需要满足两个条件：
    # 1). 以宿主的根目录做为虚拟系统的根目录 (但这样做又无权限列出根目录的文件列表)
    # 2). 不能映射这个路径：/data/user/0/com.zzvm/files (但 dotnet 却是需要这映射这个路径的)

    chmod 755 ${PROOT_BINARY_DIR}/*
    # chmod 755 ${PROOT_BINARY_DIR}/loader/*

    sysvipc_function_test=`${ALINKER64} ${PROOT_BINARY_DIR}/proot --help|grep sysvipc`

    VM_HOSTNAME=`cat ${LINUX_DIR}/etc/hostname 2>/dev/null`
    if [ "$VM_HOSTNAME" == "" ]; then
        VM_HOSTNAME=DroidVM
    fi

    ANDROID_KERNEL_RELEASE=`uname -r`
    ANDROID_KERNEL_VERSION=`uname -v`
    ANDROID_KERNEL_VERSION="#1"

    KERNEL_STRING_WITHIN_HOSTNAME="\\Linux\\${VM_HOSTNAME}\\${ANDROID_KERNEL_RELEASE}\\${ANDROID_KERNEL_VERSION}\\${KSTRING_VM_ARCH}\\domainname\\-1\\"    # 参考：https://github.com/termux/proot/issues/80 以及 proot 源码中的 src\extension\kompat\kompat.c

    remove_flag_files
    # cd ${LINUX_DIR} && ln -sf ./etc etl

    echo ""
    echo2apk 'starting linux bash...'

    export PROOT_TMP_DIR=${LINUX_DIR}/tmp
    export PROGRAM=${app_home}/main_ndk-vulkan-demo1
    # export PATH=${PROOT_BINARY_DIR}:$PATH
    command="${ALINKER64} ${PROOT_BINARY_DIR}/proot"
    command+=" -H"
    command+=" --kernel-release=${KERNEL_STRING_WITHIN_HOSTNAME}"
    command+=" --link2symlink"
    command+=" --kill-on-exit"
    command+=" -0"
    command+=" -r /"
	if [ -f ${app_home}/sysvipc ]; then
        if [ "${sysvipc_function_test}" != "" ]; then
            echo "有：$sysvipc_function_test"
            command+=" --sysvipc"
        else
            echo "无 --sysvipc 参数"
        fi
    fi
    # if [ -d $LINUX_DIR/opt/apps/termux ]; then
    # command+=" -b $LINUX_DIR/opt/apps/termux:/data/data/com.termux/files"
    # fi
    command+=" -r /"
    command+=" -0"
    command+=" -w /"
    command+=" ${ARG_QEMU}"
    ## -b ${app_home} 绑定后：
    ## 1). 无法使用 sudo -D 指令!
    ## 2). proot 环境中能成功调用vulkan
    ## 3). lx终端中cd /exbin后菜单栏打开新窗口，路径变为安卓路径
    ##
    ## -b ${app_home} 不绑定：
    ## 1). 可以使用 sudo -D 指令!
    ## 2). proot 环境中不能调用vulkan
    ## 3). lx终端中cd /exbin后菜单栏打开新窗口，路径还是 /exbin
    ##
    ## => 总算搞清楚了！
    ## ndk-vulkan程序所在的目录，对应的安卓路径，必须完全相同的映射到虚拟系统中！
    # command+=" -b ${app_home}"
    command+=" -b ${app_home}/n"
    command+=" -b ${app_home}:/exbin"
    command+=" -b ${LINUX_DIR}/lib:/lib"
    command+=" -b ${LINUX_DIR}/usr:/usr"
    command+=" -b ${LINUX_DIR}/var:/var"
    command+=" -b ${LINUX_DIR}/tmp:/tmp"
    command+=" -b ${LINUX_DIR}/etc:/system/etc"
    command+=" -b ${LINUX_DIR}/opt:/opt"
    command+=" -b ${LINUX_DIR}/run:/run"
    command+=" -b ${LINUX_DIR}/boot:/boot"
    command+=" -b ${LINUX_DIR}/sbin:/sbin"
    command+=" -b ${LINUX_DIR}/root:/root"
    command+=" -b ${LINUX_DIR}/home:/home"
    command+=" -b ${LINUX_DIR}/usr/bin/bash:/bin/bash"
    command+=" -b ${LINUX_DIR}/usr/bin/bash:/bin/sh"
    command+=" -b /dev/urandom:/dev/random"
    command+=" -b $PROOT_TMP_DIR:/dev/shm"
    # command+=" -b /proc/self/fd:/dev/fd"
    # command+=" -b /proc/self/fd/0:/dev/stdin"
    # command+=" -b /proc/self/fd/1:/dev/stdout"
    # command+=" -b /proc/self/fd/2:/dev/stderr"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.loadavg:/proc/loadavg"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.stat:/proc/stat"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.uptime:/proc/uptime"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.version:/proc/version"
    command+=" -b ${LINUX_FAKE_PROC_DIR}/.vmstat:/proc/vmstat"
    # command+=" /usr/bin/env -i"
    # command+=" APP_INTERNAL_DIR=$app_home"
    # command+=" HOME=/root TMPDIR=/tmp"
    # command+=" ENABLEVK=1"
    # command+=" PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games:/exbin"
    # command+=" TERM=vt100"
    # command+=" LANG=C.UTF-8"
    # command+=" APP_STDIO_NAME=${APP_STDIO_NAME}"

    command+=" $LINUX_LOGIN_COMMAND"
    # command+=" ${app_home}/tools/vm_init.sh"

    # $command 2>&1
    # $command 2>&1 >$APP_STDIO_NAME <$APP_STDIO_NAME &
    # cd ${app_home}
    # pwd
    unset LD_PRELOAD
    dump_proot_cmd
    ${EXEC_PROOT} $command 2>&1

}

function onVmExit() {
    # 2025.05.12 标为废弃
    set > ${app_home}/set.txt
    echo ""
    echo "虚拟机已停止"
    echo "================================"
    echo ""

    if [ -f $LINUX_DIR/tmp/req_reboot ]; then
        echo ""
        echo "正在重新启动"
        echo "================================"
        echo ""
        cd ${app_home}

        cat droidvm_vars.sh|grep "VM_BOOTTYPE=warm"
        if [ $? -ne 0 ]; then
            echo "export VM_BOOTTYPE=warm" >> droidvm_vars.sh
        fi

        exec ./droidvm_main.sh
    fi
}

echo ""
echo2apk '正在创建分享文件的接收目录...'
create_dir_filerecv


echo2apk '正在获取设备公网信息...'
get_my_internet_ip &

# 跨CPU架构的话，则启用qemu
ARG_QEMU=
function check_to_use_qemu_static() {
    if [ "${HOST_CPU_ARCH}" == "arm64" ] && [ "${CURRENT_VM_ARCH}" == "amd64" ]; then
            ARG_QEMU=" -q ./cputrans/qemu-x86_64-static"
    fi
    if [ "${HOST_CPU_ARCH}" == "amd64" ] && [ "${CURRENT_VM_ARCH}" == "arm64" ]; then
            ARG_QEMU=" -q ./cputrans/qemu-aarch64-static"
    fi
}


#################################################################################
echo "LINUX_DIR => $LINUX_DIR"
echo "${CURRENT_OS_NAME}" > ${app_home}/droidvm_vars_currosname
echo "正在以proot方式加载rootfs"

# 精简掉 startvm.sh 进程与否，实测发现使用exec 启动proot, 会导致 xlorie 端口不会释放
export EXEC_PROOT=
export EXEC_PROOT=exec
# ln -sf ${PROOT_BINARY_DIR}/proot ${app_home}/proot
if [ -f ${app_home}/app_boot_config/cfg_rootfs_sameAsHost.txt ]; then
    startvm_using_proot_with_ndk_vulkan
else
    startvm_using_proot
fi

onVmExit
