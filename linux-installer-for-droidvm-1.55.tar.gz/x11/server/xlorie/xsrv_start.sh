#!/bin/bash

echo 正在启动xserver-xlorie
echo -e "xlorie 走 x11 协议，可在小于 ${MAX_RESOLUTION} 的范围内，动态调整为任意的分辨率"
echo "#startlorie ${DISPLAY} ${VM_DPI}">$NOTIFY_PIPE
sleep 1
