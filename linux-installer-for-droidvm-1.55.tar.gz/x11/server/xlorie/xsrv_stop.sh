#!/bin/bash

echo 正在停止xserver-xlorie
echo '#vmSwitch2ConsoleMode'>${NOTIFY_PIPE}
echo "#stoplorie">$NOTIFY_PIPE
pkill -f com.zzvm:serviceX11srv
