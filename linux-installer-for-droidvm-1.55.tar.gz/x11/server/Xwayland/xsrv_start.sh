#!/bin/bash

echo -e "【仅供内部测试用】\n weston 走 wayland 协议，不支持动态调整分辨率，实测单独使用wayland很好，但套接一个xserver，就出奇的慢"
export XDG_RUNTIME_DIR=${HOME}
export WST_SCREEN_SAVETO=/exbin/ipc/Xvfb_screen0
unset WAYLAND_DISPLAY
# weston -B headless-backend.so --xwayland --use-gl --width=${RECOMMEND_SCREEN_WIDTH} --height=${RECOMMEND_SCREEN_HEIGHT} & # --scale=5 &
weston -B headless-backend.so --use-gl --width=${RECOMMEND_SCREEN_WIDTH} --height=${RECOMMEND_SCREEN_HEIGHT} >/dev/null 2>&1 & # --scale=5 &
export WAYLAND_DISPLAY=wayland-1
sleep 2

echo "正在启动xserver-xwayland"
Xwayland ${DISPLAY} +extension XTEST +extension XFIXES +extension DAMAGE -ac -dpi ${VM_DPI} &
# pidof_xserver=`pidof Xwayland`
sleep 1
