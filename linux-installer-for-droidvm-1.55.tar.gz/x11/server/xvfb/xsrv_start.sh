#!/bin/bash

echo "正在启动xserver-xvfb"
echo -e "xvfb 走 x11 协议，可在小于 ${MAX_RESOLUTION} 的范围内，动态调整任意的分辨率"
export WST_SCREEN_SAVETO=/exbin/ipc/Xvfb_screen0

# # 这几行指令会触发跟鸿蒙4.0一样的错误现象
# mkdir -p /tmp/.X11-unix/X0 2>/dev/null
# echo "ls -al /tmp/.X11-unix/"
# ls -al /tmp/.X11-unix/

# LD_LIBRARY_PATH=/gl4es-port/lib  # 可用于Xvfb，但貌似没加速作用
Xvfb +extension XTEST +extension XFIXES +extension DAMAGE +extension RANDR +extension DOUBLE-BUFFER \
-ac -listen tcp ${DISPLAY} -screen 0 ${MAX_FRAMEBUFFER_WIDTH}x${MAX_FRAMEBUFFER_HEIGHT}x24 -fbdir ${app_home}/ipc -dpi ${VM_DPI} &
# +extension GLX \
# nohup Xvfb +extension XTEST +extension XFIXES +extension DAMAGE +extension RANDR +extension DOUBLE-BUFFER \
# -ac -listen tcp ${DISPLAY} -screen 0 ${MAX_FRAMEBUFFER_WIDTH}x${MAX_FRAMEBUFFER_HEIGHT}x24 -fbdir ${app_home}/ipc -dpi ${VM_DPI} &
# -a -nocursor 

# 分辨率比较大的时候，映射fb文件耗时久一点， 所以这里比其它两个xserver多等一秒钟
sleep 0.1
# pidof_xserver=`pidof Xvfb`
# # if [ ${action} == "normal_start" ]; then
# # fi

# if [ "$pidof_xserver" == "" ]; then
# 	echo ""
# 	echo ""
# 	echo "鸿蒙4.0中不能创建 unix-socket 文件？"
# 	Xvfb +extension XTEST +extension XFIXES +extension DAMAGE +extension RANDR +extension DOUBLE-BUFFER \
# 	-ac -listen tcp -nolisten unix   ${DISPLAY} -screen 0 ${MAX_FRAMEBUFFER_WIDTH}x${MAX_FRAMEBUFFER_HEIGHT}x24 -fbdir ${app_home}/ipc -dpi ${VM_DPI} &

# 	sleep 0.1
# 	pidof_xserver=`pidof Xvfb`
# fi
