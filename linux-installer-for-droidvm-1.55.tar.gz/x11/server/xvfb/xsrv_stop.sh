#!/bin/bash

echo 正在停止xserver-Xvfb
pkill Xvfb