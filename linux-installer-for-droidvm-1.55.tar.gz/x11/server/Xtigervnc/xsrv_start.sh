#!/bin/bash

echo "正在启动xserver-tigervnc"
echo -e "Xtigervnc 走 x11协议，可在小于 ${MAX_RESOLUTION} 的范围内，动态调整任意的分辨率，改完源码测试，发现Xtigervnc不能在本地显示光标。。。"
export WST_SCREEN_SAVETO=/exbin/ipc/Xvfb_screen0
# Xtigervnc +extension XTEST +extension XFIXES +extension DAMAGE -retro ${DISPLAY} \
# -geometry ${RECOMMEND_SCREEN_WIDTH}x${RECOMMEND_SCREEN_HEIGHT} -depth 24 -dpi ${VM_DPI} +extension MIT-SHM &

Xtigervnc -nolisten unix +extension XTEST +extension XFIXES +extension DAMAGE +extension RANDR +extension DOUBLE-BUFFER -retro ${DISPLAY} \
-geometry ${MAX_FRAMEBUFFER_WIDTH}x${MAX_FRAMEBUFFER_HEIGHT} -depth 24 -dpi ${VM_DPI} +extension MIT-SHM &
# -PasswordFile /tmp/tigervnc.m4Yl5C/passwd -SecurityTypes VncAuth -auth /home/droidvm/.Xauthority &

sleep 1
