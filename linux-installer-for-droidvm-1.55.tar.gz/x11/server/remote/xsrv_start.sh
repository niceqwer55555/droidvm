#!/bin/bash

echo 正在网络上的Xserver

if [ -f /tmp/x_remote_server_addr ]; then
    x11_redirect_to=`cat /tmp/x_remote_server_addr`
fi

if [ "$x11_redirect_to" != "" ]; then
    (sleep 3;echo killing...;pkill controllee) &
    DISPLAY=${x11_redirect_to} controllee -tryxserver
    if [ $? -ne 0]; then
        echo "远端xserver连接失败：${x11_redirect_to}"
        x11_redirect_to=
        rm -rf /tmp/x_remote_server_addr
    fi

fi

