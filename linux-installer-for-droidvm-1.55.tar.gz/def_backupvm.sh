#!/system/bin/sh


source vm_config.sh


rm -rf ./backupvm.sh

mkdir -p imgbak

LINUX_TAR=imgbak/bak_${CURRENT_OS_NAME}.tar
LINUX_ZIP=imgbak/bak_${CURRENT_OS_NAME}.tar.gz
ZIP_ARG=-cf

rm -rf ${LINUX_TAR}
rm -rf ${LINUX_ZIP}

date

case "2" in
	"0")
		# 创建一个临时的 vm 来打包 rootfs, 硬链接也会打包！
		echo "正在打包"
		# echo "proot --link2symlink --kill-on-exit -0 -r $LINUX_DIR -w / -b ${tools_dir}:/exbin /exbin/tar $ZIP_ARG /exbin/$LINUX_TAR / --exclude='/proc' --exclude='dev' --exclude='/exbin' --exclude='proot' --exclude='/system/' --exclude='/apex' --exclude='/sdcard' --exclude='/tmp' 2>&1"
		#       proot --link2symlink --kill-on-exit -0 -r $LINUX_DIR -w / -b ${tools_dir}:/exbin /exbin/tar $ZIP_ARG /exbin/$LINUX_TAR / --exclude='/proc' --exclude='dev' --exclude='/exbin' --exclude='proot' --exclude='/system/' --exclude='/apex' --exclude='/sdcard' --exclude='/tmp' 2>&1

		# echo "proot --link2symlink --kill-on-exit -0 -r $LINUX_DIR -w / -b ${tools_dir}:/exbin /exbin/tar $ZIP_ARG /exbin/$LINUX_TAR / --exclude='/proc' --exclude='dev' --exclude='/exbin' --exclude='proot' 2>&1"
		#       proot --link2symlink --kill-on-exit -0 -r $LINUX_DIR -w / -b ${tools_dir}:/exbin /exbin/tar $ZIP_ARG /exbin/$LINUX_TAR / --exclude='/proc' --exclude='dev' --exclude='/exbin' --exclude='proot' 2>&1

		cat <<- EOF >  ./tmp_backup_script
			export PATH=/exbin
			tar -czf /exbin/$LINUX_ZIP / \
			--exclude=/proc \
			--exclude=/dev \
			--exclude=/exbin \
			--exclude=proot \
			--exclude=/host-rootfs \
			--exclude=/system \
			--exclude=/sdcard
		EOF
		chmod 777 ./tmp_backup_script

		command="${ALINKER64} ${PROOT_BINARY_DIR}/proot --link2symlink --kill-on-exit -0 -r $LINUX_DIR -w /"
		command+=" -b ${tools_dir}:/exbin"
		command+=" /exbin/busybox/busybox sh /exbin/tmp_backup_script"
		echo $command
		$command 2>&1
		tar_rlt=$?
		;;
	"1")
		# 创建一个临时的 vm 来打包 rootfs，不打包硬链接
		echo "正在打包"
		cat <<- EOF >  ./tmp_backup_script
			export PATH=/exbin/ndktar
			chmod a+x /exbin/ndktar/tar
			tar -czf /exbin/$LINUX_ZIP / \
			--exclude=/proc \
			--exclude=/dev \
			--exclude=/exbin \
			--exclude=proot \
			--exclude=/host-rootfs \
			--exclude=/system \
			--exclude=/sdcard \
			--hard-dereference
		EOF
		chmod 777 ./tmp_backup_script

		command="${ALINKER64} ${PROOT_BINARY_DIR}/proot --link2symlink --kill-on-exit -0 -r $LINUX_DIR -w /"
		command+=" -b ${tools_dir}:/exbin"
		command+=" /exbin/busybox/busybox sh /exbin/tmp_backup_script"
		echo $command
		$command 2>&1
		tar_rlt=$?
		;;
	*)
		# 运行快，但错误码不好判断！
		chmod a+x ${tools_dir}/ndktar/
		cat <<- EOF >  ./tmp_backup_script

			cd $LINUX_DIR
            dirtmp=\`pwd\`
            dirtmp=.
			chmod a+x ${tools_dir}/ndktar/tar
			${ALINKER64} ${tools_dir}/ndktar/tar \
			--hard-dereference \
			--exclude=\$dirtmp/acct \
			--exclude=\$dirtmp/apex \
			--exclude=\$dirtmp/dev \
			--exclude=\$dirtmp/exbin \
			--exclude=\$dirtmp/host-rootfs \
			--exclude=\$dirtmp/odm \
			--exclude=\$dirtmp/odm_dlkm \
			--exclude=\$dirtmp/oem \
			--exclude=\$dirtmp/product \
			--exclude=\$dirtmp/sdcard \
			--exclude=\$dirtmp/storage \
			--exclude=\$dirtmp/system \
			--exclude=\$dirtmp/system_ext \
			--exclude=\$dirtmp/vendor \
			--exclude=\$dirtmp/vendor_dlkm \
			--exclude=\$dirtmp/data \
			--exclude=\$dirtmp/data/user/0/com.zzvm \
            -cf ${tools_dir}/$LINUX_TAR . 

			echo "正在压缩到 ${LINUX_ZIP}"
			gzip ${tools_dir}/$LINUX_TAR
			tar_rlt=\$?
			ls -al|grep ${tools_dir}/$LINUX_TAR

		EOF
		chmod 777 ./tmp_backup_script
		. ./tmp_backup_script
	;;
esac
cd ${tools_dir}



echo tar_rlt:$tar_rlt

if [ $tar_rlt -ne 0 ]; then
    echo2apk "打包失败"
	echo -e "备份失败" > "../tmp/promptmsg.txt"
	echo2apk "#promptmsg"

    # exit_with_msg 5 "打包失败"
    # exit 5
else
    # echo "正在压缩到 ${LINUX_ZIP}"
    # gzip $LINUX_TAR
    # ls -al|grep $LINUX_TAR

    echo "备份完成"
    echo ""

    ls -al|grep $LINUX_ZIP
    rm -rf backupvm.sh
    date
    echo2apk "打包完成"

    echo "系统备份已完成.保存路径：\${tools_dir}/${LINUX_ZIP}" > $LINUX_DIR/tmp/osbackupmsg.txt

fi


