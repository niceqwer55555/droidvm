#!/bin/bash
rm -rf ${DirGuiConf}
rm -rf ~/.config/gtk2
startx xserver
