#!/bin/bash

USER_DNS_CACHE=/etc/hosts.user
rm -rf ${USER_DNS_CACHE}

rm -rf /etc/resolv.conf.force

export PRE_RESOLV_DNS_ADDRESS=1
. ${tools_dir}/vm_init_dns.sh
