#!/bin/bash

mkdir -p  /exbin/tools/imgbak
exec open /exbin/tools/imgbak
