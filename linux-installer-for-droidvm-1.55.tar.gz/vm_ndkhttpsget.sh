#!/bin/bash
fullurl=$1
filepth=$2

function usage() {
    # vm_ndkhttpsget.sh http://192.168.1.13:5559/  ~/test.html
    echo "$0    https://www.***.com/res.zip   ~/myfile.zip"
    echo "$0    https://www.***.com/res.zip   /exbin/tools/zzswmgr/downloads/myfile.zip"
    exit 1
}

if [ "$fullurl" == "" ] || [ "$filepth" == "" ] ; then
    usage
fi

filenam=`basename $filepth`
tmppath=${app_temp}/$filenam
echo "正在下载 $fullurl"
echo "保存路径 $filepth"

(cd ${tools_dir} && ${app_home}/droidexec ./vm_ndkhttpsget_internal.sh $fullurl $filenam)
httpget_rlt=$?
if [ $httpget_rlt -ne 0 ]; then
    rm -rf ${tmppath}
    exit $httpget_rlt
else
    chmod 777 ${tmppath}
    mv -f ${tmppath} $filepth
    exit $?
fi
