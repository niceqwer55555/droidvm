#!/bin/bash

: '

目前仅支持以下三种桌面环境:
pcmanfm, xfce4, kde

'


new_de="pcmanfm"
strbuttons="pcmanfm(建议):2,jwm菜单:1,取消:0"
STRTMP=$strbuttons

which startxfce4 >/dev/null 2>&1
if [ $? -eq 0 ]; then
	strbuttons="xfce4:3,"${strbuttons}
fi

which startplasma-x11 >/dev/null 2>&1
if [ $? -eq 0 ]; then
	strbuttons="kde:4,"${strbuttons}
fi

which enlightenment_start >/dev/null 2>&1
if [ $? -eq 0 ]; then
	strbuttons="enlightenment:5,"${strbuttons}
fi

which gnome-shell >/dev/null 2>&1
if [ $? -eq 0 ]; then
	strbuttons="gnome:6,"${strbuttons}
fi

which startlxde >/dev/null 2>&1
if [ $? -eq 0 ]; then
	strbuttons="lxde:7,"${strbuttons}
fi

if [ "${strbuttons}" == "${STRTMP}" ]; then
	gxmessage -title "提示"   $'\n您未安装其它桌面环境，不需要切换！\n\n如果需要使用其它桌面环境，请在软件管家中安装。\n'  -center
	exit 0
fi

gxmessage -title "桌面选择" "请选择要切换到哪个桌面环境"  -center -buttons "${strbuttons}"
case "$?" in
	"7")
		new_de="lxde"
		;;
	"6")
		new_de="gnome"
		;;
	"5")
		new_de="enlightenment"
		;;
	"4")
		new_de="kde"
		;;
	"3")
		new_de="xfce4"
		;;
	"2")
		new_de="pcmanfm"
		;;
	"1")
		jwm
		exit 0
		;;
	*)
		exit 0
		;;
esac

echo "${new_de}" > ${app_home}/app_boot_config/cfg_de.txt
startx xwinman
