#!/bin/bash

action=$1

gui_title="回收站服务进程"

if [ "$action" == "" ]; then
	action=stop
fi

if [ "$action" == "stop" ]; then
	rm -rf ${app_home}/app_boot_config/trash_enable
	gxmessage -title "${gui_title}" "回收站已禁用，重启生效"  -center
	exit 0
else

	gxmessage -title "是否启用回收站？" $'\n启用回收站后，虚拟系统中运行的进程数量会增多，部分机型上会更容易卡死\n\n确定要启用吗？\n\n'  -center -buttons "启用:0,取消:1"
	case "$?" in
		"0")
			:
			;;
		*) 
			echo "您已取消"
			exit 1
			;;
	esac

	touch ${app_home}/app_boot_config/trash_enable
	gxmessage -title "${gui_title}" "回收站已启用，重启生效。"  -center
fi

# /home/droidvm/.local/share/Trash/files
