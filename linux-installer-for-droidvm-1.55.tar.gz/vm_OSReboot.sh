#!/bin/bash

if [ "$1" == "droidconsole" ]; then
    touch /exbin/reboot_to_android_console
fi

/exbin/reboot
