#!/bin/bash

newcs=$1

if [ "${newcs}" == "" ]; then
    newcs="light"
fi

echo ${newcs}> ${PATH_VmColorscheme}


if [ "${newcs}" == "light" ]; then

    # # gtk2
    # echo "gtk-theme-name = \"Adwaita\"" > ~/.config/gtk2/gtk_theme.rc

    # gtk3
    tmpfile=/etc/gtk-3.0/settings.ini
    [ -f ${tmpfile} ] && sed -i "s|gtk-theme-name = [^\n]*|gtk-theme-name = Adwaita|"  ${tmpfile}

    # pcmanfm，，只替换匹配到的第一行
    if [ $(grep "wallpaper_mode=color" ~/.config/pcmanfm/default/desktop-items-0.conf) ]; then
        sed -i "s|desktop_bg=#[^\n]*|desktop_bg=#3C99C2|"  ~/.config/pcmanfm/default/desktop-items-0.conf
    fi

else
    # # gtk2
    # echo "gtk-theme-name = \"Adwaita-dark\"" > ~/.config/gtk2/gtk_theme.rc

    # gtk3
    tmpfile=/etc/gtk-3.0/settings.ini
    [ -f ${tmpfile} ] && sed -i "s|gtk-theme-name = [^\n]*|gtk-theme-name = Adwaita-dark|"  ${tmpfile}

    # pcmanfm，，只替换匹配到的第一行
    if [ $(grep "wallpaper_mode=color" ~/.config/pcmanfm/default/desktop-items-0.conf) ]; then
        sed -i "s|desktop_bg=#[^\n]*|desktop_bg=#222230|"  ~/.config/pcmanfm/default/desktop-items-0.conf
    fi
fi


echo "配色方案已变更,正在重启图形界面"
# export force_copy_xconf_files=1
startx xserver
