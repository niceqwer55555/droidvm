#!/bin/bash

# echo2apk "#shutdown"
echo "#shutdown" > ${NOTIFY_PIPE}
