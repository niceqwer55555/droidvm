#!/bin/bash

newdpi=$1

if [ "${newdpi}" == "" ]; then
    newdpi=150
fi

# 自定义
if [ "${newdpi}" == "custom" ]; then
    while true; do
        newdpi=$(yad --entry --title "调整屏幕dpi" --text "\n请输入新DPI值\n" --entry-text "" --validate --regex="^[0-9]+$"  --button="确定:0" --button="取消:1")
        if [ $? -ne 0 ]; then
            exit 0
        fi

        if [[ $newdpi =~ ^[0-9]+$ ]]; then
            echo "你输入的数字是: $newdpi"
            break
        else
            echo "你输入的不是数字: $newdpi"
            exit 1
        fi
    done
fi

echo ${newdpi}> ${PATH_VMDPI}

echo "DPI已变更,正在重启图形界面"
# export force_copy_xconf_files=1
startx xserver
