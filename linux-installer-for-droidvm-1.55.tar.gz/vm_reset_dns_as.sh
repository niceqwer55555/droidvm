#!/bin/bash

DNSSrv=$1
DNSCHN=$2
if [ "${DNSCHN}" == "" ]; then
    DNSCHN="udp"
fi

function apply_default_nameserver() {
	# /exbin/ipc/AndroidDnsServerList.txt 这个文件，安卓网络有变动时都会自动重新生成
	(cd /etc && ln -sf /exbin/ipc/AndroidDnsServerList.txt /etc/resolv.conf)
    rm -rf /etc/resolv.conf.force
}

if [ "${DNSSrv}" == "" ]; then

    apply_default_nameserver

    USER_DNS_CACHE=/etc/hosts.user
    rm -rf ${USER_DNS_CACHE}

    . ${tools_dir}/vm_init_dns.sh

else
	cat <<- EOF > /etc/resolv.conf.force
		nameserver ${DNSSrv}

		options single-request-reopen
		options timeout:2
		options attempts:3
		options rotate
	EOF
    if [ "${DNSCHN}" == "tcp" ]; then
	cat <<- EOF >>/etc/resolv.conf.force
		options use-vc      # 走TCP
	EOF
    fi
    
    # 如果文件是指向 /exbin/ipc/AndroidDnsServerList.txt 的链接，必须先手动删除，否则下面的复制动作会覆盖 /exbin/ipc/AndroidDnsServerList.txt
    rm -rf /etc/resolv.conf
	cp -f  /etc/resolv.conf.force  /etc/resolv.conf

fi
