#!/bin/bash


action=$1
SRVNAM=ttyd
srvprt=5559
secDelay=1
srvpid=$(pidof ttyd)
echo srvpid:$srvpid

: '
使用说明：
https://man.archlinux.org/man/extra/ttyd/ttyd.1.en

启动时加参数：

# 启用文件传输方式一
-t enableTrzsz=true		# 1.73 以上才能用

# 启用文件传输方式二
-t enableZmodem=true	# 1.73 以上才能用

-t fontSize=20


ttyd  -p 8888 -t cursorStyle=bar -t lineHeight=1.5 -t 'theme={"background": "green"}' -t fontSize=30  bash -l


传送文件需要安装：
lrzsz

'

if [ "$action" == "" ]; then
	action=stop
fi

path2ttyd=${tools_dir}/ttyd/ttyd

function download() {
	needtoDownload=0

	if [ ! -f ${path2ttyd} ]; then
		needtoDownload=1
	fi

	if [ $needtoDownload -eq 1 ]; then
		wget https://gitee.com/droidvm/ttyd/releases/download/1.7.7/ttyd.aarch64  -O ${path2ttyd}
		rlt=$?
		if [ $rlt -ne 0 ]; then
			gxmessage -title "错误" "ttyd下载失败，原因是当前无法访问github.com"  -center -fg red
			exit $rlt
		fi
	fi
	chmod a+x ${path2ttyd}
}

function stop() {
	if [ "$srvpid" == "" ]; then
		gxmessage -title "信息" "${SRVNAM}未运行"  -center
		exit 0
	else
		kill $srvpid
		rlt=$?
		if [ $rlt -ne 0 ]; then
			gxmessage -title "错误" "${SRVNAM}停止失败"  -center -fg red
			exit $rlt
		fi

		gxmessage -title "信息" "${SRVNAM}已停止"  -center
		exit $rlt
	fi
}

function start() {
	FONTSIZE=16
	if [ "$srvpid" == "" ]; then
		cd ~
		# # nohup ${path2ttyd} -p ${srvprt} -t fontSize=${FONTSIZE} bash 2>/tmp/ttyd.log &
		# # nohup ${path2ttyd} -W -p ${srvprt} -t enableZmodem=true -t enableTrzsz=true -t fontSize=${FONTSIZE} -t 'theme={"background": "green"}' bash -l 2>/tmp/ttyd.log &
		# nohup ${path2ttyd} -W -p ${srvprt} -t enableZmodem=true -t enableTrzsz=true -t fontSize=${FONTSIZE} bash -l 2>/tmp/ttyd.log &
		exec ${path2ttyd} -W -p ${srvprt} -t enableZmodem=true -t enableTrzsz=true -t fontSize=${FONTSIZE} bash -l 2>/tmp/ttyd.log
	else
		echo "已经启动"
	fi
}

function check() {
	sleep $secDelay
	srvpid=$(pidof ttyd)

	if [ "$srvpid" == "" ]; then
		gxmessage -title "错误" "${SRVNAM}启动失败"  -center -fg red
		exit
	fi

	cat <<- EOF > /tmp/ip.txt
		通过${SRVNAM}控制此模拟器
		================================
		ttyd 支持在网页端 [ 上传下载 ] 文件到当前目录中，步骤为： 
		1). 使用指令：sudo apt install -y lrzsz  安装 lrzsz
		2). 在网页终端中运行指令: rz (下载文件则使用: sz file)
		3). 选择要上传的文件

		请在电脑上使用浏览器打开以下网址
	EOF

	/exbin/tools/vm_ip2link.sh "http://" ":${srvprt}">>/tmp/ip.txt


	cat <<- EOF >> /tmp/ip.txt


		关闭这个窗口不影响功能.

	EOF

	gxmessage -title "${SRVNAM}" -file /tmp/ip.txt -center
}


case "${action}" in
	"stop")
		stop
		;;
	"start")
		download
		tmpfile=/tmp/${SRVNAM}.desktop
		cat <<- EOF > ${tmpfile}
			[Desktop Entry]
			Name=${SRVNAM}_check
			GenericName=${SRVNAM}_check
			Exec=$0 check
			Terminal=false
			Type=Application
		EOF
		xopen ${tmpfile}
		# nohup $0 check &
		# bg 	     > /tmp/bg.txt 2>&1
		# jobs     >>/tmp/bg.txt 2>&1
		# disown -a>>/tmp/bg.txt 2>&1
		start
		;;
	"check")
		check
		;;
esac

