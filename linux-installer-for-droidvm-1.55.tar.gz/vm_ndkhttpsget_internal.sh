#!/system/bin/sh
fullurl=$1
filepth=$2

function usage() {
    echo "$0    https://www.***.com/res.zip   myfile.zip"
    exit 1
}

if [ "$fullurl" == "" ] || [ "$filepth" == "" ] ; then
    usage
fi

filenam=`basename $filepth`

. ${app_home}/droidvm_vars.sh
export PATH=$PATH:${app_home}
# echo "app_home: $app_home"
# echo "app_temp: $app_temp"
# echo "    PATH: $PATH"

ndkhttpsget $fullurl $filenam 2>&1 >/dev/null
