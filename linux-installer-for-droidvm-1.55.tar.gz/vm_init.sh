#!/bin/bash -l

#不同的终端类型支持不同的功能，比如：终端文字着色，光标随意定位。。。，不设置的话不能在终端中运行 reset 指令
export TERM=vt100
export HOME=/root
export TMPDIR=/tmp
export PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games:/exbin
export LANG=C.UTF-8

if [ -x /vm_init_pre.rc ]; then
    . vm_init_pre.rc
fi

[ -d /root ] || mkdir -p /root

if [ ! -f /linkerconfig/ld.config.txt ]; then
    mkdir -p /linkerconfig 2>/dev/null
    touch /linkerconfig/ld.config.txt 2>/dev/null
    chmod 766 /linkerconfig/ld.config.txt 2>/dev/null
fi

# 删除指向 /dev/null 的无用的 ttyUSB 设备, 授权后app会自动创建
rm -rf ${app_home}/ipc/ttyUSB* 2>/dev/null

# 为虚拟系统创建APP关联的用户、用户组
. ${tools_dir}/vm_create_app_related_user.sh


# 初始化dns，让 /etc/resolv.conf 指向 /exbin/ipc/AndroidDnsServerList.txt
. ${tools_dir}/vm_init_dns.sh

if [ -f ${tools_dir}/run_once.sh ]; then
    chmod 777 ${tools_dir}/run_once.sh
    . ${tools_dir}/run_once.sh
fi

if [ -f ${tools_dir}/vm_onstarted.sh ]; then
    chmod 777 ${tools_dir}/vm_onstarted.sh
    exec ${tools_dir}/vm_onstarted.sh
else
    exec /bin/bash
fi

