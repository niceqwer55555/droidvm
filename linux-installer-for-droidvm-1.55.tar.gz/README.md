# linux-installer-for-droidvm

#### 介绍
任意安卓上使用的 proot-linux 安装脚本


#### 使用说明

1.  此仓库的脚本，需要结合droidvm.apk才能使用


#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request
