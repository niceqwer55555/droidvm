#!/bin/bash

echo "<JWM>"

	cat <<- EOF
		<TrayButton icon="chromium-browser">exec:chrome</TrayButton>
	EOF

echo "</JWM>"
