#!/bin/bash

echo "<JWM>"

IS_XVFB=" "
IS_XLOR=" "
IS_XVNC=" "

# XSrvOrder="Xvfb xlorie Xtigervnc" # Xwayland
case "${XSRV_NAME}" in
	"xlorie")
		IS_XLOR="　当前"
		;;
	"Xtigervnc")
		IS_XVNC="　当前"
		cat <<- EOF
			<Menu label="桌面截图">
				<Program label="截图　　　　　　　　　　　　">/exbin/tools/vm_screencapture.sh</Program>
			</Menu>
		EOF
		;;
	"Xvfb")
		IS_XVFB="　当前"
		cat <<- EOF
			<Menu label="桌面截图">
				<Program label="截图　　　　　　　　　　　　">/exbin/tools/vm_screencapture.sh</Program>
			</Menu>
		EOF
		;;
	*)
		exit 1
		;;
esac

cat <<- EOF
	<Menu label="XServer管理">
		<Program label="优先使用xlorie  (效率高,兼容差)${IS_XLOR}"	>/exbin/tools/vm_config_set_XSrvOrder.sh "xlorie Xvfb Xtigervnc"</Program>
		<Program label="优先使用TigerVNC(效率低,兼容好)${IS_XVNC}"	>/exbin/tools/vm_config_set_XSrvOrder.sh "Xtigervnc xlorie Xvfb"</Program>
		<Program label="优先使用Xvfb    (效率低,兼容好)${IS_XVFB}"	>/exbin/tools/vm_config_set_XSrvOrder.sh "Xvfb xlorie Xtigervnc"</Program>
		<Separator/>
		<Menu label="启动等待 (加快启动)">
			<Program label="0.1 秒"			>echo '0.1'>/exbin/app_boot_config/cfg_xserver_wait_seconds.txt</Program>
			<Program label="0.2 秒"			>echo '0.2'>/exbin/app_boot_config/cfg_xserver_wait_seconds.txt</Program>
			<Program label="0.3 秒"			>echo '0.3'>/exbin/app_boot_config/cfg_xserver_wait_seconds.txt</Program>
			<Program label="0.5 秒"			>echo '0.5'>/exbin/app_boot_config/cfg_xserver_wait_seconds.txt</Program>
			<Program label="0.7 秒"			>echo '0.7'>/exbin/app_boot_config/cfg_xserver_wait_seconds.txt</Program>
			<Program label="　1 秒 (默认)"	>echo '1'>/exbin/app_boot_config/cfg_xserver_wait_seconds.txt</Program>
		</Menu>
	</Menu>
EOF

echo "</JWM>"
