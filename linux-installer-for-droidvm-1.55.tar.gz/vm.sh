# #!/bin/bash
# function writecmd() {
#     echo "APP_STDIO_NAME: ${APP_STDIO_NAME}"
#     echo "/exbin/tools/vm_init.sh" > ${APP_STDIO_NAME}
# }
# (sleep 1; writecmd; ) &
# exec bash
