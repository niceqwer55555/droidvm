#!/bin/bash

newres=$1

if [ "${newres}" == "" ]; then
    newres="1024x768"
fi

function resize_exdisplay() {
	tmp_fbw=$1
	tmp_fbh=$2

	echo "#exDwh ${tmp_fbw} ${tmp_fbh}" > ${NOTIFY_PIPE}
}

case "$newres" in
	"1024x768")
        resize_exdisplay 1024 768
		;;
	"1366x768")
        resize_exdisplay 1366 768
		;;
    "1920x1080")
        # echo -e -n "\x0F10012;1920;1080" >/exbin/ipc/control
        resize_exdisplay 1920 1080
        ;;
	"2400x1080")
        resize_exdisplay 2400 1080
		;;
	"3840x2160")
		resize_exdisplay 3840 2160
		;;
    *)
        # echo -e -n "\x0D10012;1024x768" >/exbin/ipc/control
        resize_exdisplay 1024 768
        ;;
esac
