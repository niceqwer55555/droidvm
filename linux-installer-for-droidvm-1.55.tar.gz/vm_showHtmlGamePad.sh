#!/bin/bash

if [ ! -L "${app_home}/html/gamepad_current" ]; then
    # 给安卓用的，所以要用绝对路径
    (cd ${app_home}/html && ln -sf ${APP_INTERNAL_DIR}/tools/zzswmgr/ezapp/gamepads/4399_zmxy gamepad_current)
fi

zzllq "content://com.zzvm.sharefiles/files/html/gamepad_current/ui.html"  ""
