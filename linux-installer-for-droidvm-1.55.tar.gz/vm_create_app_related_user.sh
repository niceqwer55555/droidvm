#!/bin/bash

: '

groups: cannot find name for group ID **** 问题
https://blog.csdn.net/babytiger/article/details/112121506
https://cloud.tencent.com/developer/article/1742731
在Android中，每一个用户组都有一个唯一的ID号，定义在文件：
system\core\include\private\android_filesystem_config.h

cat /etc/group

# 代码在 setup_linux.sh 中运行，用于获取APP在安卓端的用户组列表
==============================================================================
id -G  | tr ' ' '\n'
id -Gn | tr ' ' '\n'

即：APP在安卓端对应的用户，属于这些组(在不同的安卓版本中，可能会有差异)：
==============================================================================
|    android                |   linux vm
==============================================================================
 3003	inet				# inet
 9997	everybody			# sdcard_rw
10561	u0_a561				# ??
20561	u0_a10561			# cache
50561	all_a561			# all

# addgroup --system --gid 3003  inet
# addgroup --system --gid 9997  sdcard_rw
# addgroup --system --gid $((20000+$APP_ANDROID_UID)) cache
# addgroup --system --gid $((50000+$APP_ANDROID_UID)) all_a$APP_ANDROID_UID

'




filepath_gid="${app_home}/tmp/app_groupids.txt"
filepath_gnm="${app_home}/tmp/app_groupnames.txt"
if [ -f ${filepath_gid} ] && [ -f ${filepath_gnm} ]; then

	echo '===================================='
	echo2apk '正在为虚拟系统创建APP关联的用户、用户组'
	echo '===================================='
	APP_UID=${APP_ANDROID_UID}		#   10561
	APP_NAM=${APP_ANDROID_USERNAME}	# u0_a561
	APP_GID=${APP_ANDROID_GID}		#   10561

	# 修改文件权限，以便通过直接写文件的方式添加用户、和用户组
	chmod u+rw \
		"/etc/passwd" \
		"/etc/shadow" \
		"/etc/group" \
		"/etc/gshadow" >/dev/null 2>&1 || true

	# 添加对应的用户组
	group_name=
	group_id=
	while read -u3 group_id && read -u4 group_name; do

		if [ ! $(grep "aid_${group_name}:" /etc/group) ]; then
			echo "正在创建用户组: aid_${group_name}:${group_id}"
			echo "aid_${group_name}:x:${group_id}:root,aid_${APP_NAM}"	>> "/etc/group"
		fi

		if [ -f "/etc/gshadow" ] && [ ! $(grep "aid_${group_name}:" /etc/gshadow) ]; then
			echo "aid_${group_name}:*::root,aid_${APP_NAM}"				>> "/etc/gshadow"
		fi

	done 3<${filepath_gid} 4<${filepath_gnm}
	rm -rf ${filepath_gid}   ${filepath_gnm}


	# 添加用户：messagebus
	if [ ! $(grep "messagebus:" /etc/passwd) ]; then
		echo "正在创建用户：messagebus (系统用户，不可登录)"
		useradd -U -r -s /usr/sbin/nologin -d /nonexistent  messagebus
	fi

	# 添加另外两个不知道有什么用的用户
	if [ ! $(grep "aid_${APP_NAM}:" /etc/passwd) ]; then
		echo "正在创建用户：aid_${APP_NAM}"
		echo "aid_${APP_NAM}:x:${APP_UID}:${APP_GID}:Android user:/:/sbin/nologin"	>> "/etc/passwd"
	fi
	if [ ! $(grep "aid_${APP_NAM}:" /etc/shadow) ]; then
		echo "aid_${APP_NAM}:*:18446:0:99999:7:::"									>> "/etc/shadow"
	fi

fi

