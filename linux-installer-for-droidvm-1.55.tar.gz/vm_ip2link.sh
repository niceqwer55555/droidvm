#!/bin/bash
#!/bin/bash
str_header=$1
str_tailer=$2
ndkdumpip 2>/dev/null|awk -v OFS="" -v header="${str_header}" -v tail="${str_tailer}" '{print header,$1,tail}'
