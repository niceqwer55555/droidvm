#!/bin/bash

exec open /

