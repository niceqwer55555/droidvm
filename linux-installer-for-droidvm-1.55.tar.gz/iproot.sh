#!/system/bin/sh

export tools_dir=${app_home}/tools

. ${tools_dir}/vm_config.sh


export PROOT_HOST_ABIS=`/system/bin/getprop ro.product.cpu.abilist`

export PROOT_BINARY_DIR=${tools_dir}/ndkproot
export PROOT_LOADER=${app_home}/pr-loader64
export PROOT_LOADER_32=${app_home}/pr-loader32

export PROOT_TMP_DIR=${tools_dir}/tmp
export PROOT_HOST_ABIS=`/system/bin/getprop ro.product.cpu.abilist`
export PROOT_USER_BINFMT_DIR=/etc/binfmt.d


export PATH=$PATH:$PROOT_BINARY_DIR
