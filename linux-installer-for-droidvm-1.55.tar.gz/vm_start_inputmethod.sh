#!/bin/bash

# echo "正在启动输入法"
# logfile=/tmp/start_fcitx.log
# if [ $(command -v fcitx) ]; then
#     fcitx_libdbus=/usr/lib/aarch64-linux-gnu/fcitx/fcitx-dbus.so
#     if [ ! -f ${fcitx_libdbus}.mod ]; then
#         cp -f ${fcitx_libdbus}  ${fcitx_libdbus}.mod
#         cp -f ${fcitx_libdbus}  ${fcitx_libdbus}.ori
#         sed -i "s|dbus-launch --binary-syntax|dbus-faunch --binary-syntax|g"  ${fcitx_libdbus}.mod
#     fi

#     if [ -f ${app_home}/app_boot_config/fcitx_patch_enable ]; then
#         # chmod a+x ${tools_dir}/zzswmgr/ezapp/fcitx5_dict_import_tool/dbus-faunch
#         # PATH=${tools_dir}/zzswmgr/ezapp/fcitx5_dict_import_tool:$PATH fcitx >> $logfile 2>&1 &
#         cp -f ${fcitx_libdbus}.mod  ${fcitx_libdbus}
#         fcitx -D >> $logfile 2>&1 &
#     else
#         cp -f ${fcitx_libdbus}.ori  ${fcitx_libdbus}
#         fcitx >> $logfile 2>&1 &
#     fi
# elif [ $(command -v fcitx5) ]; then
#     fcitx5 >> $logfile 2>&1 &
# else
#     gxmessage -title "输入法启动失败" "输入法启动失败，请先在软件管家中安装输入法"  -center &
# fi


echo "im">${X_DAEMON_PIPE}

# # gui_title="启动输入法"
# # logfile=/tmp/start_fcitx.log

# # # echo "">${logfile}

# # function start_fcitx() {
# #     echo "正在启动 中文输入法"
# #     # export XMODIFIERS=@im=fcitx
# #     # export GTK_IM_MODULE=fcitx
# #     # export QT_IM_MODULE=fcitx
# #     # export SDL_IM_MODULE=fcitx

# #     # # 已移到 def_run_once.sh
# #     # # dbus-uuidgen > /var/lib/dbus/machine-id
# #     fcitx >> $logfile 2>&1 &
# #     exit 0
# # }

# # # command -v fcitx && start_fcitx

# # function start_fcitx5() {
# #     echo "正在启动 中文输入法"
# #     # export XMODIFIERS=@im=fcitx
# #     # export GTK_IM_MODULE=fcitx
# #     # export QT_IM_MODULE=fcitx
# #     # export SDL_IM_MODULE=fcitx

# #     # # 已移到 def_run_once.sh
# #     # # dbus-uuidgen > /var/lib/dbus/machine-id
# #     fcitx5 >> $logfile 2>&1 &
# #     exit 0
# # }


# # # if [ "${APP_LANGUAGE}_${APP_COUNTRY}" == "zh_CN" ]; then
# # #	command -v fcitx && start_fcitx
# # # fi

# # command -v fcitx  && start_fcitx
# # command -v fcitx5 && start_fcitx5

# # gxmessage -title "${gui_title}" "输入法启动失败，请先在软件管家中安装输入法"  -center
