#!/bin/bash
cd /exbin/tools && droidexec ./svc_audio
