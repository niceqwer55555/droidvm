#!/bin/bash

newres=$1

if [ "${newres}" == "" ]; then
    newres="1024x768"
fi

function resize_screen() {
	tmp_fbw=$1
	tmp_fbh=$2

	echo "screent resizing to ${tmp_fbw} ${tmp_fbh}"

	# set -x	# echo on
	# ## 用这种方式切换分辨率，会导致 DisplayWidth() 取到的值 和 从屏幕文件中取到的 fb_width 不一致！
	# # xrandr --fb ${tmp_fbw}x${tmp_fbh}

	xrandr
	mode_name=${tmp_fbw}x${tmp_fbh}
	xrandr --newmode "${mode_name}" \
	109.00 \
	${tmp_fbw} ${tmp_fbw} ${tmp_fbw} ${tmp_fbw}  \
	${tmp_fbh} ${tmp_fbh} ${tmp_fbh} ${tmp_fbh} \
	-hsync +vsync

	if [ "${XSRV_NAME}" == "Xvfb" ] || [ "${XSRV_NAME}" == "xlorie" ]; then
		xrandr --addmode screen "${mode_name}"
	fi
	if [ "${XSRV_NAME}" == "Xtigervnc" ]; then
		xrandr --addmode VNC-0 "${mode_name}"
	fi
	xrandr -s ${mode_name}
	xrandr

	# set +x	# echo off
}


case "$newres" in
	"1024x768")
        resize_screen 1024 768
		;;
	"1366x768")
        resize_screen 1366 768
		;;
    "1920x1080")
        # echo -e -n "\x0F10012;1920;1080" >/exbin/ipc/control
        resize_screen 1920 1080
        ;;
	"2400x1080")
        resize_screen 2400 1080
		;;
	"3840x2160")
		resize_screen 3840 2160
		;;
    *)
        # echo -e -n "\x0D10012;1024x768" >/exbin/ipc/control
        resize_screen 1024 768
        ;;
esac
