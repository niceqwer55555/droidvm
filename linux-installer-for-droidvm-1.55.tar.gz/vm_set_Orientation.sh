#!/bin/bash

newOrientation=$1

if [ "${newOrientation}" == "" ]; then
    newOrientation=sz
fi

echo "#setOrientation ${newOrientation}" > ${NOTIFY_PIPE}
