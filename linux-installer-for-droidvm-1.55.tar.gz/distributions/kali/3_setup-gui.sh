#!/bin/bash

SETUP_MIN_GUI=$1

source ${tools_dir}/vm_config.sh

ANDROID_LANG="${APP_LANGUAGE}_${APP_COUNTRY}"
echo "正在安装图形界面所需的软件包"


function exit_if_fail() {
    rlt_code=$1
    fail_msg=$2
    if [ $rlt_code -ne 0 ]; then
      echo -e "错误码: ${rlt_code}\n${fail_msg}"
	  whoami
	  exec /bin/bash
      exit $rlt_code
    fi
}

function install_sw() {
  pkgnames=$@
  echo "install_sw ${pkgnames}"
  apt-get install -y ${pkgnames}
  rlt_code=$?
  if [ $rlt_code -ne 0 ]; then
    apt-get --fix-broken install -y
    rlt_code=$?
	if [ $? -ne 0 ]; then return ${rlt_code}; fi

	dpkg --configure -a
    rlt_code=$?
	if [ $? -ne 0 ]; then return ${rlt_code}; fi

    apt-get install -y ${pkgnames}
    rlt_code=$?

    return ${rlt_code}
  fi
  return ${rlt_code}
}

function setup_lang() {
    echo2apk '正在设置轻中文环境'

    echo "正在安装简体中文字体"

    echo "zh_CN.UTF-8 UTF-8">>/etc/locale.gen

    # install_sw locales ttf-wqy-microhei  # deepin 未收录 ttf-wqy-microhei
    install_sw locales fonts-wqy-zenhei
    # fc-list   #列出已经安装的字体
    # xlsfonts  #列出已经安装的字体, 与 fc-list 列出的字体列表不迥，这个指令列出的是 x11-classical 可用的字体列表
    # 字体设置文件：misc\def_xconf\uimode_phone\.jwmrc 和 misc\def_xconf\uimode_phone\cmd.conf(习惯上终端都使用等宽字体)

    locale-gen ${ANDROID_LANG}.UTF-8

	tmpfile=/etc/profile.d/droidvm.sh
	cat <<- EOF >> ${tmpfile}
		export TZ='${APP_TIMEZONE}'
		export LANG=${ANDROID_LANG}.UTF-8
		export LANGUAGE=${ANDROID_LANG}.UTF-8
		export LC_ALL=${ANDROID_LANG}.UTF-8
		export LC_CTYPE=${ANDROID_LANG}.UTF-8
		export LC_MESSAGE=${ANDROID_LANG}.UTF-8 #关联路径: /usr/share/locale/zh_CN/LC_MESSAGES/, 决定pcmanfm,jwm能否汉化
	EOF

    source /etc/profile
}

if [ "$UID" == "0" ]; then

    echo2apk '正在安装图形显示环境(约10分钟)'

    setup_lang

	echo "xfce4" > ${app_home}/app_boot_config/cfg_de.txt
    echo "export vmGraphicsx=1" >> ${app_home}/droidvm_vars_setup.sh
    echo "export vmGraphicsx=1" >> /etc/droidvm/bootup_scripts/droidvm_vars_setup.sh

    echo "xlorie">/home/droidvm/.droidvm/xserver_order.txt
    # export DEBIAN_FRONTEND=noninteractive
    # install_sw --no-install-recommends xvfb
    # exit_if_fail $? "xvfb 安装失败"

    # gxmessage # deepin 软件仓库没收录 gxmessage 这个软件
    install_sw --no-install-recommends mesa-vulkan-drivers libx11-dev libxdamage-dev libxtst-dev libxfixes-dev libxft2  x11-xserver-utils dbus-x11 command-not-found
    exit_if_fail $? "x11 扩展组件 安装失败"

	install_sw --no-install-recommends xfce4 xfce4-terminal xfce4-session xfce4-settings xfce4-panel xfwm4 xfdesktop4 thunar pavucontrol
    exit_if_fail $? "xfce4 安装失败"

	install_sw procps
    exit_if_fail $? "ps 指令安装失败"

    apt-get clean
    echo2apk '安装已完成，请重新打开app'

else
    echo "错误！你必须使用root权限运行此脚本"
fi
