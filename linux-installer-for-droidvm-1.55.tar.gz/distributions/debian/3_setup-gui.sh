#!/bin/bash

SETUP_MIN_GUI=$1

source ${tools_dir}/vm_config.sh

echo "正在安装图形界面所需的软件包"

ANDROID_LANG="${APP_LANGUAGE}_${APP_COUNTRY}"

function exit_if_fail() {
    rlt_code=$1
    fail_msg=$2
    if [ $rlt_code -ne 0 ]; then
      echo -e "错误码: ${rlt_code}\n${fail_msg}"
	  whoami
	  exec /bin/bash
      exit $rlt_code
    fi
}

function install_patches() {
    if [ "${CURRENT_VM_ARCH}" != "arm64" ]; then
        echo "只编译了arm64架构的补丁包"
        return
    fi

    # if [ "${LINUXVersionName}" == "mantic" ]; then
    #     dpkg -i ${tools_dir}/patches/${LINUX_DISTRIBUTION}/libfm*1.3.2-1*.deb
    #     exit_if_fail $? "libfm4 补丁安装失败: ${tools_dir}/patches/${LINUX_DISTRIBUTION}/libfm*1.3.2-1*.deb"
    # elif [ "${LINUXVersionName}" == "noble" ]; then
    #     dpkg -i ${tools_dir}/patches/${LINUX_DISTRIBUTION}/libfm*1.3.2-4*.deb
    #     exit_if_fail $? "libfm4 补丁安装失败: ${tools_dir}/patches/${LINUX_DISTRIBUTION}/libfm*1.3.2-4*.deb"
    # fi

}

function install_sw() {
  pkgnames=$@
  echo "install_sw ${pkgnames}"
  apt-get install -y ${pkgnames}
  rlt_code=$?
  if [ $rlt_code -ne 0 ]; then
    apt-get --fix-broken install -y
    rlt_code=$?
	if [ $? -ne 0 ]; then return ${rlt_code}; fi

	dpkg --configure -a
    rlt_code=$?
	if [ $? -ne 0 ]; then return ${rlt_code}; fi

    apt-get install -y ${pkgnames}
    rlt_code=$?

    return ${rlt_code}
  fi
  return ${rlt_code}
}

function create_bookmarks() {
    tmpbmpath=/home/droidvm/.config
    tmpbmfile=${tmpbmpath}/gtk-3.0/bookmarks
    if [ ! -f ${tmpbmfile} ]; then
        mkdir -p ${tmpbmpath}/gtk-3.0 2>/dev/null
        chmod 775 ${tmpbmpath}/gtk-3.0
        echo "file:/// 根目录"                      > ${tmpbmfile}
        echo "file:///usr/share/applications/ 软件" >>${tmpbmfile}
    else
        grep "根目录"  ${tmpbmfile}
        if [ $? -ne 0 ]; then
            echo "file:/// 根目录">> ${tmpbmfile}
        fi
        grep "软件"  ${tmpbmfile}
        if [ $? -ne 0 ]; then
            echo "file:///usr/share/applications/ 软件">> ${tmpbmfile}
        fi
    fi
}

function setup_lang() {
    echo2apk '正在设置轻中文环境'
    echo "正在安装简体中文字体"

    if [ "${LINUX_DISTRIBUTION}" == "debian" ]; then
        echo "zh_CN.UTF-8 UTF-8">>/etc/locale.gen
    fi

    install_sw locales fonts-wqy-microhei # 旧包名是 ttf-wqy-microhei
    # fc-list   #列出已经安装的字体
    # xlsfonts  #列出已经安装的字体, 与 fc-list 列出的字体列表不迥，这个指令列出的是 x11-classical 可用的字体列表
    # 字体设置文件：misc\def_xconf\uimode_phone\.jwmrc 和 misc\def_xconf\uimode_phone\cmd.conf(习惯上终端都使用等宽字体)

    locale-gen ${ANDROID_LANG}.UTF-8

	tmpfile=/etc/profile.d/droidvm.sh
	cat <<- EOF >> ${tmpfile}
		export TZ='${APP_TIMEZONE}'
		export LANG=${ANDROID_LANG}.UTF-8
		export LANGUAGE=${ANDROID_LANG}.UTF-8
		export LC_ALL=${ANDROID_LANG}.UTF-8
		export LC_CTYPE=${ANDROID_LANG}.UTF-8
		export LC_MESSAGE=${ANDROID_LANG}.UTF-8 #关联路径: /usr/share/locale/zh_CN/LC_MESSAGES/, 决定pcmanfm,jwm能否汉化
	EOF

    source /etc/profile
}

if [ "$UID" == "0" ]; then

    echo2apk '正在安装图形显示环境(约10分钟)'

    setup_lang


    # 2025.03.17 去掉后测试体积，实测发现并不能减少什么
    export DEBIAN_FRONTEND=noninteractive

    pkg2install=""
    pkg2install+=" xvfb mesa-vulkan-drivers"
    pkg2install+=" libx11-dev libxdamage-dev libxtst-dev libxfixes-dev"
    pkg2install+=" jwm pcmanfm libfm-modules libfile-mimeinfo-perl librsvg2-common"
    pkg2install+=" l3afpad curl xfce4-terminal gxmessage yad x11-xserver-utils xfonts-100dpi"
    pkg2install+=" python3-gi libasound2"

    if [ "${SETUP_MIN_GUI}" == "" ]; then
        pkg2install+=" inetutils-telnet "
        pkg2install+=" dbus-x11 xdg-utils man-db lxtask"
        pkg2install+=" gvfs"
        pkg2install+=" at-spi2-core"
        pkg2install+=" mpg123"             # 声音播放相关库
        pkg2install+=" command-not-found"
        pkg2install+=" openssh-server libgtk-3-dev"
        pkg2install+=" axel wget vim socat viewnior zip unzip xz-utils" # nomacs => viewnior
        # pkg2install+=" gnome-themes-* elementary-xfce-icon-theme  breeze-cursor-theme"
    fi

    install_sw --no-install-recommends ${pkg2install}
    exit_if_fail $? "安装失败"

    apt-get update




    # 禁用vim的鼠标拖选模式
    sed -i "s#mouse=a#mouse=#g" /usr/share/vim/vim91/defaults.vim

    rm -rf /usr/share/applications/system-config-printer.desktop

	sshd_port=5558
	mkdir -p /etc/ssh/sshd_config.d 2>/dev/null
	sed -i "/Port/d"           /etc/ssh/sshd_config
	echo "Port ${sshd_port}" > /etc/ssh/sshd_config.d/sshd_port.conf
    mkdir -p /run/sshd 2>/dev/null

    ln -s -f ${app_home}/doc/firsttime_bootmsg.txt /tmp/firsttime_bootmsg.txt

    ln -sf /usr/bin/xfce4-terminal /usr/bin/cmd
    exit_if_fail $? "cmd 安装失败"

    ln -sf /usr/bin/l3afpad /usr/bin/notepad
    exit_if_fail $? "notepad 安装失败"

    create_bookmarks
    install_patches


else
    echo "错误！你必须使用root权限运行此脚本"
fi
