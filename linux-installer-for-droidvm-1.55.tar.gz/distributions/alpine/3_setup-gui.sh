#!/bin/sh
apk add dbus-x11 jwm pcmanfm xfwm4 xfce4-terminal xmessage
