#!/bin/bash
exec setup-gui.sh min