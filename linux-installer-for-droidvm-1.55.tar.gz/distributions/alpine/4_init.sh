#!/bin/sh

source /exbin/tools/vm_config.sh

if [ ! -f /linkerconfig/ld.config.txt ]; then
    mkdir -p /linkerconfig 2>/dev/null
    touch /linkerconfig/ld.config.txt
    chmod 766 /linkerconfig/ld.config.txt
fi

export PATH=/bin:/usr/bin:/sbin:$PATH
export HOME=/

(cd /etc && ln -sf /exbin/ipc/AndroidDnsServerList.txt /etc/resolv.conf)


command -v jwm
jwm_installed=$?
if [ "${vmGraphicsx}" == "1" ] && [ $jwm_installed -ne 0 ]; then
	. ${tools_dir}/setup-gui.sh
fi

function startx() {
    echo "正在启动xserver-xlorie"
    rm -rf    ${X_DAEMON_PIPE}
    mkfifo    ${X_DAEMON_PIPE}
    chmod 777 ${X_DAEMON_PIPE}

	while true
	do
		# X_ACTION_REQ=`head -n 1 ${X_DAEMON_PIPE}`
		read X_ACTION_REQ < ${X_DAEMON_PIPE}
		rltXioRead=$?
		echo "X_ACTION_REQ: $X_ACTION_REQ"
    done

}

function start_de() {
    echo "#startlorie ${DISPLAY} ${VM_DPI}">$NOTIFY_PIPE
    sleep 1
    echo '#vmSwitch2DesktopMode'>$NOTIFY_PIPE

    jwm &
    pcmanfm --desktop &

    # ln -sf ld-musl-aarch64.so.1 ld-linux-aarch64.so.1
    # controllee -enablepc -block_size 100 -fbin /exbin/ipc/Xvfb_screen0 &
    echo ""
    echo ""
    echo "无法传送鼠标点击事件 => alpine 基于musl-libc, 没有 ld-linux-aarch64.so.1"
    xmessage "fail to transfer cick event" &
    echo ""
    echo ""

    echo 'XServerStarted' > ${NOTIFY_PIPE}
    echo 'LinuxStarted' > ${NOTIFY_PIPE}
    echo "#x11restarted" > ${NOTIFY_PIPE}


    mkdir -p ~/Desktop 2>/dev/null
	cat <<- EOF > ~/Desktop/terminal.desktop
		[Desktop Entry]
		Encoding=UTF-8
		Version=0.9.4
		Type=Application
		Name=cmd
		Terminal=false
		Categories=System;
		Exec=xfce4-terminal -e sh
		Path=~/
	EOF

    rm -rf ${APP_FILENAME_URLTOOLS}
    rm -rf ${app_home}/app_boot_config/cfg_bootup_wait_seconds.txt
}

export DISPLAY=:4
export VM_DPI=200
startx &
start_de

echo "输入t, 并回车启动telnetd"
exec /bin/sh
