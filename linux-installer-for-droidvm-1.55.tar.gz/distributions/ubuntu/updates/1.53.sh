#!/bin/bash

source ${tools_dir}/vm_config.sh

function install_sw() {
  pkgnames=$@
  echo "正在补装软件 ${pkgnames}"
  apt-get install -y ${pkgnames}
  rlt_code=$?
  if [ $rlt_code -ne 0 ]; then
    apt-get --fix-broken install -y
    rlt_code=$?
	if [ $? -ne 0 ]; then return ${rlt_code}; fi

	dpkg --configure -a
    rlt_code=$?
	if [ $? -ne 0 ]; then return ${rlt_code}; fi

    apt-get install -y ${pkgnames}
    rlt_code=$?

    return ${rlt_code}
  fi
  return ${rlt_code}
}

echo ""
echo "正在拉取仓库中的软件列表"
apt-get update -y

# 图形界面相关的修补
if [ "${vmGraphicsx}" == "1" ]; then
	swname=l3afpad
	command -v $swname || install_sw $swname

	swname=lxtask
	command -v $swname || install_sw $swname

	swname=mpg123
	command -v $swname || install_sw $swname

	swname=xfce4-terminal
	command -v $swname || install_sw --no-install-recommends $swname



	echo "正在修补文件链接"
	(cd /usr/bin && ln -sf python3  python)
	(cd /usr/bin && ln -sf l3afpad  notepad)
	(cd /usr/bin && ln -sf xfce4-terminal  cmd)


	echo "正在修补文件关联和启动图标"
	sed -i "s|L3afpad|notepad|" /usr/share/applications/l3afpad.desktop
	sed -i 's#lxterminal#cmd#g' /home/droidvm/Desktop/terminal.desktop
	sed -i 's#LX终端#xf终端#g'  /home/droidvm/Desktop/terminal.desktop

	[ ! -f /usr/share/code/resources/app/resources/linux/code.png ] || cp -f /usr/share/code/resources/app/resources/linux/code.png   /usr/share/pixmaps/   2>&1  >/dev/null


	echo "正在添加收藏夹"
	tmpbmpath=/home/droidvm/.config
	tmpbmfile=${tmpbmpath}/gtk-3.0/bookmarks
	if [ ! -f ${tmpbmfile} ]; then
		mkdir -p ${tmpbmpath}/gtk-3.0 2>/dev/null
		chmod 775 ${tmpbmpath}/gtk-3.0
		echo "file:/// 根目录"> ${tmpbmfile}
		echo "file:///usr/share/applications/ 软件">> ${tmpbmfile}
	else
		grep "根目录"  ${tmpbmfile}
		if [ $? -ne 0 ]; then
			echo "file:/// 根目录">> ${tmpbmfile}
		fi
		grep "软件"  ${tmpbmfile}
		if [ $? -ne 0 ]; then
			echo "file:///usr/share/applications/ 软件">> ${tmpbmfile}
		fi
	fi


	# 移除旧版本中输入法的自启动文件(会导致 x11-daemon 退出，进而旋转屏幕后无法点击鼠标左右键！)
	[ ! -f /etc/autoruns/services_after_gui/fcitx.sh ] || rm -rf /etc/autoruns/services_after_gui/fcitx.sh
	[ ! -f /etc/autoruns/autoruns_after_gui/fcitx.sh ] || rm -rf /etc/autoruns/autoruns_after_gui/fcitx.sh

	# 2024.06.17 移除 /etc/apt/sources.list  和 /etc/apt/sources.list.bak.tsinghua 中的 ports.ubuntu.com
	sed -i 's|ports.ubuntu.com|mirrors.tuna.tsinghua.edu.cn|g'	/etc/apt/sources.list
	sed -i 's|ports.ubuntu.com|mirrors.tuna.tsinghua.edu.cn|g'	/etc/apt/sources.list.bak.tsinghua


	# 1.43 及以后可以去掉
	cat <<- EOF > /exbin/777
	#!/bin/bash
	echo "正在重置桌面环境为 pcmanfm"
	echo "pcmanfm">/exbin/app_boot_config/cfg_de.txt
	EOF
	chmod a+x /exbin/777


fi

# sudo 相关的修补
if [ 1 -eq 1 ]; then
	# 修复部分rootfs中droidvm用户不能运行sudo su的问题
	chown root:root /usr/bin/sudo
	chmod 4755 /usr/bin/sudo
	chown root:root /etc/sudo.conf
	chown root:root /etc/sudoers.d
	chmod 4755 /etc/sudoers.d
	chown root:root /run/sudo/ts
	chmod 4755 /run/sudo/ts

	# 2024.10.13 处理 sudo -D 选项无权限使用的问题
	: ' sudoers 文件格式说明
		A       B     = {C}                        {D}                  E
		username  hosts  = target_username/groupt     pwd_required         enabled_commands
		第一部分A代表授权使用sudo的用户或者组
		第二部分B代表允许授权用户在哪些主机上使用这些权利
		第三部分C代表允许被授权用户提权到什么用户什么组级别的权限，如果省略就代表允许提权到任意用户级别。
		第四部分D代表当被授权用户是否需要输入自身密码来使用特权，若省略这代表需要输入密码
		第五部分E代表允许执行的命令，如果是all就代表允许执行所有命令
	'
	chmod 4660											  /etc/sudoers.d/droidvm
	echo 'Defaults:USERLIST   runcwd=*'					> /etc/sudoers.d/droidvm
	echo 'User_Alias  USERLIST = droidvm,ubuntu'		>>/etc/sudoers.d/droidvm
	echo '%droidvm   ALL=(ALL:ALL)           ALL'		>>/etc/sudoers.d/droidvm
	# echo '%droidvm   ALL=(ALL:ALL) NOPASSWD: ALL'		>>/etc/sudoers.d/droidvm
	chmod 4440											  /etc/sudoers.d/droidvm
fi

# sshd 相关的修补(2025.04.24)
if [ 1 -eq 1 ]; then
	sshd_port=5558

	# 原来用这个配置文件，以后不用了
	sed -i "/${sshd_port}/d" /etc/default/ssh

	# 已改用这个配置文件：/etc/ssh/sshd_config
	mkdir -p /etc/ssh/sshd_config.d 2>/dev/null
	sed -i "/Port/d"           /etc/ssh/sshd_config
	echo "Port ${sshd_port}" > /etc/ssh/sshd_config.d/sshd_port.conf

	# 运行时依赖
	mkdir -p /run/sshd 2>/dev/null
fi

# 旧版自启动项处理
if [ 1 -eq 1 ]; then
	[ ! -f /etc/autoruns/installed_sw_env.sh ] || mv -f /etc/autoruns/installed_sw_env.sh /etc/profile.d/installed_sw_env-1.52.sh 2>/dev/null
	rm -rf /etc/autoruns/vm_runtime_env.sh 2>/dev/null
	# sed -i "/\/etc\/profile/d" /home/droidvm/.bashrc
	# sed -i "/export PS1/d" /etc/profile

	if [ ! -f /etc/profile.d/droidvm.sh ]; then
		mkdir -p /etc/profile.d 2>/dev/null
		tmpfile=/etc/profile.d/droidvm.sh
		echo "source /exbin/tools/vm_config.sh"								> $tmpfile
		echo "alias unlink=rm"												>>$tmpfile
		echo "alias ls='ls --color=auto'"									>>$tmpfile
		echo "export PS1='"'\[\e]0;\u@\h: \w\a\]${debian_chroot:+($debian_chroot)}\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '"'" >>$tmpfile
		chmod 750 $tmpfile
	fi
fi

# 下面的就留在最后面
if [ 1 -eq 1 ]; then
	echo ""
	echo "正在更新开始菜单"
	cp -f ${tools_dir}/misc/def_xconf/common/menu.jwmrc   ${DirBakConf}/common/menu.jwmrc

	echo ""
	echo "正在更新 map_otg_udisk.sh"
	cp -f /exbin/autoruns/autoruns_after_gui/map_otg_udisk.sh /etc/autoruns/autoruns_after_gui/map_otg_udisk.sh

	echo ""
	echo "正在更新 systemctl"
	cp -f /exbin/tools/zzswmgr/ezapp/systemctl/systemctl.sh  /usr/bin/systemctl
	chmod a+x /usr/bin/systemctl
	DIR_SERVICE_AUTOSTART=/etc/systemd/system/multi-user.target.wants
	BAK_SERVICE_AUTOSTART=/etc/systemd/system/multi-user.target.wants.bak
	if [ ! -d ${BAK_SERVICE_AUTOSTART} ]; then
		rm -rf ${BAK_SERVICE_AUTOSTART} 2>/dev/null
		mv -f ${DIR_SERVICE_AUTOSTART}  ${BAK_SERVICE_AUTOSTART}
		[ $? -ne 0 ] || echo "安装失败，无法备份 systemd 自启动脚本目录"

	fi
	if [ ! -d ${DIR_SERVICE_AUTOSTART} ]; then
		rm -rf ${DIR_SERVICE_AUTOSTART} 2>/dev/null
		mkdir -p ${DIR_SERVICE_AUTOSTART} 2>/dev/null
		[ $? -ne 0 ] || echo "安装失败，无法创建 systemd 自启动脚本目录"
	fi
	rm -rf ${DIR_SERVICE_AUTOSTART}/* 2>/dev/null

fi

# 删除当前脚本自身 ${tools_dir}/distributions/${LINUX_DISTRIBUTION}/updates/x-xx.sh
mv -f $0 $0.bak
