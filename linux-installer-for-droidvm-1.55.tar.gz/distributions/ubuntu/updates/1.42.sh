#!/bin/bash

source ${tools_dir}/vm_config.sh

if [ "${vmDistribution}" != "ubuntu" ]; then
	echo "当前系统不是 ubuntu，不执行 updates/*.sh"
	exit 0
fi

(cd /usr/bin && ln -sf cmd  cmd)
(cd /usr/bin && ln -sf python3     python)


swname=xclip
which ${swname} >/dev/null 2>&1
if [ $? -ne 0 ]; then
	echo ""
	echo "正在补装软件: ${swname}"
	apt-get install -y ${swname}
fi

swname=l3afpad
which ${swname} >/dev/null 2>&1
if [ $? -ne 0 ]; then
	echo ""
	echo "正在补装软件: ${swname}"
	apt-get install -y ${swname}
    # ln -sf /usr/bin/l3afpad /usr/bin/notepad
	(cd /usr/bin && ln -sf l3afpad  notepad)
fi
sed -i "s|L3afpad|notepad|" /usr/share/applications/l3afpad.desktop

swname=lxtask
which ${swname} >/dev/null 2>&1
if [ $? -ne 0 ]; then
	echo ""
	echo "正在补装软件: ${swname}"
	apt-get install -y ${swname}
fi

swname=mpg123
which ${swname} >/dev/null 2>&1
if [ $? -ne 0 ]; then
	echo ""
	echo "正在补装软件: ${swname}"
	apt-get install -y ${swname}
fi


cp -f /usr/share/code/resources/app/resources/linux/code.png   /usr/share/pixmaps/   2>&1  >/dev/null

# cat <<- EOF >> ${app_home}/667
# 	#!/bin/bash
# 	echo "正在测试网络"
# 	ps ax
# EOF

tmpbmpath=/home/droidvm/.config
tmpbmfile=${tmpbmpath}/gtk-3.0/bookmarks
if [ ! -f ${tmpbmfile} ]; then
	mkdir -p ${tmpbmpath}/gtk-3.0 2>/dev/null
	chmod 775 ${tmpbmpath}/gtk-3.0
	echo "file:/// 根目录"> ${tmpbmfile}
	echo "file:///usr/share/applications/ 软件">> ${tmpbmfile}
else
	grep "根目录"  ${tmpbmfile}
	if [ $? -ne 0 ]; then
		echo "file:/// 根目录">> ${tmpbmfile}
	fi
	grep "软件"  ${tmpbmfile}
	if [ $? -ne 0 ]; then
		echo "file:///usr/share/applications/ 软件">> ${tmpbmfile}
	fi
fi


# 移除旧版本中输入法的自启动文件(会导致 x11-daemon 退出，进而旋转屏幕后无法点击鼠标左右键！)
if [ -f /etc/autoruns/services_after_gui/fcitx.sh ]; then
	rm -rf /etc/autoruns/services_after_gui/fcitx.sh
fi

if [ -f /etc/autoruns/autoruns_after_gui/fcitx.sh ]; then
	rm -rf /etc/autoruns/autoruns_after_gui/fcitx.sh
fi

# 2024.06.17 移除 /etc/apt/sources.list  和 /etc/apt/sources.list.bak.tsinghua 中的 ports.ubuntu.com
sed -i 's|ports.ubuntu.com|mirrors.tuna.tsinghua.edu.cn|g'	/etc/apt/sources.list
sed -i 's|ports.ubuntu.com|mirrors.tuna.tsinghua.edu.cn|g'	/etc/apt/sources.list.bak.tsinghua

# 2024.10.13 处理 sudo -D 选项无权限使用的问题
chmod 4660									      /etc/sudoers.d/droidvm
  echo 'Defaults:USERLIST   runcwd=*'			> /etc/sudoers.d/droidvm
  echo 'User_Alias  USERLIST = droidvm,ubuntu'  >>/etc/sudoers.d/droidvm
  echo '%droidvm   ALL=(ALL:ALL)           ALL' >>/etc/sudoers.d/droidvm
# echo '%droidvm   ALL=(ALL:ALL) NOPASSWD: ALL' >>/etc/sudoers.d/droidvm
chmod 4440									      /etc/sudoers.d/droidvm

# 1.43 及以后可以去掉
cat <<- EOF > /exbin/777
#!/bin/bash
echo "正在重置桌面环境为 pcmanfm"
echo "pcmanfm">/exbin/app_boot_config/cfg_de.txt
EOF
chmod a+x /exbin/777


echo ""
echo "正在更新开始菜单"
cp -f ${tools_dir}/misc/def_xconf/common/menu.jwmrc   ${DirBakConf}/common/menu.jwmrc

mv -f $0 $0.bak
