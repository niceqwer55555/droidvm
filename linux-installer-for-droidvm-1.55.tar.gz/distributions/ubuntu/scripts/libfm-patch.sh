#!/bin/bash

SWNAME=libfm

action=$1
if [ "$action" == "" ]; then action=安装; fi

# pwd
. ./scripts/common.sh

if [ "${action}" == "卸载" ]; then
	echo "不支持卸载."
  exit 1
else
  ls -al /exbin/tools/patchs/arm64/libfm*1.3.2-4*.deb
  if [ $? -ne 0 ]; then
    echo ""				> /tmp/msg.txt
    echo "请先更新ndktools，操作如下："	>>/tmp/msg.txt
    echo "开始->控制台->ndktools->重新下载"	>>/tmp/msg.txt
    echo ""				>>/tmp/msg.txt
    gxmessage -title "提示" -file /tmp/msg.txt -center
    exit 1
  fi

	apt-get install -y /exbin/tools/patchs/arm64/libfm*1.3.2-4*.deb   --allow-downgrades
  exit_if_fail $? "安装失败"

  echo "安装完成."
  gxmessage -title "提示" "安装完成，重启生效！"  -center
fi
