#!/bin/bash

SWNAME=mesa-turnip

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1
	sudo apt-get purge --auto-remove -y mesa-vulkan-drivers
else

	: '
	MESA_LOADER_DRIVER_OVERRIDE=zink
	VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/freedreno_icd.aarch64.json
	TU_DEBUG=noconform

	其它环境变量：
	export MESA_LOADER_DRIVER_OVERRIDE=zink
	export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/freedreno_icd.aarch64.json
	export TU_DEBUG=noconform
	export DXVK_HUD=1

	export MESA_NO_ERROR=1
	export MESA_GL_VERSION_OVERRIDE=4.3COMPAT
	export MESA_GLES_VERSION_OVERRIDE=3.2
	export GALLIUM_DRIVER=zink
	export ZINK_DESCRIPTORS=lazy

	'

	. ${app_home}/hwinfo.rc
	IS_ADRENO_GPU=0
	if [[ "${device_gpu_name}" == *"dreno"* ]]; then
		IS_ADRENO_GPU=1
	fi
	if [ $IS_ADRENO_GPU -ne 1 ]; then
		echo "当前设备的GPU不是骁龙系列，装了也没用"
		exit 2
	fi

	echo "正在解析下载站域名"
	#  ppa.launchpadcontent.net  launchpadcontent.net launchpad.net
	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh launchpad.proxy.ustclug.org`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	[ -d /etc/apt/sources.list.d ] || mkdir -p /etc/apt/sources.list.d
	exit_if_fail $? "/etc/apt/sources.list.d 目录创建失败"

	# 公钥前面的空格，不能去掉！
	cat <<- EOF > /etc/apt/sources.list.d/ppa-mesa-turnip-kgsl.sources
		Types: deb
		URIs: https://ppa.launchpadcontent.net/mastag/mesa-turnip-kgsl/ubuntu/
		Suites: noble
		Components: main
		Signed-By: 
		 -----BEGIN PGP PUBLIC KEY BLOCK-----
		 .
		 mQINBGZ+uIsBEADKS8ErQH710ZrSD7QFenRbE6xPu1wAPN11XGJFG9kufg3owybw
		 iDe8EvWDzSxlxhGbhQwJk5PTgxCIOzRPthiaq6JJG+6FsltfiPc1NmaJ5HDqOawh
		 KVfQ+CTdnhVeSuw9QGU3tK3AuCmqDTmQbO3brve3Q58zgk+j7YU13dh34ravHSxV
		 rqV7ZUKNWNQUzV9WcrGSHALKLAFI4NIvK+e5Ok36cxSY2cP/B75eTkLErGr9Aqoq
		 iV/Zo05Uk70DnOjvs7Jaq2WIRX69EHujsiXxBYvnrHHiTPrJNaMvkpy8aZWyvaAz
		 c7BlIYNjIOztiJXnjRpHPQqnhIAzY6axS1Afize1l5HgcWoPBwhNmWOlwvxcgvqL
		 mykAZZOmZ24PHW7+oQWE3qhSSV3WoAYy3PAHWDR8Hh03TtN42hXPXAxPGxH3SdO2
		 BYtjjBSV3PhrAeouqhicS/nUP+Z/d839mBYny49gk/lIYu6p63jJlbO7EkVLsQ57
		 sBPL6MPb9Ar5XZ3B6uTVv61JuRqFdcx/sdiRF2moReWeGgvOtpNoWkbNP11gMy2e
		 t9mDN6pXG/ltf0+fxmkHqwF1+MbrTzyYW58cU7O7zrny9I+J8SyeriseZiyPMpPg
		 uCOdPY6E2HZZ6h2m+DblZbIw7smToI/WmBmlYpmOnUN4ZC3rq4ZU+qlo7QARAQAB
		 tBhMYXVuY2hwYWQgUFBBIGZvciBNYXN0YUeJAk4EEwEKADgWIQQVjmp96MpqkHX9
		 jEAQJ1FdAw8TEAUCZn64iwIbAwULCQgHAgYVCgkICwIEFgIDAQIeAQIXgAAKCRAQ
		 J1FdAw8TEA25D/0SnBN063+uAwz+jrSVRjfWzmACRGpLRusVxMh/tsKw+L/i54iR
		 ddukmuzgZQEuhvswdM0MDGF3dqVD64zYsPrZoF8/ff8J1MOQEJ6CK4j9URAXxGFw
		 qaVR/XRyr3wcFQBycOySh+bM1T3a39WhqDjJ4GZ9tLFXxD4gmLa9USm/PjXvTmhM
		 em45KOG9yNMIdqYOoeox4P+vlyy8AZiz0T2+i27rK7QhgJNRRWrtL/r5nNWaG98Z
		 9mRJiNwhbmr3M1ZOZ1UtFpdRu4w/8Cl5gYHFDOo2tuq0Mgu435mMk8qxLlOfVHTw
		 RmwP6sE9Y2DL1tmTvHurPCg82WsH8Ol3IU6YKNzyNnOgLx5M79Bz+CPCAyKQsDhy
		 Wo/8WB8vVRwaeO3RRidg1eltHZY2/lnL4mhVSbl5QmFWeh1AfOO3FUw7RyjGV9+S
		 W2TMZqynlDsM8P2lhfeUHzf83/qz/MGZFJa0D57jELLuc0PLHsw1qQRLmgcxGWuH
		 ItIv96r45hcxqt21fEz7KSnT7WiUH7uk3CyyQTtPNQ3tqYffNYN+R87c5bCIOTK6
		 7o3KpxAHLRt2p/c7vycLdwWvlAsOcGZP3kSQv/bhpORFY9VVINA3Q6e2037CqhPU
		 wMwoon5MLWjznM12iAD8zvUFHUCdd4zZ5M+vSc9BnrSYaq9aPCKc8VmyAg==
		 =/HaP
		 -----END PGP PUBLIC KEY BLOCK-----
	EOF
	exit_if_fail $? "三方ppa仓库添加失败"

	# 国内能找到的惟一的镜像 for: ppa.launchpadcontent.net 
	sed -i "s|ppa.launchpadcontent.net|launchpad.proxy.ustclug.org|" /etc/apt/sources.list.d/ppa-mesa-turnip-kgsl.sources
	exit_if_fail $? "三方ppa仓库加速失败"

	sudo apt-get update -y
	exit_if_fail $? "三方ppa仓库无法访问"

	sudo apt-get install -y mesa-vulkan-drivers glmark2-x11
	exit_if_fail $? "安装失败"

	rm -rf /etc/apt/sources.list.d/ppa-mesa-turnip-kgsl.sources

	gxmessage -title "提示" "安装已完成"  -center &
	exit 0
fi
