#!/bin/bash

: '

'

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

SWNAME=mobox
SWVER=1.8.19

# 注意安装顺序，后装者依赖前装者
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

TERMUX__PREFIX=/data/data/com.termux/files/usr
WBOXUSR=${TERMUX__PREFIX}
WINE_HOME_P=${ZZ_USER_HOME}/.wine
WINE_HOME_O=${APP_INTERNAL_DIR}/vm/${CURRENT_OS_NAME}${WINE_HOME_P}

# mobox 预编译好的软件包列表
===================================================
WBOX_WINE=wine-9.3-vanilla-wow64
WBOX_PKGS="box64-binaries dxvk glibc-prefix prefix-apps scripts turnip virgl-mesa wined3d libudev en-ru-locale ${WBOX_WINE}"
# for SW_ITEM in ${WBOX_PKGS}; do
# 	PKGNAME="${SW_ITEM}.tar.xz"
# 	echo "https://gitlab.com/api/v4/projects/54240888/repository/files/$PKGNAME/raw?ref=main"
# done


function wboxDownload() {
  filesaveto=$1
  url=$2
  echo "正在下载：${filesaveto} <= ${url}"
  tmp_wdir=`pwd`
  echo "工作目录：${tmp_wdir}"
  echo "保存路径：${filesaveto}"
  if [ -f ${filesaveto}.downloading ]; then echo "上次未完整下载，正在删除临时文件后重新下载"; rm -rf ${filesaveto}; else touch ${filesaveto}.downloading ;fi
	#[ -f ${filesaveto} ] || wget -q --retry-connrefused --tries=0 --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" "${url}" -O ${filesaveto}
	 [ -f ${filesaveto} ] || wget -q --retry-connrefused --tries=0 "${url}" -O ${filesaveto}
  rlt_code=$?
  if [ $rlt_code -ne 0 ]; then
    rm -rf "${filesaveto}" 2>/dev/null
  fi
  rm -rf ${filesaveto}.downloading

  return ${rlt_code}
}

function create_files() {

	(cd ${WBOXUSR}/glibc/etc &&  ln -sf ../../etc/resolv.conf  ./resolv.conf)

	echo "调整文件夹权限"
	chown droidvm -R ${WBOXUSR}/glibc
	chmod a+x     -R ${WBOXUSR}/glibc
	chmod a+x		 ./ezapp/wbox/wbox.sh
	chmod +x         ${WBOXUSR}/glibc/bin/box64
	chmod +x         ${WBOXUSR}/glibc/${WBOX_WINE}/bin/{wine,wineserver}

	mkdir -p ${WBOXUSR}/glibc/opt/package-manager 2>/dev/null


    echo "正在生成 wine-DPI设置文件"
	cat <<- EOF > ${WBOXUSR}/glibc/opt/prefix/dpi.reg
		REGEDIT4

		[HKEY_CURRENT_USER\Software\Wine\Fonts\Replacements]
		"DFKai-SB"="WenQuanYi Micro Hei"
		"FangSong"="WenQuanYi Micro Hei"
		"KaiTi"="WenQuanYi Micro Hei"
		"Microsoft JhengHei"="WenQuanYi Micro Hei"
		"Microsoft YaHei"="WenQuanYi Micro Hei"
		"MingLiU"="WenQuanYi Micro Hei"
		"SimSun"="WenQuanYi Micro Hei"
		"PMingLiU"="WenQuanYi Micro Hei"
		"SimHei"="WenQuanYi Micro Hei"
		"SimKai"="WenQuanYi Micro Hei"
		"SimSun"="WenQuanYi Micro Hei"


		[HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\FontLink\SystemLink]
		"Lucida Sans Unicode"="WenQuanYi Micro Hei"
		"Microsoft Sans Serif"="WenQuanYi Micro Hei"
		"MS Sans Serif"="WenQuanYi Micro Hei"
		"Tahoma"="WenQuanYi Micro Hei"
		"Tahoma Bold"="WenQuanYi Micro Hei"
		"SimSun"="WenQuanYi Micro Hei"
		"Arial"="WenQuanYi Micro Hei"
		"Arial Black"="WenQuanYi Micro Hei"

		[HKEY_LOCAL_MACHINE\System\CurrentControlSet\Hardware Profiles\Current\Software\Fonts]
		"LogPixels"=dword:00000090
	EOF

}

#region elfPatch for glibc

	# termux path to zzvm path, 处理结果保存在变量 ${ZPATH} 中
	function tpath2zpath() {
		tmpstr=$1
		unset ZPATH
		if [[ "$tmpstr" == "" ]]; then
			return
		fi
		if [[ "$tmpstr" != *"com.termux/files"* ]]; then
			return
		fi
		ZPATH="$tmpstr"

		# dststr="/data/user/0/com.zzvm/files/z"

		# srcstr1="/data/data/com.termux/files"
		# srcstr2="/data/user/0/com.termux/files"
		# if [[ "$tmpstr" == *"${srcstr1}"* ]]; then
		# 	ZPATH=${tmpstr//${srcstr1}/\/data\/user\/0\/com.zzvm\/files\/z}
		# elif [[ "$tmpstr" == *"${srcstr2}"* ]]; then
		# 	ZPATH=${tmpstr//${srcstr2}/\/data\/user\/0\/com.zzvm\/files\/z}
		# fi
	}

	# 返回值保存在 ${INTERPRETER} 变量中
	function get_val_from_var_fileinfo_interpreter() {
		unset INTERPRETER
		if [[ "$fileinfo" == *", interpreter "* ]]; then
			INTERPRETER=${fileinfo##*interpreter }
			INTERPRETER=${INTERPRETER%%,*}
		fi
	}

	# 返回值保存在 ${RPATH} 变量中
	function get_val_from_var_fileinfe_rpath() {
		unset RPATH
		if [[ "$fileinfe" == *"Library rpath:"* ]]; then
			RPATH=`echo "$fileinfe"|grep "Library rpath:"`
			RPATH=${RPATH##*"Library rpath: ["}
			RPATH=${RPATH%%"]"*}
		fi
	}

	# 返回值保存在 ${RUNPATH} 变量中
	function get_val_from_var_fileinfe_runpath() {
		unset RUNPATH
		if [[ "$fileinfe" == *"Library runpath:"* ]]; then
			RUNPATH=`echo "$fileinfe"|grep "Library runpath:"`
			RUNPATH=${RUNPATH##*"Library runpath: ["}
			RUNPATH=${RUNPATH%%"]"*}
		fi
	}

	function process_file() {
		i=$1

		fileinfo=`file $i 2>/dev/null`

		if [[ "$fileinfo" != *": ELF "* ]]; then
			# echo "跳过, 不是elf文件: $filename"
			return
		fi

		if [[ "$fileinfo" == *"relocatable"* ]]; then
			# echo "跳过, 不是动态库或可执行文件: $filename"
			return
		fi

		if [[ "$fileinfo" == *"statically linked"* ]]; then
			# echo "跳过, 不是动态库或可执行文件: $filename"
			return
		fi

		fileinfe=`readelf -d $i 2>/dev/null`

		get_val_from_var_fileinfo_interpreter	# 返回值保存在 ${INTERPRETER} 变量中
		get_val_from_var_fileinfe_rpath			# 返回值保存在 ${RPATH} 变量中
		get_val_from_var_fileinfe_runpath		# 返回值保存在 ${RUNPATH} 变量中

		tpath2zpath "$INTERPRETER"
		newi=$ZPATH

		tpath2zpath "$RPATH"
		newr=$ZPATH

		tpath2zpath "$RUNPATH"
		newu=$ZPATH

		FORCELOG=0
		bdir=`dirname $i`
		if   [[ "$bdir" == "${TERMUX__PREFIX}/glibc"* ]]; then
			if   [[ "$bdir" == "${TERMUX__PREFIX}/glibc/bin"* ]]; then
				if [ "$RPATH" == "" ] && [ "$RUNPATH" == "" ]; then
					FORCELOG=1
					newr=${TERMUX__PREFIX}/glibc/lib:${TERMUX__PREFIX}/glibc/lib/x86_64-linux-gnu/
				fi
			fi
			# 	# newr="\$ORIGIN"
		# elif [ "$bdir" == "${TERMUX__PREFIX}/"* ]; then
		# 	newu=${TERMUX__PREFIX}/lib
		# 	# 	newu="\$ORIGIN"
		fi


		command=""
		if [ "$newr" != "" ]; then
			# --force-rpath  这个参数是强制设置 rpath 的，但 rpath 已经被弃用，请尽量不要加这个参数！，即使用 runpath, 而非 rpath
			command+="--force-rpath --set-rpath ${newr} "
		elif  [ "$newu" != "" ]; then
			command+="              --set-rpath ${newu} "
		fi

		if [ "$newi" != "" ]; then
			command+="--set-interpreter ${newi} "
		fi

		if [ $FORCELOG -eq 1 ]; then
			itemlen=80
			echo                                        "   当前文件: $i"
			printf "%-${itemlen}s %-${itemlen}s""\n"	"interpreter: ${INTERPRETER=-}"	"=> ${newi=-}"	# >> ${PATH_LOG_PATCH}
			printf "%-${itemlen}s %-${itemlen}s""\n"	"      rpath: ${RPATH=-}"		"=> ${newr=-}"	# >> ${PATH_LOG_PATCH}
			printf "%-${itemlen}s %-${itemlen}s""\n"	"    runpath: ${RUNPATH=-}"		"=> ${newu=-}"	# >> ${PATH_LOG_PATCH}
			echo										"   patchelf: $command"
			echo ""
		fi

		if [ "$command" != "" ]; then
			patchelf $command $i
			if [ $? -ne 0 ]; then echo "处理失败 $i"; fi
		fi
	}

	function wboxPatchElfFiles() {

		dirtopatch=$1
		if [ "$dirtopatch" == "" ]; then
			return
		fi

		for i in ${dirtopatch}/*; do
			process_file $i
		done

	}

	function doElfPatch() {
		
		patchelf --force-rpath \
		--set-rpath       ${TERMUX__PREFIX}/glibc/lib \
		--set-interpreter ${TERMUX__PREFIX}/glibc/lib/ld-linux-aarch64.so.1 \
		${TERMUX__PREFIX}/glibc/bin/box64

		# echo ""> ${PATH_LOG_PATCH}

		if [ "$QUICK_PATCH" != "1" ]; then
			WBOX_RUN_PATH=${TERMUX__PREFIX}/lib
			WBOX_INTERPRT=
			WBOX_FORCERPT=

			echo "正在处理 glibc  (gnu    libc 系列的软件)"
			WBOX_RUN_PATH=${TERMUX__PREFIX}/glibc/lib:${TERMUX__PREFIX}/glibc/lib/x86_64-linux-gnu/
			WBOX_INTERPRT=${TERMUX__PREFIX}/glibc/lib/ld-linux-aarch64.so.1
			WBOX_FORCERPT="--force-rpath"
			wboxPatchElfFiles ${TERMUX__PREFIX}/glibc/bin
			# wbox_wine_elfheader_patch $WINE_PATH/bin	# 这个不需要
		fi

			echo "正在处理 glibc  (gnu    libc 系列的动态库)"
			WBOX_RUN_PATH=${TERMUX__PREFIX}/lib
			WBOX_INTERPRT=
			WBOX_FORCERPT=
			wboxPatchElfFiles ${TERMUX__PREFIX}/glibc/lib

		echo "patch 已完成"
	}

#endregion





function sw_download() {
	if [ "${CURRENT_VM_ARCH}" != "arm64" ]; then
		exit_unsupport
	fi

	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh gitlab.com`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	# # gitlab项目ID：wine32/64分体
	# PRIVATE_TOKEN=glpat-Xs4HfrCkMpbedkPycqzP
	# PROJECT_ID=52465323

	# # gitlab项目ID：wine32/64一体											<<==	建议使用一体wine
	PRIVATE_TOKEN=glpat-h5r7HjKoPKZPxmfg79xs
	PROJECT_ID=54240888

	for SW_ITEM in ${WBOX_PKGS}; do
		PKGNAME="${SW_ITEM}.tar.xz"
		FILE_SAVETO="./downloads/${SW_ITEM}.tar.xz"
		wboxDownload "${FILE_SAVETO}" "https://gitlab.com/api/v4/projects/$PROJECT_ID/repository/files/$PKGNAME/raw?ref=main"
		exit_if_fail $? "下载失败，软件包：${SW_ITEM}"
	done

	echo "正在下载茶壶演示程序" # https://droidvmres-1316343437.cos.ap-shanghai.myqcloud.com/EnvMapping_DX9.zip
	demoapp=./downloads/demoapp.zip
	swUrl=${APP_URL_DLSERVER}/EnvMapping_DX9.zip
	download_file2 "${demoapp}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

}

function sw_install() {
	rm -rf ${WINE_HOME_P}

	[ -x /data/data/com.termux/files/usr/bin/bash ]  || . ./scripts/termux.sh
	exit_if_fail $? "termux 安装失败"

	command -v patchelf >/dev/null 2>&1 || sudo apt-get install -y patchelf
	exit_if_fail $? "patchelf 安装失败"

	command -v readelf >/dev/null 2>&1 || sudo apt-get install -y binutils
	exit_if_fail $? "readelf 安装失败"

	command -v file >/dev/null 2>&1 || sudo apt-get install -y file
	exit_if_fail $? "file 安装失败"

	command -v unzip >/dev/null 2>&1 || sudo apt-get install -y unzip
	exit_if_fail $? "unzip 安装失败"
	
	# 解压
	for SW_ITEM in ${WBOX_PKGS}; do
		PKGNAME="${SW_ITEM}.tar.xz"
		FILE_SAVETO="./downloads/${SW_ITEM}.tar.xz"
		echo "正在解压 ${SW_ITEM} . . ."
		tar -xJf ${FILE_SAVETO} --overwrite -C ${WBOXUSR}
		exit_if_fail $? "解压失败，软件包：${DEB_PATH}"
	done

	echo "正在解压 可运行于wine中的3D茶壶测试程序"
	mkdir -p  ${WBOXUSR}/glibc/opt/apps/3D茶壶 2>/dev/null
	unzip -oq ${demoapp} -d ${WBOXUSR}/glibc/opt/apps/3D茶壶
	exit_if_fail $? "解压失败，软件包：${demoapp}"

	echo "正在创建相关文件 . . ."
	create_files

	# echo "正在打elf补丁 . . ."
	# doElfPatch
}

function sw_create_desktop_file() {
	gxmessage -title "提示" "安装已完成，双击桌面上红色的 wbox 图标即可启动" -center  &
}

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1

	rm -rf ${WINE_HOME_P}
	rm -rf /usr/bin/${SWNAME}
	rm2desktop ${SWNAME}.desktop
	rm2desktop ${SWNAME}-virdsk.desktop
	rm2desktop ${SWNAME}-term.desktop
	rm2desktop ${SWNAME}-conf.desktop
	rm2desktop ${SWNAME}-reset.desktop
	rm2desktop ${SWNAME}-tools.desktop
	rm2desktop 显卡驱动
	sed -i "/盘/d"  ${ZZ_USER_HOME}/.config/gtk-3.0/bookmarks
	apt-get clean
else
	sw_download
	sw_install
	sw_create_desktop_file
fi

: '

https://droidvmres-1316343437.cos.ap-shanghai.myqcloud.com/EnvMapping_DX9.zip
https://droidvmres-1316343437.cos.ap-shanghai.myqcloud.com/EnvMapping_DX9.zip

export WBOX_WINE=wine-9.3-vanilla-wow64
exec box64 /data/data/com.termux/files/usr/glibc/${WBOX_WINE}/bin/wine explorer

'
