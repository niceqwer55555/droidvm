#!/bin/bash

SWNAME=krita

action=$1


DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}


if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh


if [ "${action}" == "卸载" ]; then
	sudo apt-get remove -y ${SWNAME} krita-l10n
	rm2desktop org.kde.krita.desktop
else
	sudo apt-get install -y ${SWNAME} krita-l10n

	rm -rf ${DIR_DESKTOP_FILES}/krita*
	cp2desktop ${DIR_DESKTOP_FILES}/org.kde.krita.desktop

fi
