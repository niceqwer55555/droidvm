#!/bin/bash

: '
vncserver :6 -localhost no -geometry 1280x800 -depth 32  -xstartup jwm
:6 即代表xserver的display_id, 也代表vnc server的端口号为 5906, 如果是:1那对应的端口号就是5901, :2=>5902
https://blog.csdn.net/u012625323/article/details/122419954
vncserver -kill :6

修改vnc访问密码：
vncpasswd

测试启动：
VNC_SCREEN_RES=1280x700
vncserver :6 -localhost no -geometry ${VNC_SCREEN_RES} -depth 32  -xstartup startx_for_vnc

'

SWNAME=webvnc
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}


action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

PKGS="tigervnc-standalone-server tigervnc-common tigervnc-tools websockify novnc"

if [ "${action}" == "卸载" ]; then
	sudo apt-get remove -y ${PKGS}
	rm -rf /usr/bin/webvnc
	rm2desktop webvnc.desktop
	exit 0
else
	sudo apt-get install -y --no-install-recommends  ${PKGS}
	exit_if_fail $? "安装失败"

	dpkg -i --force-overwrite /exbin/tools/patches/${LINUX_DISTRIBUTION}/tigervnc-standalone-server_1.13.1+dfsg-2build2_arm64.deb
	exit_if_fail $? "移植版 tigerVnc 安装失败，请：开始->控制台->ndktools->重新下载"

	mkdir -p /etc/webvnc/ 2>/dev/null
	exit_if_fail $? "安装失败，无法创建目录"

	cp -f  ./scripts/res/webvnc.defaultpwd  /etc/webvnc/password.data
	exit_if_fail $? "安装失败，无法设置初始密码"

	rm -rf /usr/bin/webvnc
	exit_if_fail $? "安装失败，旧版删除失败！"

	rm2desktop webvnc.desktop

	gxmessage -title "提示" "安装已完成，启动步骤： \"开始\" \"远程控制\"  \"通过webvnc\""  -center
fi

# vncserver :6 -localhost no -geometry ${VNC_SCREEN_RES} -depth 32  -xstartup jwm &
