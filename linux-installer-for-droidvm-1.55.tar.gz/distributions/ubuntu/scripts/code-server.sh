#!/bin/bash

SWNAME=code-server
SWVER=4.23.1

# 注意安装顺序，后装者依赖前装者
DEB_PATH1=./downloads/${SWNAME}.deb

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}
app_dir=/opt/apps/${SWNAME}
srvprt=5560

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh ${GITHUB_PROXY_HOST}`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	case "${CURRENT_VM_ARCH}" in
		"arm64")
			swUrl="${GITHUB_PROXY_HTTP}https://github.com/coder/code-server/releases/download/v${SWVER}/code-server_${SWVER}_arm64.deb"
			download_file2 "${DEB_PATH1}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		;;
		"amd64")
			swUrl="${GITHUB_PROXY_HTTP}https://github.com/coder/code-server/releases/download/v${SWVER}/code-server_${SWVER}_amd64.deb"
			download_file2 "${DEB_PATH1}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		;;
		*) exit_unsupport ;;
	esac
}

function sw_install() {

	# mkdir -p ${app_dir}

	# echo "正在解压. . ."
	# tar -xzf ${DEB_PATH1} --overwrite -C ${app_dir}
	# exit_if_fail $? "安装失败，软件包：${DEB_PATH1}"

	install_deb ${DEB_PATH1} # ${DEB_PATH2} ${DEB_PATH3}
	exit_if_fail $? "安装失败，软件包：${DEB_PATH}"

}

function sw_create_desktop_file() {
	echo "正在生成桌面文件"

	tmpfile=${DIR_DESKTOP_FILES}/${SWNAME}.desktop
	cat <<- EOF > ${tmpfile}
		[Desktop Entry]
		Name=${SWNAME}
		GenericName=${SWNAME}
		Exec=${SWNAME}
		Terminal=true
		Type=Application
	EOF
	cp2desktop ${tmpfile}

	mkdir -p /home/${ZZ_USER_NAME}/.config/code-server
	cat <<- EOF > /home/${ZZ_USER_NAME}/.config/code-server/config.yaml
		bind-addr: 0.0.0.0:${srvprt}
		auth: password
		password: droidvm
		cert: false
	EOF

	gxmessage -title "提示"     $'\n安装完成\n\n'  -center
}

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1
	rm -rf ${DEB_PATH1}

	rm -rf /usr/bin/${SWNAME}

	rm -rf /opt/apps/${SWNAME}

	rm2desktop ${SWNAME}.desktop

	apt-get clean
else
	sw_download
	sw_install
	sw_create_desktop_file
fi

