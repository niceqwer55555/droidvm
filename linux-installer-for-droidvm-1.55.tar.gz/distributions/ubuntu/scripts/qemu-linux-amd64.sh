#!/bin/bash


SWNAME=qemu-linux-amd64
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

DEB_PATH=./downloads/${SWNAME}_kernel_amd64.tar.gz
TAR_PATH=./downloads/${SWNAME}_rootfs_amd64.tar.gz
app_dir=/opt/apps/${SWNAME}

function sw_download() {

	# if [ "$action" == "重装" ]; then
	# 	echo "正在删除之前下载的安装包"
	# 	rm -rf ${DEB_PATH} ${TAR_PATH}
	# fi

	# 2024.05.13 废弃了
	# # swUrl=${APP_URL_DLSERVER}/qemu-linux-amd64.zip
	# swUrl=https://gitee.com/droidvm/build_mylinux/releases/download/v0.01/qemu-linux-amd64.zip
	# download_file2 "${DEB_PATH}" "${swUrl}"
	# exit_if_fail $? "下载失败，网址：${swUrl}"

	# kernel with usbip compile-in
	swUrl=https://gitee.com/droidvm/build_mylinux/releases/download/v0.02/linux-amd64.tar.gz
	download_file2 "${DEB_PATH}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

	# base-rootfs
	swUrl=https://mirror.tuna.tsinghua.edu.cn/ubuntu-cdimage/ubuntu-base/releases/jammy/release/ubuntu-base-22.04-base-amd64.tar.gz
	download_file2 "${TAR_PATH}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

	# # PRE_DL_PKGS="ca-certificates udev wget usb.ids usbutils unzip dosfstools fdisk grub2"
	# # apt-get install --print-uris -y ${PRE_DL_PKGS}|grep ^\'http|awk '{print $1}'
	# echo ""
    # echo "apt 安装的同时显示下载链接"
    # echo "apt-get install --print-uris -y 包名"


	# 预先下载好一些需要的deb包， qemu 中的虚拟里面下载也很慢。。。
	mkdir -p ${app_dir}/shared/pre_download_debs 2>/dev/null

	# https://mirrors.tuna.tsinghua.edu.cn/ubuntu/pool/main/o/openssl
	cat <<- EOF > ${ZZSWMGR_TEMP_DIR}/tmp_deb_list.txt
		http://${CURR_APT_HOST}/ubuntu/pool/main/o/openssl			libssl3			3.0.2
		http://${CURR_APT_HOST}/ubuntu/pool/main/o/openssl			openssl			3.0.2
	EOF
	download_deb_from_other_apt_repo  "${app_dir}/shared/pre_download_debs/"  "amd64"

	# https://mirrors.tuna.tsinghua.edu.cn/ubuntu/pool/main/c/ca-certificates
	cat <<- EOF > ${ZZSWMGR_TEMP_DIR}/tmp_deb_list.txt
		http://${CURR_APT_HOST}/ubuntu/pool/main/c/ca-certificates	ca-certificates	20240203
	EOF
	download_deb_from_other_apt_repo  "${app_dir}/shared/pre_download_debs/"  "all"


}


function edit_rootfs() {
SW_SOURCE_X86="
# 默认注释了源码镜像以提高 apt update 速度，如有需要可自行取消注释
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-updates main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-updates main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-backports main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-backports main restricted universe multiverse

deb http://security.ubuntu.com/ubuntu/ jammy-security main restricted universe multiverse
# deb-src http://security.ubuntu.com/ubuntu/ jammy-security main restricted universe multiverse

# 预发布软件源，不建议启用
# deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-proposed main restricted universe multiverse
# # deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-proposed main restricted universe multiverse
"

VM_NAMESERVER="
nameserver 8.8.8.8
nameserver 223.5.5.5
nameserver 223.6.6.6
nameserver 2400:3200::1
nameserver 2400:3200:baba::1
nameserver 114.114.114.114
nameserver 114.114.115.115
nameserver 240c::6666
nameserver 240c::6644

options single-request-reopen
options timeout:2
options attempts:3
options rotate
options use-vc      # 走TCP
"

	DIR_ROOTFS=${app_dir}/rootfs
	DIR_KNLMOD=${app_dir}/kernel/kernel-related/kernel_modules
	DIR_KNLAPP=${app_dir}/kernel/kernel-related/kernel_userapp

	sudo cp -R ${app_dir}/utils/* ${DIR_ROOTFS}/
	exit_if_fail $? "启动脚本 复制失败"

	# sudo mkdir -p ${DIR_ROOTFS}/var/cache/pre_download_debs 2>/dev/null
	# sudo cp -Rf ${app_dir}/pre_download_debs/* ${DIR_ROOTFS}/var/cache/pre_download_debs/
	# exit_if_fail $? "deb 安装包复制失败"

	echo "正在复制 内核密相关模块(在编译内核模块时生成)"
	sudo cp -R ${DIR_KNLMOD}/* ${DIR_ROOTFS}/usr/
	exit_if_fail $? "内核密相关模块 复制失败"

	echo "正在复制 内核密相关软件(在编译内核软件时生成)"
	sudo cp -R ${DIR_KNLAPP}/* ${DIR_ROOTFS}/usr/
	exit_if_fail $? "内核密相关软件 复制失败"

    sudo echo "${SW_SOURCE_X86}"   > ${DIR_ROOTFS}/etc/apt/sources.list.cn.amd64
    exit_if_fail $? "软件下载仓库地址 修改失败"

    echo "zzvm" >  ${DIR_ROOTFS}/etc/hostname
    exit_if_fail $? "hostname 修改失败"

    sudo chmod 666                       ${DIR_ROOTFS}/etc/resolv.conf
    sudo echo "${VM_NAMESERVER}"		>${DIR_ROOTFS}/etc/resolv.conf
	# cp -f /etc/resolv.conf  			 ${DIR_ROOTFS}/etc/resolv.conf
    exit_if_fail $? "DNS服务器 修改失败"

}

function rootfs2qemuImg() {
	IMG_ROOTFS=${app_dir}/virhd-amd64.img
	VHDIMGSIZE=999M
	qemu-img create  -f raw  ${IMG_ROOTFS}    ${VHDIMGSIZE}
    exit_if_fail $? "qemuImg 创建失败"

	sudo mkfs.ext4 -L rootfs ${IMG_ROOTFS} -d ${DIR_ROOTFS}
    exit_if_fail $? "qemuImg 格盘失败"

	# qemu-img convert -f raw  ${IMG_ROOTFS} -O qcow2 ${IMG_ROOTFS}.qcow2
    # exit_if_fail $? "qemuImg 格式失败"
	# apt-get install --print-uris -y ca-certificates udev wget usb.ids usbutils

}


function sw_install() {
	# apt-get install -y unzip
	# exit_if_fail $? "解压工具unzip安装失败"

	# echo "正在解压. . ."
	# mkdir -p ${app_dir} 2>/dev/null
	# unzip -oq ${DEB_PATH} -d ${app_dir}
	# exit_if_fail $? "安装失败，软件包：${DEB_PATH}"


	apt-get install -y qemu-system-x86
	exit_if_fail $? "qemu-system安装失败"

	mkdir -p ${app_dir}/shared 2>/dev/null
	cp -Rf ./ezapp/qemu-linux-amd64 /opt/apps/
	exit_if_fail $? "安装失败，无法复制文件到 /opt/apps/"

	chmod 755 ${app_dir}/qemu-linux-amd64.sh
	chmod 755 ${app_dir}/utils/*

	echo "正在解压内核. . ."
	mkdir -p ${app_dir}/kernel 2>/dev/null
	tar -xzf ${DEB_PATH} --overwrite -C ${app_dir}/kernel
	exit_if_fail $? "安装失败，软件包：${DEB_PATH}"

	echo "正在解压rootfs. . ."
	mkdir -p ${app_dir}/rootfs 2>/dev/null
	tar -xzf ${TAR_PATH} --overwrite -C ${app_dir}/rootfs
	exit_if_fail $? "安装失败，软件包：${TAR_PATH}"

	edit_rootfs
	rootfs2qemuImg
}


function sw_create_desktop_file() {
	echo "正在生成桌面文件"
	tmpfile=${DIR_DESKTOP_FILES}/${SWNAME}.desktop
	echo "[Desktop Entry]"			> ${tmpfile}
	echo "Encoding=UTF-8"			>>${tmpfile}
	echo "Version=0.9.4"			>>${tmpfile}
	echo "Type=Application"			>>${tmpfile}
	echo "Terminal=true"			>>${tmpfile}
	echo "Name=小型linux"			>>${tmpfile}
	echo "Exec=${app_dir}/qemu-linux-amd64.sh %f"	>> ${tmpfile}
	cp2desktop ${tmpfile}
}

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1

	set -x	# echo on
	apt-get autopurge -y qemu-system-x86
	rm -rf ${app_dir}
	rm -rf ${DEB_PATH} ${TAR_PATH}
	rm2desktop ${SWNAME}.desktop
	apt-get clean
	set +x	# echo off

else
	sw_download
	sw_install
	sw_create_desktop_file
fi
