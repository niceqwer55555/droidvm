#!/bin/bash

SWNAME=qqmusic
# SWVER=18.2.3

# 注意安装顺序，后装者依赖前装者
DEB_PATH1=./downloads/${SWNAME}.deb

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}
app_dir=/opt/QQmusic

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh ${GITHUB_PROXY_HOST}`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	case "${CURRENT_VM_ARCH}" in
		"arm64")
			swUrl="https://www.cnxclm.com/forum.php?mod=attachment&aid=Mzg4NHwwNWIzMmRiYXwxNzQ2ODcwNjk3fDB8NDI1MQ%3D%3D"
			download_file2 "${DEB_PATH1}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		;;
		*) exit_unsupport ;;
	esac
}

function sw_install() {

	sudo apt-get install -y ${ZZSWMGR_MAIN_DIR}/${DEB_PATH1}
	exit_if_fail $? "安装失败"

}

function sw_create_desktop_file() {
	echo "正在生成桌面文件"

	tmpfile=${DIR_DESKTOP_FILES}/${SWNAME}.desktop
    sed -i 's#Exec=/opt/QQmusic/qqmusic#Exec=/opt/QQmusic/qqmusic --no-sandbox#g'  ${tmpfile}
	cp2desktop ${tmpfile}

	gxmessage -title "提示"     $'\n安装完成\n\n'  -center
}

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1
	rm -rf ${DEB_PATH1} ${app_dir}
	rm2desktop ${SWNAME}.desktop
	apt-get clean
else
	sw_download
	sw_install
	sw_create_desktop_file
fi

