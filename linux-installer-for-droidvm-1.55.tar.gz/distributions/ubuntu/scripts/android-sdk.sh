#!/bin/bash

SWNAME=android-sdk
DEB_PATH=./downloads/${SWNAME}.zip
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}
SWVER=r26b

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh googledownloads.cn`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts
	# echo "211.97.84.91   mirrors.cloud.tencent.com"           >> /etc/hosts

	case "${CURRENT_VM_ARCH}" in
		"arm64")
				# 下载地址从这个页面来的
				# https://developer.android.google.cn/studio
				swUrl=https://googledownloads.cn/android/repository/commandlinetools-linux-11076708_latest.zip

				DEB_PATH=./downloads/android-commandlinetools-linux.zip
				download_file2 "${DEB_PATH}" "${swUrl}"
				exit_if_fail $? "下载失败，网址：${swUrl}"

				# 下载地址从这个页面来的
				# https://androidsdkmanager.azurewebsites.net/Buildtools.html
				# 29.0.3 => r29-rc3
				# 30.0.1 => r30-rc1
				# 33.0.0 => r33
				# 34.0.0 => r34

				# 查看所有版本
				# sdkmanager --list|grep build
				swUrl=https://dl.google.com/android/repository/build-tools_r29-rc3-linux.zip
				swUrl=https://dl.google.com/android/repository/build-tools_r33-linux.zip
				# swUrl=https://dl.google.com/android/repository/build-tools_r34-linux.zip

				DEB_PAT2=./downloads/android-x86-build-tools-linux.zip
				download_file2 "${DEB_PAT2}" "${swUrl}"
				exit_if_fail $? "下载失败，网址：${swUrl}"

				;;
		*) exit_unsupport ;;
	esac
}

function sw_install() {
	apt-get install -y make
	exit_if_fail $? "依赖包安装失败"

	apt-get install -y unzip 
	exit_if_fail $? "解压工具unzip安装失败"

	# export BOX64_NOBANNER=1
	# export BOX64_DYNAREC_LOG=0
	# BOX64_LOG=0
	# build-tools 是x86_64架构的，得用box64翻译运行
	command -v box64 >/dev/null 2>&1 || sudo apt-get install -y box64
	exit_if_fail $? "box64安装失败"

	apt-get install -y android-tools-adb aidl
	exit_if_fail $? "sdk相关工具安装失败"

	echo "正在解压 ${DEB_PATH}. . ."
	mkdir -p /opt/apps/android/sdk 2>/dev/null
	unzip -oq ${DEB_PATH} -d /opt/apps/android/sdk/
	exit_if_fail $? "安装失败，软件包：${DEB_PATH}"

	echo "正在解压 ${DEB_PAT2}. . ."
	mkdir -p /opt/apps/android/sdk/build-tools 2>/dev/null
	unzip -oq ${DEB_PAT2} -d /opt/apps/android/sdk/build-tools/
	exit_if_fail $? "安装失败，软件包：${DEB_PAT2}"

	cat <<- EOF > /usr/bin/sdkmanager
		#!/bin/bash
		if [[ "\$@" == *"build-tools"* ]]; then
			echo "build-tools 需要手动下载安装! 参考："
			echo "sdkmanager --list|grep build # 查看所有 build-tools 版本"
			echo "旧版地址：           https://androidsdkmanager.azurewebsites.net/Buildtools.html"
			echo ""
			echo "具体下载步骤如下："
			echo "========================================"
			echo "1). 参照下列规则构造特定版本build-tools的下载地址，并下载好zip包"
			echo "29.0.3 => r29-rc3 => https://dl.google.com/android/repository/build-tools_r29-rc3-linux.zip"
			echo "30.0.1 => r30-rc1 => https://dl.google.com/android/repository/build-tools_r30-rc1-linux.zip"
			echo "33.0.0 => r33     => https://dl.google.com/android/repository/build-tools_r33-linux.zip"
			echo "34.0.0 => r34     => https://dl.google.com/android/repository/build-tools_r34-linux.zip"
			echo ""
			echo "2). 解压第一步下载好的压缩包"
			echo "unzip -oq  您下载的build-tools.zip  -d /opt/apps/android/sdk/build-tools/"
			exit 2
		fi
		exec /opt/apps/android/sdk/cmdline-tools/bin/sdkmanager --sdk_root=/opt/apps/android/sdk \$@
	EOF
	chmod a+x /usr/bin/sdkmanager

	echo "正在安装 android-34 (android.jar，类似C的头文件, 主要包含使用到的函数列表, 用于链接时). . ."
	cmd -e sdkmanager "platforms;android-34"
	exit_if_fail $? "android-32 (android.jar) 安装失败"

}

function sw_create_desktop_file() {
	:
}

if [ "${action}" == "卸载" ]; then
	echo "暂不支持卸载"
	exit 1
else
	which java >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo ""				> /tmp/msg.txt
		echo "请先安装jdk"	>>/tmp/msg.txt
		echo ""				>>/tmp/msg.txt
		gxmessage -title "提示" -file /tmp/msg.txt -center
		exit 1
	fi

	sw_download
	sw_install
	sw_create_desktop_file
fi
