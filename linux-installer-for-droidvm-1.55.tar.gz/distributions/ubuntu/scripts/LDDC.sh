#!/bin/bash

SWNAME=LDDC
SWVER=0.9.1

# 注意安装顺序，后装者依赖前装者
DEB_PATH1=./downloads/${SWNAME}-${SWVER}.deb

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	case "${CURRENT_VM_ARCH}" in
		"arm64")
			swUrl="${GITHUB_PROXY_HTTP}https://github.com/chenmozhijin/LDDC/releases/download/v${SWVER}/LDDC_${SWVER}_arm64.deb"
			download_file2 "${DEB_PATH1}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		;;
		*) exit_unsupport ;;
	esac
}

function sw_install() {

	# apt-get install -y libasound2t64
	# exit_if_fail $? "依赖库安装失败"

	sudo apt-get install -y \
	libxkbcommon-x11-0  \
	libxcb-cursor0 libxcb-cursor-dev libxcb-xinerama0 libxcb-icccm4 libxcb-image0 \
	libxcb-keysyms1 libxcb-render-util0 libxcb-randr0 libxcb-shape0 libxcb-xfixes0 libxcb-xkb1 \
	${ZZSWMGR_MAIN_DIR}/${DEB_PATH1}
	exit_if_fail $? "安装失败，主包安装失败"

	# install_deb ${DEB_PATH1} ${DEB_PATH2} ${DEB_PATH3}
	# install_deb ${DEB_PATH1}
	# exit_if_fail $? "安装失败，软件包：${DEB_PATH1}"

}

function sw_create_desktop_file() {
	tmpfile=${DSK_PATH}
	cp2desktop ${tmpfile}

	gxmessage -title "提示"     $'\n安装完成\n\n'  -center
}

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1

	pkgname2rm=lddc
	echo "正在 dpkg --remove --force-remove-reinstreq ${pkgname2rm}"
	dpkg --remove --force-remove-reinstreq ${pkgname2rm}
	exit_if_fail $? "force-remove-reinstreq 失败"

	echo "正在 apt-get purge ${pkgname2rm} -y"
	apt-get purge ${pkgname2rm} -y

	rm -rf /usr/lib/LDDC

	rm -rf ${app_dir} ${DIR_DESKTOP_FILES}/${SWNAME}.desktop
	rm2desktop ${SWNAME}.desktop
else
	sw_download
	sw_install
	sw_create_desktop_file
fi

