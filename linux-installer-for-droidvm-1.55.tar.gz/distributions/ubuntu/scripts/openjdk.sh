#!/bin/bash

SWNAME=default-jdk

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

if [ "${action}" == "卸载" ]; then
	sudo dpkg --purge ${SWNAME} # openjdk-11-jre-headless:amd64
	sudo apt-get remove -y ${SWNAME}
	sudo apt remove default-jdk
	sudo apt remove openjdk*
	sudo rm /var/lib/binfmts/jar

	# sudo dpkg --list | grep -i jdk
	# sudo apt autoremove
else
	sudo apt-get install -y ${SWNAME}

	# # 
	# dir_tmp=`ls -a /usr/lib/jvm/|grep jdk-|tail -n 1`
	# app_dir=/opt/apps/${dir_tmp}

	cat <<- EOF > ${DIR_PROFILE_D}/${SWNAME}.sh

		export JAVA_HOME=/usr/lib/jvm/default-java
		export CLASSPATH=\$JAVA_HOME/lib

		# JAVA_BINDIR=\${JAVA_HOME}/bin
		# if [[ \$PATH != *\${JAVA_BINDIR}* ]]
		# then
		# 	export PATH=\$PATH:\${JAVA_BINDIR}
		# fi
	EOF

	echo "安装完成."
	gxmessage -title "提示" "安装完成，重启生效"  -center
fi

# /usr/lib/jvm/java-21-openjdk-arm64
