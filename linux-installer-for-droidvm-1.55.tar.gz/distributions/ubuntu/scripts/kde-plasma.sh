#!/bin/bash

SWNAME=kde-plasma-desktop

action=$1
if [ "$action" == "" ]; then action=安装; fi

# pwd
. ./scripts/common.sh


if [ "${action}" == "卸载" ]; then
  sudo apt-get remove -y ${SWNAME}
  rm -rf ${app_home}/app_boot_config/cfg_de.txt
else

  gxmessage -title "是否继续安装？" $'\n不建议不熟悉linux环境的新手在虚拟电脑中使用kde\n\n虚拟电脑集成的所有界面类脚本都是针对jwm+pcmanfm桌面环境整理的\n使用kde将不能使用虚拟电脑集成的各类便捷脚本\n\n'  -center -buttons "继续安装:0,取消安装:1"
  case "$?" in
    "0")
      :
      ;;
    *) 
      echo "您已取消安装"
      exit 1
      ;;
  esac

  sudo apt-get install -y ${SWNAME}
  exit_if_fail $? "${SWNAME} 安装失败"
  echo "kde" > ${app_home}/app_boot_config/cfg_de.txt

  echo "${SWNAME}安装完成."
  gxmessage -title "提示" "${SWNAME}安装完成, 重启生效"  -center &

fi
