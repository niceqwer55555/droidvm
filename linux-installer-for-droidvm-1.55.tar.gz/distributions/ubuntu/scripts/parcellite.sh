#!/bin/bash

SWNAME=parcellite

action=$1
if [ "$action" == "" ]; then action=安装; fi

# pwd
. ./scripts/common.sh

if [ "${action}" == "卸载" ]; then
	apt-get remove -y ${SWNAME}
	rm -rf /etc/autoruns/autoruns_after_gui/parcellite.desktop 2>/dev/null
else
	apt-get install -y ${SWNAME}
  exit_if_fail $? "安装失败"

	# 添加到自启动目录
	tmpfile=/etc/autoruns/autoruns_after_gui/parcellite.desktop
	cat <<- EOF > ${tmpfile}
		[Desktop Entry]
		Name=剪贴板管理
		GenericName=剪贴板管理
		Exec=parcellite
		Terminal=false
		Type=Application
	EOF

	# for xfce4
	rm -rf /etc/xdg/autostart/parcellite*

  echo "安装完成."
  gxmessage -title "提示" "安装完成，重启生效"  -center
fi
