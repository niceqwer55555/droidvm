#!/bin/bash

SWNAME=filezilla
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

# pwd
. ./scripts/common.sh

if [ "${action}" == "卸载" ]; then
	apt-get remove -y ${SWNAME}
	rm2desktop ${SWNAME}.desktop
else
	apt-get install -y ${SWNAME}
	exit_if_fail $? "安装失败"

	tmpfile=${DIR_DESKTOP_FILES}/${SWNAME}.desktop
	cp2desktop ${tmpfile}

	echo "安装完成."
	gxmessage -title "提示" "安装完成，重启生效"  -center
fi
