#!/bin/bash

SWNAME=wps-pro
DEB_PATH=./downloads/${SWNAME}.deb
FT_PATH1=./downloads/ttf-wps-fonts.tar.xz
FT_PATH2=./downloads/ttf-mst-fonts.tar.xz
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {

	if [ "${CURRENT_VM_ARCH}" != "arm64" ]; then
		exit_unsupport
	fi

	zzgetapthost

	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh ${CURR_APT_HOST} mirrors.sdu.edu.cn gitee.com`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	# 下载主安装包!，如果桌面上有安装包，就从桌面上直接复制过来，而不会下载
	if [ ! -f "${DEB_PATH}" ]; then
		user_download_deb=`ls /home/${ZZ_USER_NAME}/Desktop/${SWNAME}*.deb 2>/dev/null`
		if [ -f "${user_download_deb}" ]; then
			cp -f "${user_download_deb}" "${DEB_PATH}"
			exit_if_fail $? "安装包无法复制：${user_download_deb}"
		else
			echo ""
			echo "安装包请到资源群下载，不要改文件名，并放到桌面上, 最后再回到这里重装。"
			echo "(QQ群中下载后, 长按文件, 选使用虚拟电脑打开, 文件即可传送到桌面上)"
			echo "${APP_QQ_Qzy}, 安装包名：wps-pro_11.8.2.1132.AK.preload.sw.withsn_arm64.deb"
			exit 1

			swUrl="https://mirrors.sdu.edu.cn/spark-store-repository/aarch64-store/office/cn.wps.wps-office-pro/"
			DEB_NAME=`wget -q -O - "${swUrl}"|grep "cn.wps.wps-office-pro"|grep href|grep deb\"|tail -n 1|awk -F "\"" '{print $2}'`
			DEB_NAME=${DEB_NAME:2}
			echo ${DEB_NAME}
			if [ "$DEB_NAME" == "" ]; then
				false
				exit_if_fail $? "安装包下载地址无法获取"
			fi
			swUrl="${swUrl}${DEB_NAME}"
			download_file2 "${DEB_PATH}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		fi
	fi

	# 下载wps字体
	swUrl=https://gitee.com/ak2/ttf-wps-fonts/raw/master/ttf-wps-fonts.tar.xz
	download_file2 "${FT_PATH1}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

	# 下载ms字体
	swUrl=https://gitee.com/ak2/msttcorefonts/raw/master/msttcorefonts.tar.xz
	download_file2 "${FT_PATH2}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"
}

function sw_install() {

	# # 有用户交互部分！！！
	# aceept_command=debconf-set-selections
	# echo ttf-mscorefonts-installer msttcorefonts/accepted-mscorefonts-eula select true | ${aceept_command}
	# sudo apt-get install -y ttf-mscorefonts-installer
	# exit_if_fail $? "ms字体安装失败"

	# 这个包安装太耗时，这里生成一个空deb来跳过，后面的代码会从gitee下载这份字体
	TMP_PKG_NAME="ttf-mscorefonts-installer"
	apt list --installed|grep "${TMP_PKG_NAME}"
	if [ $? -ne 0 ]; then
		makedeb "${TMP_PKG_NAME}" "3.8.1ubuntu1"
		if [ "${DEB_OUT}" != "" ]; then
			dpkg -i --force-overwrite ${DEB_OUT}
		fi
	fi

	echo "正在安装wps字体"
	tar -Jxvf "${FT_PATH1}" --overwrite -C /
	exit_if_fail $? "wps字体安装失败"

	echo "正在安装ms字体"
	tar -Jxvf "${FT_PATH2}" --overwrite -C /
	exit_if_fail $? "ms字体安装失败"

	# 更新字体缓存
	sudo fc-cache -f -v

	# 安装主包, 2025.04.02 添加: libxkbcommon-x11-0
	sudo apt-get install -y --allow-downgrades libxkbcommon-x11-0 libglu1-mesa libxslt-dev bsdmainutils \
	${ZZSWMGR_MAIN_DIR}/scripts/res/deepin-elf-verify_all.deb \
	${ZZSWMGR_MAIN_DIR}/${DEB_PATH}
	exit_if_fail $? "安装失败"

	# 导入补丁脚本 2025.03.08
	. ./scripts/wps-patches-for-droidvm-ubuntu-24.04-2025.03.09.sh
	patch5_for_wps_pro_only

	# 错误1：找不到 libproviders.so 
	# 是因为虚拟电脑使用的rootfs较新，带的openssl也较新, export OPENSSL_CONF=/dev/null 可以不报此错误

	# 错误2：Some formula symbols might not be displayed correctly due to missing fonts. 缺失字体
	# https://gitee.com/ak2/ttf-wps-fonts
	# https://gitee.com/ak2/msttcorefonts

	# 错误3：backup fail/backup目录不可设置，backup功能不可关闭
	# 还是proot环境不能处理 mount 映射，导致wps把备份目录识别成只读的(/home/droidvm/.local/share/Kingsoft/office6/data/backup)
}

function sw_create_desktop_file() {
	# patch4_for_wps_starter
	# 2024.08.03 添加, 用以处理界面默认为英文的问题
	sed -i "s|Exec=|Exec=env LANGUAGE= |g" /usr/share/applications/wps*.desktop
	sed -i "s|Exec=|Exec=env LANGUAGE= |g" /home/${ZZ_USER_NAME}/Desktop/wps*.desktop
}

if [ "${action}" == "卸载" ]; then
	# sudo    dpkg    --remove     --force-remove-reinstreq    wps-office
	apt-get purge -y cn.wps.wps-office-pro
	apt-get -y autoremove --purge cn.wps.wps-office-pro
	rm2desktop wps-office*
	rm -rf /usr/share/applications/wps-office*
	rm -rf /opt/apps/cn.wps.wps-office-pro
	rm -rf /opt/kingsoft/cn.wps.wps-office-pro
	rm -rf /home/${ZZ_USER_NAME}/.local/share/Kingsoft
	rm -rf /home/${ZZ_USER_NAME}/.config/Kingsoft

	# echo "暂不支持卸载"
	# exit 1
else

	sw_download
	sw_install
	sw_create_desktop_file
fi
