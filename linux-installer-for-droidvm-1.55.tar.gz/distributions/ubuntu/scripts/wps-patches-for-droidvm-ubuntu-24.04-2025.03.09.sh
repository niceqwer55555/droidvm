: ' 分析笔记

	~/cxtest    是个在上随便写的c++可执行文件, 对动态库的依赖极少，也极不挑版本

	pad 版排查(可以gdb加载, 能直接定位到出错的是哪一个库，哪一个函数)
		export DIR_WPS=/opt/kingsoft/wps-office/office6
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/libksojscore.so                ~/cxtest     # OK
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/addons/kcef/libjscefservice.so ~/cxtest     # 失败

	365 版排查(不能gdb加载, 还直接闪退, 比较麻烦)
		export DIR_WPS=/opt/kingsoft/wps-office/office6
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/libksojscore.so                ls     # OK
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/addons/kcef/libjscefservice.so ls     # 失败
		LD_LIBRARY_PATH=${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu:${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}:${DIR_WPS}/addons/kcef  ${DIR_WPS}/wps

		gdb attach wps pid
		catch signal SIGBUS
		发现扫码登录时，这个库出错 /opt/kingsoft/wps-office/office6/libstdc++.so.6

		出错时的库、函数调用栈
		Thread 1 "wps" received signal SIGBUS, Bus error.
		0x0000007c482e9044 in __cxa_begin_catch () from /lib/aarch64-linux-gnu/libstdc++.so.6
		(gdb) bt
		#0  0x0000007c482e9044 in __cxa_begin_catch () at /lib/aarch64-linux-gnu/libstdc++.so.6
		#1  0x0000007c482ed490 in __gnu_cxx::__verbose_terminate_handler() () at /lib/aarch64-linux-gnu/libstdc++.so.6
		#2  0x756e654d656c6946 in ??? ()
		最外层的 0x756e654d656c6946 像是个跑飞了的地址，等于是看不到真实的调用栈。。。又没其它错误信息，这还怎么定位哪个地方出错的。。。

		来个瞎试。。。	=> 实测居然解决了登录闪退的问题
		cp libstdc++.so.6.0.21 libstdc++.so.6


	free 版排查(不能gdb加载, 比较麻烦)
		rm -rf  ~/.config/Kingsoft/

		export DIR_WPS=/opt/kingsoft/wps-office/office6
		LD_LIBRARY_PATH=${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu:${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}:${DIR_WPS}/addons/kcef  LD_PRELOAD=${DIR_WPS}/libtcmalloc_minimal.so.4        ~/cxtest    # OK 
		LD_LIBRARY_PATH=${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu:${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}:${DIR_WPS}/addons/kcef  LD_PRELOAD=${DIR_WPS}/addons/kcef/libjscefservice.so  ~/cxtest    # FAIL 
		LD_LIBRARY_PATH=${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu:${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}:${DIR_WPS}/addons/kcef  LD_PRELOAD=${DIR_WPS}/libwpsmain.so                   ~/cxtest    # FAIL
		LD_LIBRARY_PATH=${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu:${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}:${DIR_WPS}/addons/kcef  LD_PRELOAD=${DIR_WPS}/libkprometheus.so               ~/cxtest
		LD_LIBRARY_PATH=${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu:${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}:${DIR_WPS}/addons/kcef  LD_PRELOAD=${DIR_WPS}/libkso.so                       ~/cxtest
		LD_LIBRARY_PATH=${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu:${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}:${DIR_WPS}/addons/kcef  ${DIR_WPS}/wps

		libicuuc.so.70: cannot open shared object file: No such file or directory	cd ${DIR_WPS} && ln -sf libicuuc.so libicuuc.so.70
		libxml2.so.2: undefined symbol: UCNV_FROM_U_CALLBACK_STOP_70

		这样没有报错，但登录界面无法显示
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/f/freetype			libfreetype6	2.13.3
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/libx/libxml2			libxml2			2.12.7
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/c/cairo				libcairo2		1.16.0
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/c/cups				libcups2		2.4.1
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/m/mesa				libgbm1			23.2.1
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/h/harfbuzz			libharfbuzz0b	2.7.4
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/p/pango1.0			libpango-1.0-0	1.50.6

		以上列为基础，调成这样：
		libxml2			2.9.10 	# 报错说 libxml2.so.2: undefined symbol: UCNV_TO_U_CALLBACK_STOP_66		# cp libicuuc.so libicuuc.so.66
		libxml2			2.9.1	# 有提示请登录，但登录界面无显示 
		libxml2			2.9.3	# 没提示请登录，也点不开登录界面
		libxml2			2.9.4	# 报错说 libxml2.so.2: undefined symbol: UCNV_TO_U_CALLBACK_STOP_60		# cp libicuuc.so libicuuc.so.60
		libxml2			2.9.13  # libicuuc.so.70: cannot open shared object file: No such file or directory # cp libicuuc.so.55 libicuuc.so.70
		libxml2			2.9.14	# 有提示您未登录，但登录界面无显示 ， pure virtual method called

		把其它旧库删除，调成只有：
		libxml2			2.9.14	# 没提示请登录，也点不开登录界面
		libxml2			2.9.1 	# 有提示请登录，也点不开登录界面
		libxml2			2.9.3 	# 有提示请登录，也点不开登录界面
		libxml2			2.9.4 	# 无法运行
		libxml2			2.9.10 	# 无法运行

		这个成了！
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/libx/libxml2			libxml2			2.9.14
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/c/cairo				libcairo2		1.16.0
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/h/harfbuzz			libharfbuzz0b	2.7.4
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/p/pango1.0			libpango-1.0-0	1.50.6
			http://${CURR_APT_HOST}/ubuntu-ports/pool/main/p/pango1.0			libpangoft2-1.0-0   1.38.1


		wps安装包自带的是55和另一个比较新的(实测不是55，应该是62)


	pro 版排查(不能gdb加载, 比较麻烦)
		export DIR_WPS=/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6
		mv /opt/kingsoft/wtool   /opt/kingsoft/wtool.bak
		mv ${DIR_WPS}/wpsoffice  ${DIR_WPS}/wpsoffice.bak   # 测试发现这样做以后，${DIR_WPS}/wps 启动正常，创建新文档也不会崩溃了，但会一直转圈
															# 由此能确认 创建新文档，跟 ${DIR_WPS}/wpsoffice 有很大关系

		启动这两进程，查看错误信息
		${DIR_WPS}/wps
		${DIR_WPS}/wpsoffice  # 单独启动这个进程，报库错误了，提示也很明显: libwpsmain.so failed, libtcmalloc_minimal.so.4: cannot allocate memory in static TLS block

		查找库 libtcmalloc_minimal，并对它进行 ldd 和 preload 测试 => 发现都正常，无缺失库，也无报错 => 搜索发现是个开源库，关于内存泄露检查的，对它改名试试
		ldd -v ${DIR_WPS}/libtcmalloc_minimal.so.4

		改名测试 => 错误信息无参考价值：
		mv ${DIR_WPS}/libtcmalloc_minimal.so.4 ${DIR_WPS}/libtcmalloc_minimal.so.4.bak
		${DIR_WPS}/wpsoffice

		以上没多大价值，
		网络搜索 "libtcmalloc   cannot allocate memory in static TLS block" => 无参考价值
		网络搜索 "wps   cannot allocate memory in static TLS block"


		大多没用。。。

		find /usr/lib/ -name libSegFault.so => 系统中没找到

		adb shell logcat => 无价值

		整理头绪，再回报错信息出现的地方，确定的是：
		libtcmalloc_minimal.so.4 是由 libwpsmain.so 加载的，且没有加载成功，dlopen时就出错了

		所以， gdb启动，并在dlopen处下断：
		gdb ${DIR_WPS}/wpsoffice.bak
		b dlopen    # 断住后，会自己显示dlopen函数的参数，能看到正在加载哪一个so

		${DIR_WPS}/libwpsmain.so  => xmain => WpsMain

		readelf -h ${DIR_WPS}/libwpsmain.so


		sudo apt install -y libtcmalloc-minimal4t64 => 无效，这个 TLS 似乎跟 proot/android 有关系！！





		export DIR_WPS=/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/libksojscore.so                 ~/cxtest    # OK
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/addons/kcef/libjscefservice.so  ~/cxtest    # OK 
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/libtcmalloc_minimal.so.4        ~/cxtest    # OK 
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/libwpsmain.so                   ~/cxtest    # OK
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/libkprometheus.so               ~/cxtest
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/libkso.so                       ~/cxtest
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/libkccservice.so                ~/cxtest

		export PRE_LIB=${DIR_WPS}/addons/kcef/libjscefservice.so
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef   ldd ${PRE_LIB}
		/usr/lib/ld-linux-aarch64.so.1  --list --library-path ${DIR_WPS}:${DIR_WPS}/addons/cef ldd ${PRE_LIB}


		崩溃重启的指令：
		/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/transerr -app=wps -ccrash=0 -callfrom=1 -cpid=22087 -module=wps -dir=



		以上是2025.03.09的分析，基本没有什么作用，所得如下：
		${DIR_WPS}/wpsoffice 和 ${DIR_WPS}/libtcmalloc_minimal.so.4 删除或替换掉，可以把专业版当本地编辑工具，不能登录，不能使用在线模板创建新文档


		再来一次，这次从崩溃窗口的信息入手
		xwininfo -tree -root > ~/w.txt      => "transerr"

		查找：grep -r transerr ./
		grep: ./libkprometheus.so: binary file matches
		grep: ./libkso.so: binary file matches
		grep: ./transerr: binary file matches


		libkso.so => KCrashHandler::SendErrorReport <= KCrashHandler::CreateAndSendMiniDump() <= KCrashHandler::CrashHandler/KCrashHandler::SignalHandler

		<= Up	p	KCrashHandler::NewHandler/Up	p	KCrashHandler::TerminateHandler/Up	p	KCrashHandler::UnexpectedHandler

		SIGABRT 6 




		grep -r "SendErrorReport" ./
		也只有一个库！ 就是 libkso.so 但这个库 53MB 的大小 ......











		第三次
		export DIR_WPS=/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6

		gdb attach 2925 # ps ax|grep wps =>  2925 ?        Sl     0:01 /opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/wps
		catch signal 6  # 得到地址：0x0000007421eadeac

		catch exception
		catch assert
		catch catch
		catch signal 6
		catch signal 11 #SIGSEGV，断在 0x7cda30deac:    =>    有效定位！     0x7cda288000       0x7cda310000    0x88000    0x58000  r-xp   /data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkccservice.so


		info threads
		切换线程：thread n
		set scheduler-locking on    # 只运行当前线程

		strings libkso.so |grep endErrorReport
		b _ZN13KCrashHandler15SendErrorReportERKNSt7__cxx1112basic_stringIwSt11char_traitsIwESaIwEEE


		catch signal 6  # 用这个拦截，断在0x0000007421eadeac， 得到：
		0x7420e1c000       0x742236c000  0x1550000  0x122c000  r-xp   /data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkshell.so

		/data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkshell.so
		libksolog.so

		0x74239a6000       0x74239ba000    0x14000        0x0  rw-p   
		0x74239c0000       0x7424adf000  0x111f000        0x0  r--p   /data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkso.so--Type <RET> for more, q to quit, c to continue without paging--
		0x7424adf000       0x7424aee000     0xf000  0x111f000  ---p   /data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkso.so
		0x7424aee000       0x7426b67000  0x2079000  0x111e000  r-xp   /data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkso.so
		0x7426b67000       0x7426b76000     0xf000  0x31a7000  ---p   /data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkso.so
		0x7426b76000       0x7426d8b000   0x215000  0x3196000  r--p   /data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkso.so
		0x7426d8b000       0x7426d9a000     0xf000  0x33cb000  ---p   /data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkso.so
		0x7426d9a000       0x7426dd3000    0x39000  0x33aa000  rw-p   /data/user/0/com.zzvm/files/vm/ubuntu-arm64/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6/libkso.so
		0x7426dd3000       0x7426e1c000    0x49000        0x0  rw-p   

		CryptoPP
		ldd     libkccservice.so
		ldd -v  libkccservice.so


		根据上面拿到的有效定位，再断：
		b *0x0000007CDA30DEA8   => 失败


		liblibsafec.so
		libcrypto.so.1.1

		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/liblibsafec.so                  ~/cxtest
		LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef  LD_PRELOAD=${DIR_WPS}/libcrypto.so.1.1                ~/cxtest



		再得一个结果：
		删除 libkccservice.so ，点击立即登录按钮，不会崩溃


		CryptoPP 已下载，待分析!	=> 不继续分析了。。。

		编译一个最小的可加载的libempty.so ，用来来替换掉 libtcmalloc_minimal.so.4
		cat <<- EOF > libempty.c
		void __attribute__((visibility("default"))) donothing(void) {} // 只导出一个空函数
		EOF

		gcc -shared -fPIC -Os -ffunction-sections -fdata-sections \
			-nostdlib -Wl,--gc-sections,--strip-all,-z,norelro libempty.c -o libempty.so

	其它:
		ltrace    /opt/kingsoft/wps-office/office6/promecefpluginhost --type=zygote --no-zygote-sandbox --no-sandbox
		strace -d /opt/kingsoft/wps-office/office6/promecefpluginhost --type=zygote --no-zygote-sandbox --no-sandbox

		gdb 设置出错断点：
		catch signal 6  #SIGABRT
		catch signal 11 #SIGSEGV
	完
'

DIR_WPS=/opt/kingsoft/wps-office/office6
if [ "${SWNAME}" == "wps-pro" ]; then
DIR_WPS=/opt/apps/cn.wps.wps-office-pro/files/kingsoft/wps-office/office6
fi

# 2025.03.08 处理1/3 postinst 脚本中的 hexdump 读取 libstdc++.so.6 读不到的问题
# 这种有商业版本的软件，不好重新打开它的安装包，所以只能这么处理
function patch1_needed_by_pad_version_only() {
	(cd /usr/lib/aarch64-linux-gnu/ && ln -sf libstdc++.so.6.0.33 libstdc++.so.6.0.30)
}

# 2025.03.08 处理2/3 处理不能登录的问题
function patch2_for_wps_login() {
	[ ! -f ${DIR_WPS}/addons/cef/libm.so.6 ] || mv ${DIR_WPS}/addons/cef/libm.so.6 ${DIR_WPS}/addons/cef/libm.so.6.bak
	exit_if_fail $? "安装失败, 不能登录的问题处理失败"
}

# 2025.03.08 处理3/3 24.04 上无法使用在线模板创建新文档的问题 => 装旧库
function patch3_for_wps_create_newfile_online() {
	: '
	花两天分析了wps在ubuntu-24.04上的依赖库关系，得到以下包名及版本号，下载网址可以这么获取：
	OPTION_SHOW_URL_ONLY="--print-uris"
	sudo apt-get download ${OPTION_SHOW_URL_ONLY} -y libcups2=2.4.1*  libcairo2=1.16.0*  libharfbuzz0b=2.7.4*  libxml2=2.9.13*  libgbm1=23.2.1*  libpango-1.0-0=1.50.6*  |awk '{print $1}'

	查so的归属包: 
	apt-file search libcups.so.2
	apt-file search libfreetype.so.6.18.3
	apt-file search libxkbcommon-x11.so.0


	https://mirrors.tuna.tsinghua.edu.cn/ubuntu-ports/pool/main/f/freetype
	'

	case "${SWNAME}" in
		"wps-free")
				# 字体加粗异常问题的修复包，即旧的freetype库, fix2 版已处理，不再需要在此脚本中另外进行修复
			cat <<- EOF > ${ZZSWMGR_TEMP_DIR}/tmp_deb_list.txt
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/libx/libxml2			libxml2			2.9.14
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/c/cairo				libcairo2		1.16.0
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/h/harfbuzz			libharfbuzz0b	2.7.4
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/p/pango1.0			libpango-1.0-0	1.50.6
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/p/pango1.0			libpangoft2-1.0-0   1.38.1
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/t/tiff				libtiff5		4.3.0
			EOF
			;;
		"wps-pad")
			cat <<- EOF > ${ZZSWMGR_TEMP_DIR}/tmp_deb_list.txt
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/libx/libxml2			libxml2			2.9.13
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/c/cairo				libcairo2		1.16.0
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/c/cups				libcups2		2.4.1
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/m/mesa				libgbm1			23.2.1
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/h/harfbuzz			libharfbuzz0b	2.7.4
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/p/pango1.0			libpango-1.0-0	1.50.6
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/t/tiff				libtiff5		4.3.0
			EOF
			;;
		*)
			cat <<- EOF > ${ZZSWMGR_TEMP_DIR}/tmp_deb_list.txt
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/libx/libxml2			libxml2			2.9.13
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/c/cairo				libcairo2		1.16.0
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/c/cups				libcups2		2.4.1
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/m/mesa				libgbm1			23.2.1
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/h/harfbuzz			libharfbuzz0b	2.7.4
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/p/pango1.0			libpango-1.0-0	1.50.6
				http://${CURR_APT_HOST}/ubuntu-ports/pool/main/t/tiff				libtiff5		4.3.0
			EOF
			;;
	esac

	while read line
	do
		DEB_NAME=
		URL=`echo "${line}"|awk '{print \$1}'`
		LIB=`echo "${line}"|awk '{print \$2}'`
		VER=`echo "${line}"|awk '{print \$3}'`
		# grep "ubuntu"|
		# echo "DEB_NAME: |${DEB_NAME}|"
		DEB_NAME=`ndkwget "$URL"|grep -v dev|grep -v dbg|grep "arm64.deb"|grep "href=\"${LIB}_${VER}[^0-9]"|tail -n 1|awk -F "\"" '{print $4}'`
		if [ "$DEB_NAME" == "" ]; then
		DEB_NAME=`wget "$URL" -O - -q --user-agent="Mozilla"|grep -v dev|grep -v dbg|grep "arm64.deb"|grep "href=\"${LIB}_${VER}[^0-9]"|tail -n 1|awk -F "\"" '{print $4}'`
		fi
		if [ "$DEB_NAME" == "" ]; then
		DEB_NAME=`wget "$URL" -O - -q |grep -v dev|grep -v dbg|grep "arm64.deb"|grep "href=\"${LIB}_${VER}[^0-9]"|tail -n 1|awk -F "\"" '{print $4}'`
		fi
		if [ "$DEB_NAME" == "" ]; then
		DEB_NAME=`/usr/lib/apt/apt-helper download-file "$URL" ./tmp/1.html && cat ./tmp/1.html|grep -v dev|grep -v dbg|grep "arm64.deb"|grep "href=\"${LIB}_${VER}[^0-9]"|tail -n 1|awk -F "\"" '{print $4}'`
		fi
        if [ "$DEB_NAME" == "" ]; then
            echo "URL=\"${URL}\""
            echo "LIB=\"${LIB}\""
            echo "VER=\"${VER}\""
            false
            exit_if_fail $? "安装包下载地址无法获取 ${URL} ${LIB} ${VER}"
        fi

		debUrl="${URL}/${DEB_NAME}"
		debPth="./downloads/${SWNAME}_dependlib_${DEB_NAME}"
		# download_file2 "${debPth}" "${debUrl}"	# wget 请求经常被拦截！
		download_file1 "${debPth}" "${debUrl}"
		exit_if_fail $? "下载失败，网址：${debUrl}"

		dpkg -x ${debPth} ${DIR_WPS}/old-libs
		exit_if_fail $? "安装失败，旧版依赖库安装失败"

		# echo -e "\n\n"
	done < ${ZZSWMGR_TEMP_DIR}/tmp_deb_list.txt
	chmod a+x ${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu/*
	# DIR_WPS=/opt/kingsoft/wps-office/office6
	# LANGUAGE= LD_LIBRARY_PATH=${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu  ${DIR_WPS}/wps

	: '
		# 终端测试
		CURR_APT_HOST=mirrors.tuna.tsinghua.edu.cn
		line="http://${CURR_APT_HOST}/ubuntu-ports/pool/main/libx/libxml2			libxml2			2.9.13"
		URL=`echo "${line}"|awk '{print \$1}'`
		LIB=`echo "${line}"|awk '{print \$2}'`
		VER=`echo "${line}"|awk '{print \$3}'`
		DEB_NAME=`wget "$URL" -O - -q |grep -v dev|grep -v dbg|grep "arm64.deb"|grep "href=\"${LIB}_${VER}[^0-9]"|tail -n 1|awk -F "\"" '{print $4}'`
		echo "获取到的包名: |${DEB_NAME}|"
	'
}

function patch4_for_wps_starter() {
	# 2024.08.03 添加, 用以处理界面默认为英文的问题
	sed -i "s|Exec=|Exec=env LANGUAGE= LD_LIBRARY_PATH=${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu:${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}/addons/kcef |g" /usr/share/applications/wps*.desktop
	sed -i "s|Exec=|Exec=env LANGUAGE= LD_LIBRARY_PATH=${DIR_WPS}/old-libs/usr/lib/aarch64-linux-gnu:${DIR_WPS}:${DIR_WPS}/addons/cef:${DIR_WPS}/addons/kcef |g" /home/${ZZ_USER_NAME}/Desktop/wps*.desktop
	case "${SWNAME}" in
		"wps-pad")
			[ -d /tablet ] || mkdir /tablet
			rm -rf /tablet/sd卡
			rm -rf /tablet/桌面
			(cd /tablet && ln -sf /sdcard  ./SD卡)
			(cd /tablet && ln -sf /home/droidvm/Desktop  ./桌面)
			;;
		*)
			:
			;;
	esac
}


function patch5_for_wps_pro_only() {
	# 创建文档按钮不崩溃
	[ ! -f ${DIR_WPS}/wpsoffice ]                || mv ${DIR_WPS}/wpsoffice                ${DIR_WPS}/wpsoffice.bak
	[ ! -f ${DIR_WPS}/libtcmalloc_minimal.so.4 ] || mv ${DIR_WPS}/libtcmalloc_minimal.so.4 ${DIR_WPS}/libtcmalloc_minimal.so.4.bak
	cp -f ./scripts/res/libempty.so                    ${DIR_WPS}/libtcmalloc_minimal.so.4

	# 点击立即登录不崩溃
	[ ! -f ${DIR_WPS}/libkccservice.so ]         || mv ${DIR_WPS}/libkccservice.so                ${DIR_WPS}/libkccservice.so.bak
}

function patch6_for_wps_365_only() {
	# 扫码登录后不闪退
	rm -rf ${DIR_WPS}/libstdc++.so.6
	cp -f ${DIR_WPS}/libstdc++.so.6.0.21 ${DIR_WPS}/libstdc++.so.6
}
