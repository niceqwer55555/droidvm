
tmpfile=${ZZSWMGR_RMSH_DIR}/"卸载-"${pkgname}.sh
cat <<- EOF > ${tmpfile}
	#!/bin/bash
	# exec /usr/bin/code_ori ${ZZVM_ARGS} \$@
	sudo apt autoremove --purge -y              ${pkgname}
	sudo dpkg --remove --force-remove-reinstreq ${pkgname}
EOF
chmod 755 ${tmpfile}


新增软件参考:
YesPlayMusic.sh
alist.sh
motrix.sh
EGzip.sh
peazip.sh
xvkbd, filezilla		# apt 仓库中的软件, 其中 xvkb 带自启动
clash.sh -> lxmusic		# install_deb, 带卸载
mixly					# git clone
