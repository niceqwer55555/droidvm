#!/bin/bash

SWNAME=zwcad2024
PKNAME=zwcad2024
DEB_PATH=./downloads/${SWNAME}.deb
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {

	if [ "${CURRENT_VM_ARCH}" != "arm64" ]; then
		exit_unsupport
	fi

	# 主包需要自己从网下载: https://www.zwsoft.cn/product/zwcad/linux?year=2024
	if [ ! -f ${DEB_PATH} ]; then
		select_deb ${DEB_PATH}
	else
		echo "安装包已下载过"
	fi

}

function sw_remove() {
	[ "${PKNAME}" != "" ] || exit_if_fail $? "sw_remove 失败"

	apt-get -y purge "${PKNAME}"
	apt-get -y autoremove --purge "${PKNAME}"
	dpkg --remove --force-remove-reinstreq "${PKNAME}"

	echo "正在删除桌面图标"
	rm2desktop "${PKNAME}"*

	echo "正在删除软件图标"
	rm -rf /usr/share/applications/"${PKNAME}"*

	echo "正在删除相关配置文件"
	rm -rf /home/${ZZ_USER_NAME}/.local/share/ZWSOFT
	rm -rf /home/${ZZ_USER_NAME}/.config/ZWSOFT

	echo "正在删除主安装文件夹"
	rm -rf /opt/apps/"${PKNAME}"

	echo "正在删除软件的卸载脚本"
	rm -rf /var/lib/dpkg/info/"${PKNAME}"*

}

function sw_install() {

	issame_cpu_arch "${DEB_PATH}"
	exit_if_fail $? "安装包的CPU架构不匹配，请下载${CURRENT_VM_ARCH}版本的deb安装包"

	sudo apt-get install -y \
	libxkbcommon-x11-0 libglu1-mesa \
	${ZZSWMGR_MAIN_DIR}/${DEB_PATH}
	exit_if_fail $? "安装失败，主包安装失败"
}

function sw_create_desktop_file() {
	:
}

if [ "${action}" == "卸载" ]; then
	sw_remove
else
	sw_download
	sw_install
	sw_create_desktop_file
fi
