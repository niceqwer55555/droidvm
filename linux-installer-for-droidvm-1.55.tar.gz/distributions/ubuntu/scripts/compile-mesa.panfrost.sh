#!/bin/bash

action=$1
if [ "$action" == "" ]; then action=安装; fi

SWNAME=mesa
swVer=23.2.1

SWMGR_DIR=`pwd`
TMPDIR=${SWMGR_DIR}/tmp
export SRC_DIR="${TMPDIR}/${SWNAME}-${swVer}"
echo "SRC_DIR: ${SRC_DIR}"

abis="arm64-v8a"  #arm64-v8a armeabi-v7a x86_64 x86


. ./scripts/common.sh


function sw_download() {

	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh      packages.microsoft.com`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	sudo apt-get -y install dpkg-dev xz-utils mesa-utils
	exit_if_fail $? "dpkg-dev安装失败"

	zz_enable_src_apt

	# exit 1

	if [ ! -d ${SRC_DIR} ]; then
		cd ${TMPDIR}
		apt-get source ${SWNAME}
		exit_if_fail $? "从apt仓库下载源码失败, 源码项目名称：${SWNAME}"

		# sudo apt build-dep -y -aarmhf ${SWNAME} # 可以指定架构
		sudo apt build-dep -y ${SWNAME}
		exit_if_fail $? "源码项目编译过程的依赖库/依赖程序安装失败"

		echo "正在修改源码"
		# export SRC_DIR=/exbin/tools/zzswmgr/tmp/mesa-23.2.1
		cd ${SRC_DIR}
		cat ${SRC_DIR}/src/gallium/targets/dri/meson.build|grep "'ln'"
		sed -i "s|'ln'|'cp'|"   ${SRC_DIR}/src/gallium/targets/dri/meson.build
		cat ${SRC_DIR}/src/gallium/targets/dri/meson.build|grep "'cp'"
		exit_if_fail $? "源码修改失败：${SWNAME}"

		# echo "正在修改源码"
		# cd ${SRC_DIR}
		# patch -p1 < ${SWMGR_DIR}/scripts/res/libfm.patch
		# exit_if_fail $? "源码修改失败：${SWNAME}"

		# # # 有些项目的源码，修改后需要 commit 才能编译, 比如 libfm, 实测 weston 不需要，反而还省点事了
		# # # dpkg-source --commit
	else
		:
		# echo "正在修改源码"
		# cd ${SRC_DIR}
		# patch -p1 < ${SWMGR_DIR}/scripts/res/libfm.patch
		# exit_if_fail $? "源码修改失败：${SWNAME}"
	fi


}

function sw_compile() {

	# command -v patchelf >/dev/null 2>&1 || sudo apt-get install -y patchelf
	# exit_if_fail $? "patchelf 安装失败"

	for abi in ${abis}
	do
		echo -e "\n当前架构: ${abi}"
		mkrlt=2
		case "${abi}" in
			"arm64-v8a")
				CPLARCH=aarch64
				OS_ARCH=arm64
				;;
			"armeabi-v7a")
				CPLARCH=armv7a
				OS_ARCH=arm32
				;;
			"x86_64")
				CPLARCH=x86_64
				OS_ARCH=amd64
				;;
			"x86")
				CPLARCH=i686
				OS_ARCH=amd32
				;;
			*)
				echo "不支持的abi: |${abi}|"
				exit 2
				;;
		esac

		export INSTALL_DIR="${SRC_DIR}/release/${OS_ARCH}"
		mkdir -p "$INSTALL_DIR"

		cd ${SRC_DIR}
		pwd

		echo "正在编译"
		# # dpkg-buildpackage -nc -us -uc -j12 -aarmhf # 可以指定架构
		# dpkg-buildpackage -nc -us -uc -j12
		# exit_if_fail $? "编译失败"

		export MESA_INSTALLDIR=/usr/lib/mesa.panfrost
		meson setup build/   \
		-Dprefix="$MESA_INSTALLDIR" \
		-Dvulkan-drivers= \
		-Dgallium-drivers=panfrost,virgl,swrast \
		-Dllvm=enabled \
		-Ddri3=enabled
		exit_if_fail $? "编译失败1: fail to meson setup"
		# -Ddri-drivers-path="$MESA_INSTALLDIR"/dri

		meson compile -C build/
		exit_if_fail $? "编译失败2: fail to meson compile"

		sudo meson install -C build/
		exit_if_fail $? "编译失败3: fail to meson install"

		echo "编译成功，已安装到: ${MESA_INSTALLDIR}"


		echo "正在生成桌面文件"
		chmod 755 /exbin/tools/zzswmgr/ezapp/mesa/mesa_demo.sh
		tmpfile=${DIR_DESKTOP_FILES}/${SWNAME}.desktop
		cat <<- EOF > ${tmpfile}
			[Desktop Entry]
			Encoding=UTF-8
			Version=0.9.4
			Type=Application
			Name=Mesa测试
			Comment=Mesa测试
			Icon=/exbin/tools/zzswmgr/appicons/mesa.svg
			Exec=/exbin/tools/zzswmgr/ezapp/mesa/mesa_demo.sh
			Terminal=true
		EOF
		cp2desktop ${tmpfile}

		# LD_LIBRARY_PATH="$MESA_INSTALLDIR:$MESA_INSTALLDIR/dri" glxinfo	# 运行
		# meson devenv -C build glxinfo									# 运行

		# echo "正在打包"
		# cp  -f ${SRC_DIR}/../ jwm_${swVer}-1_arm64.deb		${INSTALL_DIR}/
		# echo "编译完成，请查看：$INSTALL_DIR"

	done
}

function sw_create_desktop_file() {
	echo ""
}

if [ "${action}" == "卸载" ]; then
	rm -rf /usr/lib/mesa.panfrost
	rm -rf ${SRC_DIR}
	echo "暂不支持卸载"
	exit 1
else
	sw_download
	sw_compile
	sw_create_desktop_file
fi


: '

参考：
1). https://docs.mesa3d.org/drivers/panfrost.html
2). https://docs.mesa3d.org/install.html
3). https://docs.mesa3d.org/meson.html
4). https://www.cnblogs.com/ArsenalfanInECNU/p/16844535.html

...


官方源码(未deb化)：
https://archive.mesa3d.org/
https://archive.mesa3d.org/mesa-23.2.1.tar.xz
https://gitlab.freedesktop.org/mesa/mesa

非官方源码：(仅支持G610/G710两款GPU)
https://github.com/Saikatsaha1996/mesa-Panfrost-G610

依赖库： sudo apt build-dep -y mesa
sudo apt install -y mesa-utils glslang-tools llvm-dev \
meson gcc python3-mako libdrm-dev byacc flex libwayland-egl-backend-dev \
libx11-xcb-dev libxcb-glx0-dev libxcb-dri2-0-dev libxcb-dri3-dev \
libxcb-present-dev libxshmfence-dev libxxf86vm-dev libxrandr-dev


cd ${tools_dir}/zzswmgr/tmp/mesa-23.2.1
meson setup .  build/ -Dvulkan-drivers= -Dgallium-drivers=panfrost -Dllvm=disabled
ninja -C build/
meson install  -C build/

以下编译指令测试通过，但会多编译很多的C源码文件，比较耗时，整个编译过程总体耗时约10分钟：
export MESA_INSTALLDIR=/usr/lib/mesa.panfrost
# meson setup --wipe build/ # 等效于 make clean
# 支持的gallium-drivers包括: (只要值列表中有一个错，就会列出如下内容)
# ERROR: Options "llvmpipe, softpipe" are not in allowed choices: "auto, kmsro, radeonsi, r300, r600, nouveau, 
# freedreno, swrast, v3d, vc4, etnaviv, tegra, i915, svga, virgl, panfrost, iris, lima, zink, d3d12, asahi, crocus"
meson setup build/   \
-Dprefix="$MESA_INSTALLDIR" \
-Dvulkan-drivers= \
-Dgallium-drivers=panfrost,swrast \
-Dllvm=enabled \
-Ddri3=enabled \
-Ddri-drivers-path="$MESA_INSTALLDIR"/dri
meson compile -C build/
sudo meson install -C build/
LD_LIBRARY_PATH="$MESA_INSTALLDIR:$MESA_INSTALLDIR/dri" glxinfo	# 运行
meson devenv -C build glxinfo									# 运行

swrast_dri.so 不兼容!
cp -fi  /usr/lib/aarch64-linux-gnu/dri/swrast_dri.so  /usr/local/lib/aarch64-linux-gnu/dri/

重要修改！
src/gallium/targets/dri/meson.build 中的ln -f srcfile dstfile 指令，在proot环境中，即使给 proot 加了 --link2symlink 参数，ln -f仍可能会运行失败
因为安卓的不允许对文件做硬链接，可以将ln指令替换成cp指令，或者将 ln -f 改成 ln -sf

sudo ldconfig -p | grep -i gl.so


export LIBGL_DEBUG=verbose
export GALLIUM_DRIVER=panfrost
export MESA_GL_VERSION_OVERRIDE=3.0
export LIBGL_DRIVERS_PATH=/usr/lib/"$MESA_INSTALLDIR"/dri
export LIBGL_DRIVERS_PATH=/exbin/tools/zzswmgr/tmp/mesa-23.2.1/build/src/gallium/targets/dri
LD_LIBRARY_PATH=/usr/local/lib/aarch64-linux-gnu/dri/:/usr/local/lib/aarch64-linux-gnu:/usr/lib/aarch64-linux-gnu  glxinfo
LD_LIBRARY_PATH=/usr/local/lib/aarch64-linux-gnu/dri/:/usr/local/lib/aarch64-linux-gnu:/usr/lib/aarch64-linux-gnu  glmark2


查询so文件属于哪个包：
sudo apt-get install apt-file
sudo apt-file update
apt-file search swrast_dri.so	# 发现so在这个apt包里面：libgl1-mesa-dri

查看dri相关的库文件：
LD_LIBRARY_PATH=/usr/local/lib/aarch64-linux-gnu/dri/:/usr/local/lib/aarch64-linux-gnu:/usr/lib/aarch64-linux-gnu  \
dpkg -L libgl1-mesa-dri


测试：
	export GALLIUM_DRIVER=panfrost
	export MESA_GL_VERSION_OVERRIDE=3.0
	export MESA_INSTALLDIR=/usr/lib/mesa.panfrost
	LD_LIBRARY_PATH="$MESA_INSTALLDIR/lib/aarch64-linux-gnu:$MESA_INSTALLDIR/dri" glxinfo | grep "OpenGL renderer"
	LD_LIBRARY_PATH="$MESA_INSTALLDIR/lib/aarch64-linux-gnu:$MESA_INSTALLDIR/dri" glmark2

	或者:
	cd /exbin/tools/zzswmgr/tmp/mesa-23.2.1/
	export GALLIUM_DRIVER=panfrost
	unset GALLIUM_DRIVER
	unset MESA_GL_VERSION_OVERRIDE
	unset LIBGL_DRIVERS_PATH
	unset MESA_LOADER_DRIVER_OVERRIDE
	unset LD_LIBRARY_PATH
	meson devenv -C build glxinfo | grep "OpenGL renderer"

	或者:
	export GALLIUM_DRIVER=panfrost
	export MESA_GL_VERSION_OVERRIDE=3.0
	export MESA_INSTALLDIR=/usr/lib/mesa.panfrost
	export LIBGL_DRIVERS_PATH=${MESA_INSTALLDIR}/dri
	export MESA_LOADER_DRIVER_OVERRIDE=panfrost
	LD_LIBRARY_PATH=${MESA_INSTALLDIR}/dri:${MESA_INSTALLDIR}/lib/aarch64-linux-gnu:/usr/lib/aarch64-linux-gnu  glmark2
	LD_LIBRARY_PATH=${MESA_INSTALLDIR}/dri:${MESA_INSTALLDIR}/lib/aarch64-linux-gnu:/usr/lib/aarch64-linux-gnu  glxinfo | grep "OpenGL renderer"


搜索： cat  ./mesa-23.0.0/meson.build  | grep "Please pass"
-Dplatforms=x11 wayland surfaceless drm xcb
-Dplatforms=x11 surfaceless drm xcb

'



