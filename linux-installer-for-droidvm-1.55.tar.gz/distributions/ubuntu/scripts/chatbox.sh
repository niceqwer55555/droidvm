#!/bin/bash

SWNAME=chatbox
# SWVER=18.2.3

# 注意安装顺序，后装者依赖前装者
DEB_PATH1=./downloads/${SWNAME}.deb

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}
app_dir=/opt/apps/${SWNAME}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh ${GITHUB_PROXY_HOST}`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	case "${CURRENT_VM_ARCH}" in
		"arm64")
			swUrl="https://download.chatboxai.app/releases/Chatbox-1.5.1-arm64.deb"
			download_file1 "${DEB_PATH1}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		;;
		"amd64") exit_unsupport ;;
		*) exit_unsupport ;;
	esac
}

function sw_install() {
	echo "正在安装. . ."
	install_deb ${DEB_PATH1}
	exit_if_fail $? "安装失败，软件包：${DEB_PATH1}"
}

function sw_create_desktop_file() {
	echo "正在生成桌面文件"

	tmpfile=${DIR_DESKTOP_FILES}/xyz.chatboxapp.app.desktop
	sed -i "s| %U| %U  --no-sandbox|g" ${tmpfile}
	cp2desktop ${tmpfile}

	gxmessage -title "提示"     $'\n安装完成\n\n'  -center
}

if [ "${action}" == "卸载" ]; then
	# # echo "暂不支持卸载"
	# # exit 1
	# rm -rf ${DEB_PATH1}

	# rm -rf /usr/bin/${SWNAME}

	# rm -rf /opt/apps/${SWNAME}

	apt purge -y --autoremove xyz.chatboxapp.app

	rm2desktop ${SWNAME}.desktop
	rm2desktop xyz.chatboxapp.app.desktop

	apt-get clean
else
	sw_download
	sw_install
	sw_create_desktop_file
fi

