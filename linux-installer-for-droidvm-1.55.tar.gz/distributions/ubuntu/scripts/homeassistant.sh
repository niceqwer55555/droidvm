#!/bin/bash

: '

会创建 hardlink ，在安卓上是不允许的！

'

SWNAME=homeassistant
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}
app_dir=/opt/apps/${SWNAME}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh


function sw_download() {
	case "${CURRENT_VM_ARCH}" in
		"arm64")
				echo ""
				;;
		"amd64")
				exit_unsupport
				;;
		*) exit_unsupport ;;
	esac

}

function sw_install() {
	case "${CURRENT_VM_ARCH}" in
		"arm64")
				apt_pkgs="python3 python3-pip"
				apt_pkgs="${apt_pkgs} python3-venv virtualenv"
				apt-get install -y ${apt_pkgs}
				exit_if_fail $? "依赖库安装失败"


				echo "正在将pip下载仓库地址换成国内的. . ."
				pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

				echo "正在创建python vENV"
				python3 -m venv ${app_dir}

				echo "正在将vENV中的pip的下载仓库地址换成国内的"
				${app_dir}/bin/pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
				exit_if_fail $? "pip仓库设置出错"

				echo "正在通过pip安装组件"
				${app_dir}/bin/pip install homeassistant==2023.6.3
				exit_if_fail $? "依赖库安装失败"

				;;
		"amd64")
				exit_unsupport
				;;
		*) exit_unsupport ;;
	esac
}

function sw_create_desktop_file() {
	echo ""
}

if [ "${action}" == "卸载" ]; then
	echo "暂不支持卸载"
	exit 1
else
	sw_download
	sw_install
	sw_create_desktop_file
fi
