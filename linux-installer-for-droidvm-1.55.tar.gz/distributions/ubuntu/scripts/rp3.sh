#!/bin/bash

SWNAME=rp3

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh


if [ "${action}" == "卸载" ]; then
	sudo apt update -y
	sudo apt-get install --fix-missing -y
else
	sudo apt-get install --fix-missing -y
fi

