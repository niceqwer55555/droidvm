#!/bin/bash

SWNAME=wps-365
PKNAME=wps-office
DEB_PATH=./downloads/${SWNAME}.deb
FT_PATH1=./downloads/ttf-wps-fonts.tar.xz
FT_PATH2=./downloads/ttf-mst-fonts.tar.xz
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {

	if [ "${CURRENT_VM_ARCH}" != "arm64" ]; then
		exit_unsupport
	fi

	# # 下载主安装包, 官网上的安装包变来变去，依赖库难以持续跟进适配，请从资源群下载安装包
	# swUrl="https://wps-linux-365.wpscdn.cn/wps/download/ep/Linux365/20327/wps-office_12.8.2.20327.AK.preload.sw_arm64.deb"
	# download_file2 "${DEB_PATH}" "${swUrl}"
	# exit_if_fail $? "下载失败，网址：${swUrl}"

	# 主包需要自己从网下载
	if [ ! -f ${DEB_PATH} ]; then
		select_deb ${DEB_PATH}
	else
		echo "已下载过wps安装包"
	fi

	# 下载wps字体
	swUrl=https://gitee.com/ak2/ttf-wps-fonts/raw/master/ttf-wps-fonts.tar.xz
	download_file2 "${FT_PATH1}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

	# 下载ms字体
	swUrl=https://gitee.com/ak2/msttcorefonts/raw/master/msttcorefonts.tar.xz
	download_file2 "${FT_PATH2}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

}

function sw_remove() {
	[ "${PKNAME}" != "" ] || exit_if_fail $? "sw_remove 失败"

	apt-get -y purge "${PKNAME}"
	apt-get -y autoremove --purge "${PKNAME}"
	dpkg --remove --force-remove-reinstreq "${PKNAME}"

	echo "正在删除桌面图标"
	rm2desktop "${PKNAME}"*
	
	echo "正在删除软件图标"
	rm -rf /usr/share/applications/"${PKNAME}"*

	echo "正在删除相关配置文件"
	rm -rf /home/${ZZ_USER_NAME}/.local/share/Kingsoft
	rm -rf /home/${ZZ_USER_NAME}/.config/Kingsoft

	echo "正在删除主安装文件夹"
	rm -rf /opt/kingsoft/"${PKNAME}"

	echo "正在删除软件的卸载脚本"
	rm -rf /var/lib/dpkg/info/"${PKNAME}"*

}

function sw_install() {

	issame_cpu_arch "${DEB_PATH}"
	exit_if_fail $? "安装包的CPU架构不匹配，请下载${CURRENT_VM_ARCH}版本的deb安装包"

	# 这个包安装太耗时，这里生成一个空deb来跳过，后面的代码会从gitee下载这份字体
	TMP_PKG_NAME="ttf-mscorefonts-installer"
	apt list --installed|grep "${TMP_PKG_NAME}"
	if [ $? -ne 0 ]; then
		makedeb "${TMP_PKG_NAME}" "3.8.1ubuntu1"
		if [ "${DEB_OUT}" != "" ]; then
			dpkg -i --force-overwrite ${DEB_OUT}
		fi
	fi

	echo "正在安装wps字体"
	tar -Jxvf "${FT_PATH1}" --overwrite -C /
	exit_if_fail $? "wps字体安装失败"

	echo "正在安装ms字体"
	tar -Jxvf "${FT_PATH2}" --overwrite -C /
	exit_if_fail $? "ms字体安装失败"

	echo "正在更新字体缓存"
	sudo fc-cache -f -v

	echo "正在安装主包"
	# 2025.04.02 添加: libxkbcommon-x11-0
	# --allow-downgrades libglu1-mesa libxslt-dev bsdmainutils 
	sudo apt-get install -y libxkbcommon-x11-0  ${ZZSWMGR_MAIN_DIR}/${DEB_PATH}
	exit_if_fail $? "安装失败，主包安装失败"

	# 导入补丁脚本 2025.03.08
	. ./scripts/wps-patches-for-droidvm-ubuntu-24.04-2025.03.09.sh
	patch2_for_wps_login
	patch3_for_wps_create_newfile_online
	patch6_for_wps_365_only


	# 错误1：找不到 libproviders.so 
	# 是因为虚拟电脑使用的rootfs较新，带的openssl也较新, export OPENSSL_CONF=/dev/null 可以不报此错误

	# 错误2：Some formula symbols might not be displayed correctly due to missing fonts. 缺失字体
	# https://gitee.com/ak2/ttf-wps-fonts
	# https://gitee.com/ak2/msttcorefonts

	# 错误3：backup fail/backup目录不可设置，backup功能不可关闭
	# 还是proot环境不能处理 mount 映射，导致wps把备份目录识别成只读的(/home/droidvm/.local/share/Kingsoft/office6/data/backup)
}

function sw_create_desktop_file() {
	patch4_for_wps_starter
}

function check_installed() {
	dpkg-query -l ${PKNAME} 2>/dev/null
	if [ $? -eq 0 ]; then
		gxmessage -title "请确认" $'\n系统中已安装过wps。\n若它无法运行，建议清除后再继续安装\n\n是否先将其清除？\n\n'  -center -buttons "清除掉:0,不清除:1,取消安装:2"
		case "$?" in
			"0")
				sw_remove
				;;
			"1")
				:
				;;
			*) 
				echo "您已取消安装"
				exit 1
				;;
		esac
	fi
}

if [ "${action}" == "卸载" ]; then
	sw_remove
else
	check_installed
	sw_download
	sw_install
	sw_create_desktop_file
fi
