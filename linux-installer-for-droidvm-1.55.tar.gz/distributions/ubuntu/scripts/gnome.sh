#!/bin/bash

SWNAME=gnome

action=$1
if [ "$action" == "" ]; then action=安装; fi

# pwd
. ./scripts/common.sh


if [ "${action}" == "卸载" ]; then
  sudo apt-get remove -y ${SWNAME} language-pack-gnome-zh-hans*
  rm -rf ${app_home}/app_boot_config/cfg_de.txt
else

  gxmessage -title "是否继续安装？" $'\n不建议不熟悉linux环境的新手在虚拟电脑中使用gnome\n\n虚拟电脑集成的所有界面类脚本都是针对jwm+pcmanfm桌面环境整理的\n使用gnome将不能使用虚拟电脑集成的各类便捷脚本\n\n'  -center -buttons "继续安装:0,取消安装:1"
  case "$?" in
    "0")
      :
      ;;
    *) 
      echo "您已取消安装"
      exit 1
      ;;
  esac

  sudo apt-get install -y --no-install-recommends ${SWNAME}
  exit_if_fail $? "${SWNAME} 安装失败"

  sudo apt-get install -y language-pack-gnome-zh-hans*
  exit_if_fail $? "${SWNAME} 专用的简体中文包安装失败"

  echo "gnome" > ${app_home}/app_boot_config/cfg_de.txt

  echo "${SWNAME}安装完成."
  gxmessage -title "提示" "${SWNAME}安装完成, 重启生效"  -center &

fi

: '
# 这样能起来了，但没有桌面图标!
dbus-launch --exit-with-session gnome-session &     # 得先运行这个!
export XDG_SESSION_TYPE=x11
# 这个能启动 gnome-control-center
export XDG_CURRENT_DESKTOP='ubuntu:GNOME'
gnome-shell   # gnome-shell -r --x11 --force-animations
nautilus
gnome-tweaks  # 设置程序
gnome-terminal


pkill -f gnome-session-binary
pkill gnome-shell


桌面还是没图标
sudo apt install -y gnome-shell-extension-desktop-icons-ng

'
