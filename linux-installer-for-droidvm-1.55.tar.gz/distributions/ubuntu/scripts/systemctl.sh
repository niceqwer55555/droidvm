#!/bin/bash

SWNAME=fakesystemd
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_install() {
	cp -Rf ./ezapp/systemctl/systemctl.sh /usr/bin/systemctl
	exit_if_fail $? "安装失败，无法复制文件到 /usr/bin/"

	chmod 755 /usr/bin/systemctl
	exit_if_fail $? "安装失败，无法添加可执行权限"

	DIR_SERVICE_AUTOSTART=/etc/systemd/system/multi-user.target.wants
	BAK_SERVICE_AUTOSTART=/etc/systemd/system/multi-user.target.wants.bak
	if [ ! -d ${BAK_SERVICE_AUTOSTART} ]; then
		rm -rf ${BAK_SERVICE_AUTOSTART} 2>/dev/null
		mv -f ${DIR_SERVICE_AUTOSTART}  ${BAK_SERVICE_AUTOSTART}
		exit_if_fail $? "安装失败，无法备份目录"
	fi
	if [ ! -d ${DIR_SERVICE_AUTOSTART} ]; then
		rm -rf ${DIR_SERVICE_AUTOSTART} 2>/dev/null
		mkdir -p ${DIR_SERVICE_AUTOSTART} 2>/dev/null
		[ $? -ne 0 ] || echo "安装失败，无法创建 systemd 自启动脚本目录"
	fi
	rm -rf ${DIR_SERVICE_AUTOSTART}/*
}

function sw_create_desktop_file() {
	echo "安装已完成"
	gxmessage -title "提示" "安装已完成"  -center
}

if [ "${action}" == "卸载" ]; then
	echo "暂不支持卸载"
	exit 1
else
	# sw_download
	sw_install
	sw_create_desktop_file
fi
