#!/bin/bash

SWNAME=xfce4-theme-osx11
DEB_PATH1=./downloads/${SWNAME}.tar.gz

action=$1
if [ "$action" == "" ]; then action=安装; fi

# pwd
. ./scripts/common.sh

if [ "${action}" == "卸载" ]; then
	echo "暂不支持卸载"
	exit 1
else

	which startxfce4 >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo ""				      		> /tmp/msg.txt
		echo "xfce4未安装，请先安装"	>>/tmp/msg.txt
		echo ""				      		>>/tmp/msg.txt
		gxmessage -title "提示" -file /tmp/msg.txt -center
		exit 1
	fi

	# swUrl="http://192.168.1.5/apps/droidvm/downloads/xfce4-theme-osx11.tar.gz"
	swUrl="https://gitee.com/droidvm/xfce4-theme/raw/master/xfce4-theme-osx11.tar.gz"
	download_file2 "${DEB_PATH1}" "${swUrl}"
	exit_if_fail $? "xfce4主题包下载失败"

	echo "正在解压. . ."
	tar -xzf ${DEB_PATH1} --overwrite -C /
	exit_if_fail $? "xfce4主题包解压失败"

	cp -f /usr/share/backgrounds/xfce/xfce-flower.svg  /usr/share/backgrounds/

	sudo -u ${ZZ_USER_NAME} mkdir -p ${ZZ_USER_HOME}/.config/xfce4/xfconf/xfce-perchannel-xml

	echo "正在xfce4配置任务栏"
	sudo -u ${ZZ_USER_NAME} cat <<- EOF > ${ZZ_USER_HOME}/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml
		<?xml version="1.0" encoding="UTF-8"?>

		<channel name="xfce4-panel" version="1.0">
		  <property name="configver" type="int" value="2"/>
		  <property name="panels" type="array">
			<value type="int" value="1"/>
			<property name="dark-mode" type="bool" value="false"/>
			<property name="panel-1" type="empty">
			  <property name="position" type="string" value="p=8;x=960;y=982"/>
			  <property name="length" type="uint" value="100"/>
			  <property name="position-locked" type="bool" value="true"/>
			  <property name="icon-size" type="uint" value="18"/>
			  <property name="size" type="uint" value="61"/>
			  <property name="plugin-ids" type="array">
				<value type="int" value="1"/>
				<value type="int" value="2"/>
				<value type="int" value="3"/>
				<value type="int" value="5"/>
				<value type="int" value="6"/>
				<value type="int" value="8"/>
				<value type="int" value="11"/>
				<value type="int" value="12"/>
				<value type="int" value="13"/>
			  </property>
			  <property name="background-style" type="uint" value="0"/>
			  <property name="background-rgba" type="array">
				<value type="double" value="0.34117599999999998"/>
				<value type="double" value="0.89019599999999999"/>
				<value type="double" value="0.53725500000000004"/>
				<value type="double" value="1"/>
			  </property>
			  <property name="enter-opacity" type="uint" value="72"/>
			  <property name="leave-opacity" type="uint" value="72"/>
			</property>
		  </property>
		  <property name="plugins" type="empty">
			<property name="plugin-1" type="string" value="applicationsmenu">
			  <property name="button-icon" type="string" value="applications-all"/>
			  <property name="show-button-title" type="bool" value="true"/>
			  <property name="show-generic-names" type="bool" value="false"/>
			</property>
			<property name="plugin-2" type="string" value="tasklist">
			  <property name="grouping" type="uint" value="1"/>
			</property>
			<property name="plugin-3" type="string" value="separator">
			  <property name="expand" type="bool" value="true"/>
			  <property name="style" type="uint" value="0"/>
			</property>
			<property name="plugin-5" type="string" value="separator">
			  <property name="style" type="uint" value="0"/>
			</property>
			<property name="plugin-6" type="string" value="systray">
			  <property name="square-icons" type="bool" value="true"/>
			  <property name="known-items" type="array">
				<value type="string" value="Fcitx"/>
				<value type="string" value="vlc"/>
			  </property>
			</property>
			<property name="plugin-8" type="string" value="pulseaudio">
			  <property name="enable-keyboard-shortcuts" type="bool" value="true"/>
			  <property name="show-notifications" type="bool" value="true"/>
			  <property name="mpris-players" type="string" value="vlc"/>
			</property>
			<property name="plugin-9" type="string" value="power-manager-plugin"/>
			<property name="plugin-11" type="string" value="separator">
			  <property name="style" type="uint" value="0"/>
			</property>
			<property name="plugin-12" type="string" value="clock">
			  <property name="tooltip-format" type="string" value="%A %d %B %Y"/>
			  <property name="digital-format" type="string" value="%_H:%M"/>
			  <property name="digital-time-format" type="string" value="%_H:%M"/>
			  <property name="digital-layout" type="uint" value="3"/>
			</property>
			<property name="plugin-13" type="string" value="separator">
			  <property name="style" type="uint" value="0"/>
			</property>
		  </property>
		</channel>
	EOF
	exit_if_fail $? "xfce4任务栏配置失败"

	# 外观.主题
	sudo -u ${ZZ_USER_NAME} xfconf-query -c xsettings -p /Net/ThemeName -s "osx11-light"  --create -t string
	exit_if_fail $? "xfce4 外观.主题 配置失败"

	# 外观.图标
	sudo -u ${ZZ_USER_NAME} xfconf-query -c xsettings -p /Net/IconThemeName -s 'osx11-light'  --create -t string
	exit_if_fail $? "xfce4 外观.图标 配置失败"

	# 窗口.主题
	sudo -u ${ZZ_USER_NAME} xfconf-query -c xfwm4     -p /general/theme -s "osx11-light"  --create -t string
	exit_if_fail $? "xfce4 窗口.主题 配置失败"

	sudo -u ${ZZ_USER_NAME} xfconf-query -c xfwm4     -p /general/inactive_opacity -s 88  --create -t int
	exit_if_fail $? "xfce4 窗口.失焦窗口透明度 配置失败"

	sudo -u ${ZZ_USER_NAME} xfconf-query -c xfwm4     -p /general/move_opacity -s 88  --create -t int
	exit_if_fail $? "xfce4 窗口.移动窗口透明度 配置失败"

	# 桌面.壁纸
	sudo -u ${ZZ_USER_NAME} xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitorscreen/workspace0/last-image  -s /usr/share/backgrounds/osx-default.png  --create -t string
	exit_if_fail $? "xfce4 桌面.壁纸 配置失败"

	echo "安装完成."
	gxmessage -title "提示" "安装完成, 重启生效"  -center &
fi

: '

背景图片：
/usr/share/backgrounds/xfce/xfce-flower.svg

切换 xfce4-win10 主题步骤：

为便于在电脑端操作，开的远程终端
ttyd.aarch64 -W -p 5559 -t enableZmodem=true -t enableTrzsz=true -t fontSize 16 bash


第一步：下载并解压win10主题包，解压用的unzip指令
wget https://codeload.github.com/B00merang-Project/Windows-10/zip/refs/tags/3.2.1           -O /tmp/win10_white.zip
wget ${GITHUB_PROXY_HTTP}https://github.com/B00merang-Project/Windows-10-Dark/archive/refs/tags/3.2.1-dark.zip  -O /tmp/win10_black.zip
(cd /usr/share/themes/ && unzip -o /tmp/win10_white.zip )
(cd /usr/share/themes/ && unzip -o /tmp/win10_black.zip )
mv /usr/share/themes/Windows-10-3.2.1           /usr/share/themes/win10_white
mv /usr/share/themes/Windows-10-Dark-3.2.1-dark /usr/share/themes/win10_black


第二步：对xfce4外观进行手动设置，外观设置分几个类别

1). 运行这个指令，打开外观设置程序
xfce4-settings-manager

2). 点 "窗口管理器 " 图标项，
样式选 win10_white 或 win10_black

设置完点窗口底部的 返回所有设置 按钮

3). 点 "外观" 图标项，
样式选 win10_white 或 win10_black




# WhiteSur-gtk-theme
# https://github.com/zayronxio/Mkos-Big-Sur
sudo apt install xfce4-whiskermenu-plugin # vala-panel-appmenu

命令行下配置 xfce4:
xfconf-query    -c xfwm4 -p /general/workspace_count
xfconf-query    -c xfwm4 -p /general/workspace_count -s 2

xfconf-query -l           # 查看可设置的分类项
xfconf-query -l -c xfwm4  # 查看该分类的可设置项
xfconf-query -l -c xfce4-desktop
xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitorscreen/workspace0/last-image  -s /usr/share/backgrounds/xfce/xfce-flower.svg


xfconf-query -c xsettings -p /Net/ThemeName

xfconf-query -c xsettings -p /Net/ThemeName -s Adwaita
xfconf-query -c xfwm4     -p /general/theme -s Adwaita

SESSION_MANAGER environment variable not defined
参考这个文件：
/etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml


<?xml version="1.0" encoding="UTF-8"?>

<channel name="xfce4-session" version="1.0">
  <property name="general" type="empty">
    <property name="FailsafeSessionName" type="string" value="Failsafe"/>
    <property name="LockCommand" type="string" value=""/>
  </property>
  <property name="sessions" type="empty">
    <property name="Failsafe" type="empty">
      <property name="IsFailsafe" type="bool" value="true"/>
      <property name="Count" type="int" value="5"/>
      <property name="Client0_Command" type="array">
        <value type="string" value="jwm"/>
      </property>
      <property name="Client0_Priority" type="int" value="15"/>
      <property name="Client0_PerScreen" type="bool" value="false"/>
      <property name="Client3_Priority" type="int" value="30"/>
      <property name="Client3_PerScreen" type="bool" value="false"/>
      <property name="Client4_Command" type="array">
        <value type="string" value="xfdesktop"/>
      </property>
      <property name="Client4_Priority" type="int" value="35"/>
      <property name="Client4_PerScreen" type="bool" value="false"/>
    </property>
  </property>
</channel>




# 重新来过
git clone ${GITHUB_PROXY_HTTP}https://github.com/vinceliuice/WhiteSur-gtk-theme


# ocs-store, 主题管理工具


# 1). 手动下载该主题的各个子包：主题网址：https://www.xfce-look.org/p/1403328
图标：https://www.pling.com/p/1405756/
指针：https://www.pling.com/p/1355701/
壁纸：https://www.pling.com/p/1398833/

手动按标准路径整理好以后，打包：
tar -czvf ../xfce4-theme-osx11.tar.gz  .
mv  -f  ../xfce4-theme-osx11.tar.gz   /mnt/c/Users/lenovo/Desktop/test/osx-theme/

虚拟电脑端启动ftp-server，以方便传文件:
/exbin/tools/vm_fileshare_ftp.sh start  ~/


# 网友 "对不起我憋着" 发的，仅仅是图标集
https://github.com/zayronxio/Mkos-Big-Sur


# 桌面图标正常的，其安装脚本中对xfce4的配置指令非常有参考价值，相关路径： ~/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml
https://github.com/jothi-prasath/SmallSur

gtk-update-icon-cache

appmenu
vala-panel


gtk-color-scheme	= "shadow_color:#000000" # Xfce desktp icons shadow color

XfdesktopIconView::shadow-color = @shadow_color
XfdesktopIconView::selected-shadow-color = @shadow_color

cd /usr/share/themes/WhiteSur-Light/gtk-3.0
gresource list gtk.gresource|grep css
gresource extract gtk.gresource /org/gnome/theme/gtk.css

桌面图标背景问题：
https://forum.xfce.org/viewtopic.php?id=15690#:~:text=Try%20adding%20the%20following%20to%20~%2F.config%2Fgtk-3.0%2Fgtk.css%3A%20%2F%2A%20default,rgba%20to%20suit%20and%20restart%20xfdesktop%3A%20pkill%20xfdesktop


模拟osx界面只需要改：
1). panel.xml
2). 窗口管理器的主题为 Mkosbigsur-gtk
3). 外观的图标类
4). 桌面背景



'
