#!/bin/bash



SWNAME=cajviewer
# SWVER=18.2.3

# 注意安装顺序，后装者依赖前装者
DEB_PATH1=./downloads/${SWNAME}.deb

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}
app_dir=/opt/apps/net.cnki.cajviewer

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh ${GITHUB_PROXY_HOST}`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	case "${CURRENT_VM_ARCH}" in
		"arm64")
			# swUrl="https://download.cnki.net/cajPackage/tongxinUOS/signed_net.cnki.cajviewer_1.4.2-21_arm64.deb"

			# 安装包地址来自：https://github.com/Cateners/tiny_computer/blob/master/lib/workflow.dart		=> 居然无法用 wget 下载！
			swUrl="https://download.cnki.net/net.cnki.cajviewer_1.3.20-1_arm64.deb"
			download_file4 "${DEB_PATH1}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		;;
		# "amd64")
		# 	swUrl="https://download.cnki.net/cajPackage/tongxinUOS/signed_net.cnki.cajviewer_1.4.2-9_amd64.deb"
		# 	download_file2 "${DEB_PATH1}" "${swUrl}"
		# 	exit_if_fail $? "下载失败，网址：${swUrl}"
		# ;;
		*) exit_unsupport ;;
	esac
}

function sw_install() {

	# sudo apt-get install -y  ${ZZSWMGR_MAIN_DIR}/scripts/res/deepin-elf-verify_all.deb ${ZZSWMGR_MAIN_DIR}/${DEB_PATH1}
	sudo apt-get install -y --allow-downgrades ${ZZSWMGR_MAIN_DIR}/${DEB_PATH1}
	exit_if_fail $? "安装失败"

}

function sw_create_desktop_file() {
	echo "正在生成桌面文件"

	tmpfile=${DIR_DESKTOP_FILES}/cajviewer.desktop
	cat <<- EOF > ${tmpfile}
		[Desktop Entry]
		Type=Application
		Name=CAJViewer
		Comment=CAJViewer for Linux
		Icon=/opt/apps/net.cnki.cajviewer/files/cajviewer.png
		Categories=Office;Documentation;
		MimeType=application/caj;application/kdh;application/nh;application/teb;application/pdf;
		Exec=/opt/apps/net.cnki.cajviewer/files/start.sh %u
		Terminal=false
	EOF
	cp2desktop ${tmpfile}

	gxmessage -title "提示"     $'\n安装完成\n\n'  -center
}

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1
	rm -rf ${DEB_PATH1} ${app_dir}

	apt-get purge net.cnki.cajviewer -y
	apt-get -y autoremove --purge net.cnki.cajviewer
	rm2desktop *cajviewer*
	rm -rf /usr/share/applications/*cajviewer*
	apt-get clean
else
	sw_download
	sw_install
	sw_create_desktop_file
fi

