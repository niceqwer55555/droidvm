#!/bin/bash

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

SWNAME=termux
SWVER=2025.06.08-r1

# 注意安装顺序，后装者依赖前装者
DEB_PATH1=./downloads/${SWNAME}.deb
TMX_PATH="./downloads/termux-bootstrap-aarch64.zip"
TMX_PATH="./downloads/termux-rootfs-arm64.tar.gz"

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}
app_dir=/opt/apps/${SWNAME}
TERMUX__PREFIX=/data/data/com.termux/files/usr
WB_PORT=1026

function setup_empty_apk() {
	if [ -d /data/data/com.termux ]; then
		return
	fi

	apk_path="${ZZSWMGR_MAIN_DIR}/scripts/res/包名抢占-com.termux.apk"

	gxmessage -title "请确认" $'\n需要先安装一个空应用到设备上才能继续安装termux，请确认是否继续\n\n您也可以手动安装这个应用\n应用路径：'"${apk_path}"$'\n\n'  -center -buttons "继续安装:0,取消安装:1"
	case "$?" in
		"0")
			:
			;;
		*) 
			echo "您已取消安装"
			exit 1
			;;
	esac

	echo "正在安装 包名抢占.apk"
	cp -f ${apk_path}  /exbin/tmp/droidvm.apk
	echo "#vmUpdateApk" > "${NOTIFY_PIPE}"

	echo "安装过程被打断，请重新安装"
	exit 1
}

function sw_download() {
	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh ${GITHUB_PROXY_HOST}`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	# termux rootfs
	swUrl=${GITHUB_PROXY_HTTP}https://github.com/termux/termux-packages/releases/download/bootstrap-2025.06.08-r1%2Bapt.android-7/bootstrap-aarch64.zip
	swUrl=${GITHUB_PROXY_HTTP}https://github.com/droidvm/tmx-in-any-app/releases/download/rfs/termux-rootfs-arm64.tar.gz
	download_file2 "${TMX_PATH}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

}

function sw_install() {

	# command -v patchelf >/dev/null 2>&1 || sudo apt-get install -y patchelf
	# exit_if_fail $? "patchelf 安装失败"

	# command -v readelf >/dev/null 2>&1 || sudo apt-get install -y binutils
	# exit_if_fail $? "readelf 安装失败"

	# command -v file >/dev/null 2>&1 || sudo apt-get install -y file
	# exit_if_fail $? "file 安装失败"

	command -v unzip >/dev/null 2>&1 || sudo apt-get install -y unzip
	exit_if_fail $? "unzip 安装失败"
	
	echo "正在解压 termux-rootfs 到 ${TERMUX__PREFIX}../ . . ."
	mkdir -p ${app_dir}			2>/dev/null
	mkdir -p ${TERMUX__PREFIX}	2>/dev/null
	mkdir -p /data/data/com.termux/cache/apt/archives/partial 2>/dev/null
	# unzip -oq ${TMX_PATH} -d     ${TERMUX__PREFIX}/
	tar -xzf ${TMX_PATH} --overwrite -C ${TERMUX__PREFIX}/../
	exit_if_fail $? "解压失败，软件包：${TMX_PATH}"

	if [ -f "${TERMUX__PREFIX}/SYMLINKS.txt" ]; then
		echo "正在处理 文件链接"
		# export IFS= 
		while read -r line; do
			echo "正在处理 $line"
			l_part="${line%%←*}"
			r_part="${line#*←}"
			#echo "l: $l_part"
			#echo "r: $r_part"

			dir=`dirname ${r_part}`
			#echo "d: $dir"

			nam=`basename ${r_part}`
			#echo "n: $nam"
			(cd ${TERMUX__PREFIX}/$dir && ln -sf ${l_part}  ${nam})
		done < "${TERMUX__PREFIX}/SYMLINKS.txt"
	fi

	echo "正在更换软件仓库地址"
	mkdir -p ${TERMUX__PREFIX}/etc/apt/sources.list.d 2>/dev/null
	echo "deb https://mirrors.tuna.tsinghua.edu.cn/termux/apt/termux-main stable main" > ${TERMUX__PREFIX}/etc/apt/sources.list
	echo "deb https://mirrors.tuna.tsinghua.edu.cn/termux/apt/termux-x11 x11 main"     > ${TERMUX__PREFIX}/etc/apt/sources.list.d/x11.list

}

function sw_create_desktop_file() {

	# 保留备用
	echo "正在生成桌面文件"
	tmpfile=${DIR_DESKTOP_FILES}/${SWNAME}.desktop
	cat <<- EOF > ${tmpfile}
		[Desktop Entry]
		Name=${SWNAME}
		GenericName=${SWNAME}
		Exec=${SWNAME}
		Terminal=true
		Type=Application
		Icon=/exbin/tools/zzswmgr/ezapp/tmx/tmx.png
	EOF
	cp2desktop ${tmpfile}


	cat <<- EOF > ${app_dir}/tmx-init
		#!${TERMUX__PREFIX}/bin/bash
		export TERMUX_APK_RELEASE=UNKNOWN
		# export TERMUX_APP_PID=6405
		export TERMUX_APP__DATA_DIR=/data/user/0/com.termux
		export TERMUX_APP__LEGACY_DATA_DIR=/data/data/com.termux
		export TERMUX_APP__SE_FILE_CONTEXT=u:object_r:app_data_file:s0:c37,c257,c512,c768
		export TERMUX_APP__SE_INFO=default:targetSdkVersion=28:complete
		export TERMUX_IS_DEBUGGABLE_BUILD=1
		export TERMUX_MAIN_PACKAGE_FORMAT=debian
		export TERMUX_VERSION=0.118.3
		export TERMUX__HOME=/data/data/com.termux/files/home
		export TERMUX__PREFIX=/data/data/com.termux/files/usr
		export  TERMUX_PREFIX=${TERMUX__PREFIX}
		export         PREFIX=${TERMUX__PREFIX}
		export TERMUX__ROOTFS_DIR=/data/data/com.termux/files
		export TERMUX__SE_PROCESS_CONTEXT=u:r:untrusted_app_27:s0:c37,c257,c512,c768
		export TMPDIR=/data/data/com.termux/files/usr/tmp
		export LANG=en_US.UTF-8
		## LD_PRELOAD 会导致 glibc/bin/bash 起不来!
		# export LD_PRELOAD=/data/data/com.termux/files/usr/lib/libtermux-exec.so
		# export LD_PRELOAD=/data/data/com.termux/files/usr/lib/libtermux-exec-ld-preload.so
		export LINES=42
		export MACHTYPE=aarch64-unknown-linux-android
		export MAILCHECK=60
		export TERM=xterm-256color
		# export TERM=vt100
		export HOME=/data/data/com.termux/files/home
		# export PATH=/data/data/com.termux/files/usr/bin
		# exec bash

		# mobox
		export RESOLUTION=1024x768
		export PATH=\$PATH:\${TERMUX_PREFIX}/glibc/bin:\${TERMUX_PREFIX}/bin:\$PATH
		unset  BOX64_LD_LIBRARY_PATH
		export BOX64_LD_LIBRARY_PATH=\${TERMUX_PREFIX}/glibc/lib:\${TERMUX_PREFIX}/glibc/lib/x86_64-linux-gnu
		export BOX64_NOBANNER=1
		export BOX64_LOG=5
		unset BOX64_DYNAREC_BIGBLOCK
		unset WINEESYNC
		unset WINEESYNC_TERMUX
		unset BOX64_DYNAREC_CALLRET

		# app
		export app_home=${APP_INTERNAL_DIR}
		export tools_dir=${APP_INTERNAL_DIR}/tools
		. ${APP_INTERNAL_DIR}/hostvars.rc
		${APP_INTERNAL_DIR}/ndktelnetd -p ${WB_PORT} -l ${TERMUX__PREFIX}/bin/bash

		# export HOME=${WB_PATH}/home
		# cd ~
		# clear
		# export app_home=${APP_INTERNAL_DIR}
		# export tools_dir=${APP_INTERNAL_DIR}/tools
		# export CURRENT_OS_DIR=${APP_INTERNAL_DIR}/vm/${CURRENT_OS_NAME}
		# export TERMUX_PREFIX=${WB_PATH}
		# export        PREFIX=${WB_PATH}/usr
		# export LD_PRELOAD=${WB_PATH}/usr/lib/libtermux-exec.so
		# export PATH=${WB_PATH}:${WB_PATH}/usr/bin:/exbin
		# export TMPDIR=${WB_PATH}/usr/tmp
		# export TERM=vt100
		# export LANG=C.UTF-8
		# . ${WB_PATH}/hostvars.rc
		# ndktelnetd -p ${WB_PORT} -l ${WB_PATH}/usr/bin/bash

		# # echo "欢迎使用termux"
		# # # pkg update -y --allow-unauthenticated
		# # exec ${WB_PATH}/usr/bin/bash

	EOF
	chmod a+x ${app_dir}/tmx-init

	cat <<- EOF > /usr/bin/${SWNAME}
		#!/bin/bash

		echo "export      DISPLAY=\${DISPLAY}"      > ${app_home}/hostvars.rc
		echo "export PULSE_SERVER=\${PULSE_SERVER}" >>${app_home}/hostvars.rc

		cd ${app_dir}

		ps ax|grep ndktelnetd|grep ${WB_PORT} >/dev/null 2>/dev/null
		if [ \$? -ne 0 ]; then
			droidexec ./tmx-init
			# sleep 0.5
		fi
		echo "termux官方网站：https://termux.dev/"
		echo "termux移植来的，仅用于运行wbox，非全功能termux!"
		echo "不支持 termux-api等与app极度相关的扩展功能"
		echo ""
		echo -e "您也可以通过telnet连接本机的\e[96m${WB_PORT}\e[0m端口来使用termux"
		# echo -e "\e[96m要安装 mobox, 请运行：./mobox-installer/setup.sh \e[0m"
		echo ""
		exec telnet 127.0.0.1 ${WB_PORT}

	EOF
	chmod a+x /usr/bin/${SWNAME}

	# # gxmessage -title "提示" "安装已完成，双击桌面上 tmx 图标即可启动" -center  &

}

if [ "${action}" == "卸载" ]; then
	echo "暂不支持卸载"
	exit 1

	rm -rf ${WBOXDIR}
	rm -rf /usr/bin/${SWNAME}
	rm2desktop ${SWNAME}.desktop

else
	setup_empty_apk
	sw_download
	sw_install
	sw_create_desktop_file
fi

: '

${GITHUB_PROXY_HTTP}https://github.com/droidvm/tmx-in-any-app/releases/download/rfs/termux-rootfs-arm64.tar.gz

'
