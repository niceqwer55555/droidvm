#!/bin/bash

SWNAME=EasiNote
SWVER=5.2.2.4.12789

# 注意安装顺序，后装者依赖前装者
DEB_PATH1=./downloads/${SWNAME}-${SWVER}.deb

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE="com.seewo.easinote5.desktop"
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	case "${CURRENT_VM_ARCH}" in
		"arm64")
			swUrl="https://imlizhi-store-https.seewo.com/EasiNote_UOS_arm64_5.2.2.4.12789(20250228143928).deb"
			download_file2 "${DEB_PATH1}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		;;
		*) exit_unsupport ;;
	esac
}

function sw_install() {

	apt-get install -y libasound2t64
	exit_if_fail $? "依赖库安装失败"

	install_deb ${DEB_PATH1} ${DEB_PATH2} ${DEB_PATH3}
	install_deb ${DEB_PATH1}
	exit_if_fail $? "安装失败，软件包：${DEB_PATH1}"

	sed -i "s| %F| --no-sandbox %F|g" /usr/share/applications/com.seewo.easinote5.desktop
	exit_if_fail $? "启动图标处理失败"

	sed -i "/MimeType/d" /usr/share/applications/com.seewo.easinote5.desktop
	exit_if_fail $? "启动图标处理失败"

	echo "SEEWO" > /opt/apps/com.seewo.easinote5/files/resources/public/bios_version
}

function sw_create_desktop_file() {
	tmpfile=${DSK_PATH}
	cp2desktop ${tmpfile}

	gxmessage -title "提示"     $'\n安装完成\n\n'  -center
}

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1
	

	pkgname2rm=linuxqq
	echo "正在 dpkg --remove --force-remove-reinstreq ${pkgname2rm}"
	dpkg --remove --force-remove-reinstreq ${pkgname2rm}
	exit_if_fail $? "force-remove-reinstreq 失败"

	echo "正在 apt-get purge ${pkgname2rm} -y"
	apt-get purge ${pkgname2rm} -y

	rm -rf ${app_dir} ${DIR_DESKTOP_FILES}/${SWNAME}.desktop
	rm2desktop ${SWNAME}.desktop
else
	sw_download
	sw_install
	sw_create_desktop_file
fi

