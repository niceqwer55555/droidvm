#!/bin/bash

SWNAME=xfce4-theme-default
DEB_PATH1=./downloads/${SWNAME}.tar.gz

action=$1
if [ "$action" == "" ]; then action=安装; fi

# pwd
. ./scripts/common.sh

if [ "${action}" == "卸载" ]; then
	echo "暂不支持卸载"
	exit 1
else

	which startxfce4 >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo ""				      		> /tmp/msg.txt
		echo "xfce4未安装，请先安装"	>>/tmp/msg.txt
		echo ""				      		>>/tmp/msg.txt
		gxmessage -title "提示" -file /tmp/msg.txt -center
		exit 1
	fi

	sudo -u ${ZZ_USER_NAME} rm -rf ${ZZ_USER_HOME}/.config/xfce4

	echo "安装完成."
	gxmessage -title "提示" "安装完成, 重启生效"  -center &
fi
