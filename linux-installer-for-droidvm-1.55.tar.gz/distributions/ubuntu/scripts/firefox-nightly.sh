#!/bin/bash

SWNAME=firefox-nightly
SWVER=${tmp_version}

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	# zzgetapthost
	# echo "当前apt仓库主机名: ${CURR_APT_HOST}"

	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh  packages.mozilla.org`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

}

function sw_install() {

	wget -q https://packages.mozilla.org/apt/repo-signing-key.gpg -O /etc/apt/keyrings/packages.mozilla.org.asc
	exit_if_fail $? "安装失败, 无法将firefox官网仓库的访问密钥添加到系统中"

	# 官方仓库
	echo "deb [           signed-by=/etc/apt/keyrings/packages.mozilla.org.asc] https://packages.mozilla.org/apt                 mozilla main" > /etc/apt/sources.list.d/mozilla.list

	# 清华仓库
	echo "deb [arch=arm64 signed-by=/etc/apt/keyrings/packages.mozilla.org.asc] https://mirrors.tuna.tsinghua.edu.cn/mozilla/apt mozilla main" > /etc/apt/sources.list.d/mozilla.list
	exit_if_fail $? "安装失败, 无法将firefox官网仓库的地址添加到系统中"

	cat <<- EOF > /etc/apt/preferences.d/mozilla
		Package: *
		Pin: origin packages.mozilla.org
		Pin-Priority: 1000
	EOF
	exit_if_fail $? "仓库配置失败，无法优先使用firefox官网仓库中的软件"

	apt-get update
	exit_if_fail $? "无法获取仓库中的软件清单"

	# apt-get install firefox
	apt-get install -y firefox-nightly firefox-nightly-l10n-zh-cn
	exit_if_fail $? "安装失败"

	rm -rf /etc/apt/sources.list.d/mozilla.list
	apt-get update
	exit_if_fail $? "无法获取仓库中的软件清单"


	echo "正在首次运行，以生成相关的配置文件"
	rm -rf /home/${ZZ_USER_NAME}/.mozilla
	sudo -u      ${ZZ_USER_NAME} firefox-nightly &

	sleep 10
	pkill firefox-bin

	prefsPath=`find /home/${ZZ_USER_NAME}/.mozilla/ -name prefs.js|head -n 1`
	if [ "${prefsPath}" != "" ]; then
		cat <<- EOF >> ${prefsPath}
			user_pref("media.cubeb.sandbox", false);
			user_pref("security.sandbox.content.level", 0);
		EOF
		exit_if_fail $? "无法禁用firefox的沙盒功能，在proot环境中这会导致网页崩溃"
	else
		echo "无法禁用firefox的沙盒功能，在proot环境中这会导致网页崩溃"
		echo "请按以下步骤自行禁用:"
		cat <<- EOF
			firefox 标签面崩溃处理：
			在firefox浏览器中输入about:config
			搜索sandbox
			把"media.cubeb.sandbox"的值改成false
			把"security.sandbox.content.level"的值改为0
		EOF
	fi

}

function sw_create_desktop_file() {
	cp2desktop ${DSK_PATH}

	# # update-alternatives --display x-www-browser
	# # update-alternatives --config x-www-browser
	# # ls -l /usr/bin/x-www-browser
	# # ln -sf /usr/bin/chrome /etc/alternatives/x-www-browser
	# # xdg-settings get default-web-browser

	# # 用于命令行下 open https://www.***.com
	# sudo update-alternatives --remove x-www-browser /usr/bin/firefox-nightly
	# sudo update-alternatives --install /usr/bin/x-www-browser x-www-browser /usr/bin/${SWNAME} 210
	# sudo update-alternatives --set x-www-browser /usr/bin/${SWNAME}
	# sudo ln -sf /usr/bin/${SWNAME} /etc/alternatives/x-www-browser

	# # 这个可以让chrome不再显示“不是您的默认浏览器”
	# sudo -u ${ZZ_USER_NAME} xdg-settings set default-web-browser firefox-nightly.desktop

	gxmessage -title "提示"     $'\n安装完成\n请关闭firefox后重新打开\n\n'  -center &       # 一定要是单引号

	# if [ -f ./scripts/res/chrome.pref/Bookmarks ]; then
	# 	sudo -u ${ZZ_USER_NAME} mkdir -p ${ZZ_USER_HOME}/.config/chromium/Default
	# 	sudo -u ${ZZ_USER_NAME} cp -f ./scripts/res/chrome.pref/Bookmarks ${ZZ_USER_HOME}/.config/chromium/Default/Bookmarks
	# fi

	# if [ -f ./scripts/res/chrome.pref/Preferences ]; then
	# 	sudo -u ${ZZ_USER_NAME} mkdir -p ${ZZ_USER_HOME}/.config/chromium/Default
	# 	sudo -u ${ZZ_USER_NAME} cp -f ./scripts/res/chrome.pref/Preferences ${ZZ_USER_HOME}/.config/chromium/Default/Preferences
	# fi

}

if [ "${action}" == "卸载" ]; then
	apt-get remove firefox-nightly firefox-nightly-l10n*
	rm2desktop ${SWNAME}.desktop
else
	sw_download
	sw_install
	sw_create_desktop_file
fi
