#!/bin/bash

SWNAME=termux-pulseaudio
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

if [ "${action}" == "卸载" ]; then
	rm -rf ${tools_dir}/tmx_pulseaudio
else
	# 下载演示音频
	DEB_PATH=./downloads/tmx_pulseaudio.tar.gz
	swUrl=${APP_URL_DLSERVER}/tmx_pulseaudio.tar.gz
	download_file2 "${DEB_PATH}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

	mkdir -p ${tools_dir}/tmx_pulseaudio 2>/dev/null
	tar -xzf ${DEB_PATH} -C ${tools_dir}/tmx_pulseaudio
	exit_if_fail $? "解压失败：${DEB_PATH}"

	gxmessage -title "提示" "安装已完成，但需要重启一次才会生效"  -center &
fi
