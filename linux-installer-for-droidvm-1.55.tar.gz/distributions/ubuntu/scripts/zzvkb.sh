#!/bin/bash

SWNAME=zzvkb

action=$1
if [ "$action" == "" ]; then action=安装; fi

# pwd
. ./scripts/common.sh

if [ "${action}" == "卸载" ]; then
	rm -rf /usr/bin/zzvkb
	rm -rf /etc/autoruns/autoruns_after_gui/zzvkb.desktop 2>/dev/null
else
	apt-get install -y python3-xlib
	exit_if_fail $? "依赖库安装失败"

	STARTUP_SCRIPT_FILE=/usr/bin/zzvkb
	cat <<- EOF > ${STARTUP_SCRIPT_FILE}
		#!/bin/bash
		chmod a+x /exbin/tools/zzswmgr/ezapp/zzvkb/zzvkb.py
		exec      /exbin/tools/zzswmgr/ezapp/zzvkb/zzvkb.py "\$@"
	EOF
	chmod a+x ${STARTUP_SCRIPT_FILE}

	# 添加到自启动目录
	tmpfile=/etc/autoruns/autoruns_after_gui/zzvkb.desktop
	cat <<- EOF > ${tmpfile}
		[Desktop Entry]
		Name=全键位屏幕键盘
		GenericName=全键位屏幕键盘
		Exec=zzvkb
		Terminal=false
		Icon=/exbin/tools/zzswmgr/appicons/zzvkb.jfif
		Type=Application
		Categories=System;Utility;
		Keywords=keyboard;input
	EOF

  echo "安装完成."
  gxmessage -title "提示" "安装完成，重启生效"  -center
fi
