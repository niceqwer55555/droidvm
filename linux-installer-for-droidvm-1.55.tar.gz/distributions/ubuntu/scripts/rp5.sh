#!/bin/bash

SWNAME=rp5

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh


if [ "${action}" == "卸载" ]; then
	sudo xdg-mime default pcmanfm.desktop "inode/directory"
else
	sudo xdg-mime default pcmanfm.desktop "inode/directory"
fi

: '
查询关联
xdg-mime query default "inode/directory"

全局文件关联：/usr/share/applications/default.list
个人文件关联：~/.local/share/applications/mimeapps.list
个人文件关联：~/.config/mimeapps.list			# ubuntu-24.04 中这个有效


ls -al /etc/alternatives
ls -al /usr/bin/|grep xdg
'
