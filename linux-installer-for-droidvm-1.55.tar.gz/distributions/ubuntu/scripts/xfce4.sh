#!/bin/bash

SWNAME=xfce4

action=$1
if [ "$action" == "" ]; then action=安装; fi

# pwd
. ./scripts/common.sh

function create_xfce4_menu() {
  # XDG菜单规范：https://specifications.freedesktop.org/menu-spec/1.0/
  # export ZZ_USER_HOME=/home/droidvm
  NEW_CAT=droidvm
  NAMECAT=虚拟系统
  DSK_CAT=/usr/share/applications/${NAMECAT}
  _PREFIX=xfce4

  DIR_XDG_MENU=${ZZ_USER_HOME}/.config/menus/applications-merged
  DIR_XDG_MENU=/etc/xdg/menus/applications-merged
  NAMEXDESKTOP=${_PREFIX}-${NEW_CAT}.directory
  PATHXDESKTOP=/usr/share/desktop-directories/${NAMEXDESKTOP}
  PATHXDSK_CH1=/usr/share/desktop-directories/${_PREFIX}-${NEW_CAT}.child1.directory
  PATHXDSK_CH2=/usr/share/desktop-directories/${_PREFIX}-${NEW_CAT}.child2.directory
  PATHXDSK_CH3=/usr/share/desktop-directories/${_PREFIX}-${NEW_CAT}.child3.directory

  mkdir -p ${DIR_XDG_MENU} 2>/dev/null
  mkdir -p ${DSK_CAT}      2>/dev/null

	# 菜单显示的顺序，会根据 ".desktop" 文件中的Name字段值进行排序
	cat <<- EOF > ${DIR_XDG_MENU}/${_PREFIX}-${NEW_CAT}.menu
		<!DOCTYPE Menu PUBLIC "-//freedesktop//DTD Menu 1.0//EN" "http://www.freedesktop.org/standards/menu-spec/menu-1.0.dtd">
		<Menu>
			<Name>Applications</Name>
			<Menu>
						<Name>${NAMECAT}</Name>
						<!--AppDir>/usr/share/applications</AppDir-->
						<Directory>${NAMEXDESKTOP}</Directory>
						<Include>
							<Category>${NEW_CAT}</Category>
						</Include>

						<Layout>
							<Menuname>name_resetdpi</Menuname>
							<Menuname>name_rcontrol</Menuname>
							<Menuname>name_fileshare</Menuname>
							<Separator/>
							<Merge type="all"/>
						</Layout>

						<Menu>
							<Name>name_resetdpi</Name>
							<Directory>${_PREFIX}-${NEW_CAT}.child3.directory</Directory>
							<Include>
								<Category>resetdpi</Category>
							</Include>
						</Menu>

						<Menu>
							<Name>name_rcontrol</Name>
							<Directory>${_PREFIX}-${NEW_CAT}.child1.directory</Directory>
							<!--AppDir>${DSK_CAT}</AppDir-->
							<Include>
								<Category>rcontrol</Category>
							</Include>
							<Exclude>
								<Filename>droidvm_natshell.desktop</Filename>
							</Exclude>
							<Layout>
								<Filename>droidvm_natshell.desktop</Filename>
								<Separator/>
								<Merge type="all"/>
							</Layout>
						</Menu>

						<Menu>
							<Name>name_fileshare</Name>
							<Directory>${_PREFIX}-${NEW_CAT}.child2.directory</Directory>
							<Include>
								<Category>fileshare</Category>
							</Include>
						</Menu>
			</Menu>
		</Menu>
	EOF

	cat <<- EOF > ${PATHXDESKTOP}
		[Desktop Entry]
		Version=1.0
		Type=Directory
		Encoding=UTF-8
		Icon=/exbin/tools/zzswmgr/appicons/ic_launcher.png
		Name=${NAMECAT}
		Name[zh_CN]=${NAMECAT}
		Comment=droidvm quick menu
		Comment[zh_CN]=虚拟系统专用操作
	EOF

	cat <<- EOF > ${PATHXDSK_CH3}
		[Desktop Entry]
		Version=1.0
		Type=Directory
		Encoding=UTF-8
		Name=屏幕DPI
		Name[zh_CN]=屏幕DPI
	EOF


	cat <<- EOF > ${PATHXDSK_CH1}
		[Desktop Entry]
		Version=1.0
		Type=Directory
		Encoding=UTF-8
		Name=远程控制
		Name[zh_CN]=远程控制
	EOF

	cat <<- EOF > ${PATHXDSK_CH2}
		[Desktop Entry]
		Version=1.0
		Type=Directory
		Encoding=UTF-8
		Name=文件共享
		Name[zh_CN]=文件共享
	EOF

	cat <<- EOF > ${DSK_CAT}/droidvm_update_zzswmgr.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=更新软件管家(需重启)
		Comment=更新软件管家(需重启)
		Exec=/exbin/tools/vm_updateBootScript.sh
		Terminal=false
		Type=Application
		Icon=
		Categories=${NEW_CAT};
	EOF

	cat <<- EOF > ${DSK_CAT}/droidvm_update_app.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=升级虚拟电脑(需重启)
		Comment=升级虚拟电脑(需重启)
		Exec=/exbin/tools/vm_updateApk.sh
		Terminal=false
		Type=Application
		Icon=
		Categories=${NEW_CAT};
	EOF

	cat <<- EOF > ${DSK_CAT}/droidvm_fileshare_ftp.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=通过ftp共享 ~/
		Comment=通过ftp共享 ~/
		# Exec=/exbin/tools/vm_fileshare_ftp.sh start ~/
		Exec=bash -c /exbin/nmftpsrv -p 5557 -c gb18030 -d ~/
		Terminal=true
		Type=Application
		Icon=
		Categories=fileshare;
	EOF

	cat <<- EOF > ${DSK_CAT}/droidvm_natshell.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=远程协助
		Comment=远程协助
		Exec=cmd -e /exbin/tools/vm_natshell2.sh
		Terminal=false
		Type=Application
		Icon=
		Categories=rcontrol;
	EOF

	cat <<- EOF > ${DSK_CAT}/droidvm_rcontrol_ttyd.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=启动ttyd
		Comment=启动ttyd
		Exec=/exbin/tools/vm_webtty_control.sh start
		Terminal=false
		Type=Application
		Icon=
		Categories=rcontrol;
	EOF

	cat <<- EOF > ${DSK_CAT}/droidvm_rcontrol_telnetd.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=启动telnetd
		Comment=启动telnetd
		Exec=/exbin/tools/vm_telnet_control.sh start
		Terminal=false
		Type=Application
		Icon=
		Categories=rcontrol;
	EOF

	cat <<- EOF > ${DSK_CAT}/droidvm_rcontrol_sshd.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=启动sshd
		Comment=启动sshd
		Exec=cmd -e /exbin/tools/vm_ssh_control.sh start
		Terminal=false
		Type=Application
		Icon=
		Categories=rcontrol;
	EOF

	cat <<- EOF > ${DSK_CAT}/resetdpi_96.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=96
		Comment=96
		Exec=/exbin/tools/vm_set_dpi.sh 96
		Terminal=false
		Type=Application
		Icon=
		Categories=resetdpi;
	EOF

	# 菜单显示的顺序，会根据 ".desktop" 文件中的Name字段值进行排序
	cat <<- EOF > ${DSK_CAT}/resetdpi_96.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=096
		Comment=96
		Exec=/exbin/tools/vm_set_dpi.sh 96
		Terminal=false
		Type=Application
		Icon=
		Categories=resetdpi;
	EOF

	cat <<- EOF > ${DSK_CAT}/resetdpi_112.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=112
		Comment=112
		Exec=/exbin/tools/vm_set_dpi.sh 112
		Terminal=false
		Type=Application
		Icon=
		Categories=resetdpi;
	EOF

	cat <<- EOF > ${DSK_CAT}/resetdpi_128.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=128
		Comment=128
		Exec=/exbin/tools/vm_set_dpi.sh 128
		Terminal=false
		Type=Application
		Icon=
		Categories=resetdpi;
	EOF

	cat <<- EOF > ${DSK_CAT}/resetdpi_144.desktop
		[Desktop Entry]
		Version=1.0
		Encoding=UTF-8
		Name=144
		Comment=144
		Exec=/exbin/tools/vm_set_dpi.sh 144
		Terminal=false
		Type=Application
		Icon=
		Categories=resetdpi;
	EOF



}

if [ "${action}" == "卸载" ]; then
	sudo apt-get remove -y ${SWNAME}
	sudo apt-get remove -y pavucontrol
	rm -rf ${app_home}/app_boot_config/cfg_de.txt
else

	gxmessage -title "是否继续安装？" $'\n不建议不熟悉linux环境的新手在虚拟电脑中使用xfce\n\n虚拟电脑集成的所有界面类脚本都是针对jwm+pcmanfm桌面环境整理的\n使用xfce将不能使用虚拟电脑集成的各类便捷脚本\n\n'  -center -buttons "继续安装:0,取消安装:1"
	case "$?" in
		"0")
			:
			;;
		*) 
			echo "您已取消安装"
			exit 1
			;;
	esac

	# sudo apt-get install -y ${SWNAME}
	# sudo apt-get install -y --no-install-recommends ${SWNAME}
	sudo apt-get install -y --no-install-recommends xfce4-session xfce4-terminal xfce4-settings xfce4-panel xfwm4 xfdesktop4 thunar pavucontrol xfce4-pulseaudio-plugin plank  compton thunar-archive-plugin
	exit_if_fail $? "xfce4安装失败"
	echo "xfce4" > ${app_home}/app_boot_config/cfg_de.txt


	# 在安卓中的容器内运行xfce4，需要减少其进程数量，尽量保证app内进程数据在32个以内！
	fbak=/usr/lib/aarch64-linux-gnu/bamf/bamfdaemon.bak
	[ -f ${fbak} ] || mv -f /usr/lib/aarch64-linux-gnu/bamf/bamfdaemon                      ${fbak}

	fbak=/usr/lib/aarch64-linux-gnu/xfce4/panel/plugins/libactions.so.bak
	[ -f ${fbak} ] || mv -f /usr/lib/aarch64-linux-gnu/xfce4/panel/plugins/libactions.so    ${fbak}

	fbak=/etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml.bak
	[ -f ${fbak} ] || cp -f /etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml     ${fbak}

	fbak=/usr/bin/startxfce4.bak
	[ -f ${fbak} ] || cp -f /usr/bin/startxfce4                                             ${fbak}


	rm -rf /usr/bin/xfce4-tinysession
	cp -f /etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml.bak    /etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml

	create_xfce4_menu

	# 实测发现：图标主题无法生效
	cat <<- EOF > /usr/bin/startxfce4.less_process
		#!/usr/bin/bash
		xfwm4 &
		xfdesktop &
		xfce4-panel &
	EOF
	chmod a+x /usr/bin/startxfce4.less_process

	echo "xfce4安装完成."
	gxmessage -title "提示" "xfce4安装完成, 重启生效"  -center &
fi

: '
xfwm4 --display :4 --replace &

最终确定是以下这10个图片文件决定的标题栏高度：
title-1-active.xpm
title-1-inactive.xpm
...
title-5-active.xpm
title-5-inactive.xpm



'
