#!/bin/bash

SWNAME=rp4

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh


if [ "${action}" == "卸载" ]; then
	:
else
	while true
	do
		badpkg=`grep -B 2 "Status: install reinstreq" /var/lib/dpkg/status | awk '/Package:/ {print $2}'|head -n 1`

		if [ "$badpkg" == "" ]; then
			echo ""
			echo "已清理系统中只安装到一半的损坏包"
			exit 0
		else
			echo "正在清理：${badpkg}"
			sudo dpkg --remove --force-remove-reinstreq ${badpkg}
			sudo dpkg --purge --force-all ${badpkg}
		fi
	done
fi



: '

apt 相关路径：
/var/lib/dpkg/status	# 已安装的软件列表
/var/lib/dpkg/info		# 已安装软件的卸载脚本
/var/cache/apt/archives	# apt指令下载的deb，存放在这里


编辑 /var/lib/dpkg/status
并将对应包的状态改成：install reinstreq half-installed
即可触发错误：xxx 需要重新安装，但无法找到该安装包

function makedeb() {
	# 参考：https://blog.csdn.net/badbayyj/article/details/129353140

  pkg_name=$1
  pkg_version=$2
	DEB_DIR=/tmp/${pkg_name}
	DEB_OUT=${DEB_DIR}.deb


	mkdir -p ${DEB_DIR}/DEBIAN 2>/dev/null
	echo "Package: ${pkg_name}"               > ${DEB_DIR}/DEBIAN/control
	echo "Version: ${pkg_version}"            >>${DEB_DIR}/DEBIAN/control
	echo "Architecture: arm64"                >>${DEB_DIR}/DEBIAN/control
	echo "Maintainer: droidvm"                >>${DEB_DIR}/DEBIAN/control
	echo "Description: empty deb package"     >>${DEB_DIR}/DEBIAN/control
	# echo "Replaces: *"                      >>${DEB_DIR}/DEBIAN/control
	# echo "Depends: libc6:armhf"             >>${DEB_DIR}/DEBIAN/control
	chmod 755 ${DEB_DIR}/DEBIAN/control

	# 打包！
	dpkg -b ${DEB_DIR}

	if [ -f ${DEB_OUT} ]; then
		echo "DEB包生成成功 => ${DEB_OUT}"
    export DEB_OUT
		# open ${RLT_DIR}/..  &
		return 0
	fi

	return 1
}

makedeb rp4test 1.48
sudo apt install -y /tmp/rp4test.deb

vi /var/lib/dpkg/status

手动将状态改为：
install reinstreq half-installed

再：
rm -rf /tmp/rp4test.deb

'