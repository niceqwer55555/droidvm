#!/bin/bash

SWNAME=adminer

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	echo ""
}

function sw_install() {
	if [ ! -d /var/www/html ]; then
		echo ""					> /tmp/msg.txt
		echo "请先安装nginx"	>>/tmp/msg.txt
		echo ""					>>/tmp/msg.txt
		gxmessage -title "提示" -file /tmp/msg.txt -center
		exit 1
	fi

	# 安装adminer，比较phpmyadmin简单、轻量的数据库管理工具(基于浏览器)
	wget https://github.com/vrana/adminer/releases/download/v4.8.1/adminer-4.8.1.php -O /var/www/html/adminer.php
	exit_if_fail $? "安装失败${SWNAME}"

	echo "安装完成!"
	echo "保存路径: /var/www/html/adminer.php"
}

function sw_create_desktop_file() {
	echo ""
}

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1
	rm -rf /var/www/html/adminer.php
else

	sw_download
	sw_install

	sw_create_desktop_file

	gxmessage -title "提示"     $'安装完成\n保存路径为：/var/www/html/adminer.php\n\n'  -center        # 一定要是单引号

fi
