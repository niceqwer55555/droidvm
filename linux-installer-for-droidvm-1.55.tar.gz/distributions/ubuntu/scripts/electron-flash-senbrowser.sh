#!/bin/bash

SWNAME=electron-flash-senbrowser
SWVER=11.0.5

# 注意安装顺序，后装者依赖前装者
DEB_PATH1=./downloads/${SWNAME}-${SWVER}.zip
DEB_PATH2=./downloads/${SWNAME}-app.zip

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}
app_dir=/opt/apps/${SWNAME}-${SWVER}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {

	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh ${GITHUB_PROXY_HOST}`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	case "${CURRENT_VM_ARCH}" in
		"arm64")
			swUrl="${GITHUB_PROXY_HTTP}https://github.com/electron/electron/releases/download/v11.0.5/electron-v11.0.5-linux-armv7l.zip"
			download_file2 "${DEB_PATH1}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"

			swUrl="https://gitee.com/droidvm/electron-flash-senbrowser/repository/archive/master.zip"
			swUrl="${GITHUB_PROXY_HTTP}https://github.com/yusenyi123/electron-flash-senbrowser/archive/refs/heads/master.zip"
			download_file2 "${DEB_PATH2}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		;;
		*) exit_unsupport ;;
	esac
}

function sw_install_depends() {
	echo "正在启用 multi-arch ..."
	sudo dpkg --add-architecture armhf
	exit_if_fail $? "依赖包安装失败"

	sudo apt update
	exit_if_fail $? "apt仓库刷新失败"

	# sudo dpkg --print-foreign-architectures # 确认有没有显示出 armhf

	echo "正在安装必须的 armhf 依赖库"
	sudo apt-get install -y libc6:armhf libkrb5support0:armhf  libk5crypto3:armhf
	exit_if_fail $? "依赖库 libc6:armhf 安装失败"

	sudo apt-get install -y libk5crypto3:armhf
	exit_if_fail $? "依赖库 libk5crypto3:armhf 安装失败"

	sudo apt-get install -y libkrb5-3:armhf
	exit_if_fail $? "依赖库 libkrb5-3:armhf 安装失败"

	sudo apt-get install -y libgssapi-krb5-2:armhf
	exit_if_fail $? "依赖库 libgssapi-krb5-2:armhf 安装失败"

	sudo apt-get install -y --allow-downgrades \
		libc6:armhf \
		zlib1g:armhf  \
		libstdc++6:armhf \
		libglib2.0-0t64:armhf  \
		libnss3:armhf  \
		libatk1.0-0t64:armhf \
		libatk-bridge2.0-0t64:armhf  \
		libatk-bridge2.0-0t64:armhf  \
		libx11-xcb1:armhf   \
		libgdk-pixbuf-xlib-2.0-0:armhf  \
		libgtk-3-0t64:armhf  \
		libdrm2:armhf     \
		libgbm1:armhf   \
		libasound2t64:armhf   \
		libasound2-plugins:armhf
	exit_if_fail $? "32位依赖库安装失败"
}

function sw_install() {

	apt-get install -y gamemode
	exit_if_fail $? "gamemode 加速工具安装失败"

	apt-get install -y unzip
	exit_if_fail $? "unzip 解压工具安装失败"

	mkdir -p ${app_dir} 2>/dev/null
	exit_if_fail $? "无法创建目录: ${app_dir}"

	unzip -oq ${DEB_PATH1} -d ${app_dir}
	exit_if_fail $? "安装失败，软件包：${DEB_PATH1}"

	unzip -oq ${DEB_PATH2} -d ${app_dir}
	exit_if_fail $? "安装失败，软件包：${DEB_PATH2}"

	rm -rf ${app_dir}/app
	sudo mv ${app_dir}/electron-flash-senbrowser-master  ${app_dir}/app
	exit_if_fail $? "无法重命名文件夹"

	chmod 777  ${app_dir}/*
	exit_if_fail $? "无法授予 ${app_dir}/electron 可执行权限"

	sw_install_depends

}

function sw_create_desktop_file() {
	echo "正在生成桌面文件"

	cat <<- EOF > /usr/bin/${SWNAME}
		#!/bin/bash
		gamemoderun ${app_dir}/electron --no-sandbox ${app_dir}/app
	EOF
	chmod a+x /usr/bin/${SWNAME}

	tmpfile=${DSK_PATH}
	cat <<- EOF > ${tmpfile}
		[Desktop Entry]
		Name=FlashPlayer
		GenericName=FlashPlayer
		Exec=${SWNAME}
		Terminal=false
		Type=Application
		Icon=/exbin/tools/zzswmgr/appicons/flash.jpg
	EOF
	cp2desktop ${tmpfile}

	gxmessage -title "提示"     $'\n安装完成\n\n'  -center
}

if [ "${action}" == "卸载" ]; then
	# echo "暂不支持卸载"
	# exit 1
	rm -rf /usr/bin/${SWNAME}
	rm -rf ${app_dir}
	rm2desktop ${SWNAME}.desktop
else
	/system/bin/getprop ro.product.cpu.abilist|grep armeabi
	exit_if_fail $? "你的设备不支持32位模式, 所以不能安装运行这个软件!"

	sw_download
	sw_install
	sw_create_desktop_file
fi

