#!/bin/bash

: '

# 软件包 xxx 需要重新安装，但是我无法找到对应的安装文件
sudo    dpkg    --remove     --force-remove-reinstreq    wps-office

2025.02.11 确认还可以使用
https://mirrors.sdu.edu.cn/spark-store-repository/aarch64-store/office/wps-office/wps-office_11.1.0.11720-fix2_arm64.deb


'

SWNAME=wps-free
DEB_PATH=./downloads/${SWNAME}.deb
FT_PATH1=./downloads/ttf-wps-fonts.tar.xz
FT_PATH2=./downloads/ttf-mst-fonts.tar.xz
FT_PATH3=./downloads/freetype-old.deb
DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

maindeb_installed=0
if [ -d /opt/kingsoft/wps-office ]; then
	maindeb_installed=1
fi


function sw_download() {

	if [ "${CURRENT_VM_ARCH}" != "arm64" ]; then
		exit_unsupport
	fi

	zzgetapthost

	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh ${CURR_APT_HOST} mirrors.sdu.edu.cn gitee.com`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	# 下载主安装包!，如果桌面上有安装包，就从桌面上直接复制过来，而不会下载
	if [ ! -f "${DEB_PATH}" ]; then
		# user_download_deb=`ls /home/${ZZ_USER_NAME}/Desktop/${SWNAME}*.deb 2>/dev/null`
		# if [ -f "${user_download_deb}" ]; then
		# 	cp -f "${user_download_deb}" "${DEB_PATH}"
		# 	exit_if_fail $? "安装包无法复制：${user_download_deb}"
		# else
		# 	echo ""
		# 	echo "安装包请到资源群下载，不要改文件名，并放到桌面上, 最后再回到这里重装。"
		# 	echo "(QQ群中下载后, 长按文件, 选使用虚拟电脑打开, 文件即可传送到桌面上)"
		# 	echo "${APP_QQ_Qzy}, 安装包名：wps-free-11.1.0.11720_arm64.deb"
		# 	exit 1

			swUrl="https://mirrors.sdu.edu.cn/spark-store-repository/aarch64-store/office/wps-office/wps-office_11.1.0.11720-fix2_arm64.deb"
			download_file2 "${DEB_PATH}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		# fi
	fi

	# 下载wps字体
	swUrl=https://gitee.com/ak2/ttf-wps-fonts/raw/master/ttf-wps-fonts.tar.xz
	download_file2 "${FT_PATH1}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

	# 下载ms字体
	swUrl=https://gitee.com/ak2/msttcorefonts/raw/master/msttcorefonts.tar.xz
	download_file2 "${FT_PATH2}" "${swUrl}"
	exit_if_fail $? "下载失败，网址：${swUrl}"

	# # 字体加粗异常问题的修复包，即旧的freetype库, fix2 版已处理，不再需要在此脚本中另外进行修复
	# case "${CURRENT_VM_ARCH}" in
	# 	"arm64")
	# 		#swUrl=https://mirrors.tuna.tsinghua.edu.cn/ubuntu-ports/pool/main/f/freetype/libfreetype6_2.12.1%2Bdfsg-4_arm64.deb
	# 		swUrl="https://mirrors.tuna.tsinghua.edu.cn/ubuntu-ports/pool/main/f/freetype/libfreetype6_2.13.3%2Bdfsg-1_arm64.deb"
	# 		;;
	# 	"amd64")
	# 		# 2025.02.11 决定不再维护 amd64 版本！
	# 		swUrl=https://mirrors.tuna.tsinghua.edu.cn/ubuntu/pool/main/f/freetype/libfreetype6_2.12.1%2Bdfsg-4_amd64.deb
	# 		;;
	# 	*) exit_unsupport ;;
	# esac
	# download_file2 "${FT_PATH3}" "${swUrl}"
	# exit_if_fail $? "下载失败，网址：${swUrl}"
}


function sw_install() {
	# hard code patch for wps-aarch64 reinstall operation
	if [ -f /usr/share/applications/wps-office-wps.desktop ]; then
		echo "检测到您正在重新安装wps，为避免wps.postinst 出错，此处加了hard code"
		cp -f /usr/share/applications/wps-office-wps.desktop	/usr/share/applications/wps-office-wps-aarch64.desktop
		cp -f /usr/share/applications/wps-office-et.desktop		/usr/share/applications/wps-office-et-aarch64.desktop
		cp -f /usr/share/applications/wps-office-wpp.desktop	/usr/share/applications/wps-office-wpp-aarch64.desktop
	fi

	sudo dpkg --configure -a

	# 有用户交互部分！！！ 等效于 ttf-ms-core-fonts ${FT_PATH2}, 下载太慢，所以2025.02.11废弃不用了，换成 https://gitee.com/ak2/msttcorefonts
	# aceept_command=debconf-set-selections
	# echo ttf-mscorefonts-installer msttcorefonts/accepted-mscorefonts-eula select true | ${aceept_command}
	# sudo apt-get install -y ttf-mscorefonts-installer
	# exit_if_fail $? "ms字体安装失败"

	# 这个包安装太耗时，这里生成一个空deb来跳过，后面的代码会从gitee下载这份字体
	TMP_PKG_NAME="ttf-mscorefonts-installer"
	apt list --installed|grep "${TMP_PKG_NAME}"
	if [ $? -ne 0 ]; then
		makedeb "${TMP_PKG_NAME}" "3.8.1ubuntu1"
		if [ "${DEB_OUT}" != "" ]; then
			dpkg -i --force-overwrite ${DEB_OUT}
		fi
	fi

	echo "正在安装wps字体"
	tar -Jxvf "${FT_PATH1}" --overwrite -C /
	exit_if_fail $? "wps字体安装失败"

	echo "正在安装ms字体"
	tar -Jxvf "${FT_PATH2}" --overwrite -C /
	exit_if_fail $? "ms字体安装失败"

	# 更新字体缓存
	sudo fc-cache -f -v

	issame_cpu_arch "${DEB_PATH}"
	exit_if_fail $? "安装包的CPU架构不匹配，请下载${CURRENT_VM_ARCH}版本的deb安装包"

	# 安装主包, 2025.04.02 添加: libxkbcommon-x11-0
	sudo apt-get install -y --allow-downgrades libxkbcommon-x11-0 libglu1-mesa libxslt-dev bsdmainutils ${ZZSWMGR_MAIN_DIR}/${DEB_PATH}
	exit_if_fail $? "安装失败"

	# 导入补丁脚本 2025.03.08
	. ./scripts/wps-patches-for-droidvm-ubuntu-24.04-2025.03.09.sh
	# patch2_for_wps_login
	patch3_for_wps_create_newfile_online

	freetype6_old_ver="18.1"
	if [ -f /opt/kingsoft/wps-office/office6/old-libs/usr/lib/aarch64-linux-gnu/libfreetype.so.6.${freetype6_old_ver}]; then

		# http://security.debian.org/debian-security/pool/updates/main/f/freetype/libfreetype6_2.12.1+dfsg-5+deb12u4_arm64.deb

		cp -f   /opt/kingsoft/wps-office/office6/old-libs/usr/lib/aarch64-linux-gnu/libfreetype.so.6.${freetype6_old_ver} /opt/kingsoft/wps-office/office6/
		exit_if_fail $? "旧版freetype复制失败"

		cd /opt/kingsoft/wps-office/office6/ && ln -sf libfreetype.so.6.${freetype6_old_ver} libfreetype.so.6
		exit_if_fail $? "旧版freetype复制失败"
	fi



	# 错误1：找不到 libproviders.so 
	# 是因为虚拟电脑使用的rootfs较新，带的openssl也较新, export OPENSSL_CONF=/dev/null 可以不报此错误

	# 错误2：Some formula symbols might not be displayed correctly due to missing fonts. 缺失字体
	# https://gitee.com/ak2/ttf-wps-fonts
	# https://gitee.com/ak2/msttcorefonts

	# 错误3：backup fail/backup目录不可设置，backup功能不可关闭
	# 还是proot环境不能处理 mount 映射，导致wps把备份目录识别成只读的(/home/droidvm/.local/share/Kingsoft/office6/data/backup)
}

function sw_create_desktop_file() {
	patch4_for_wps_starter
	# # 2024.08.03 添加, 用以处理界面默认为英文的问题
	# sed -i "s|Exec=|Exec=env LANGUAGE= |g" /usr/share/applications/wps*.desktop
	# sed -i "s|Exec=|Exec=env LANGUAGE= |g" /home/${ZZ_USER_NAME}/Desktop/wps*.desktop
}

function check_installed() {
	# dpkg -s wps-office 1
	# apt list --installed | grep wps-office
	dpkg-query -l wps-office 2>/dev/null
	if [ $? -eq 0 ]; then
		gxmessage -title "请确认" $'\n系统中已安装过wps。\n若它无法运行，建议清除后再继续安装\n\n是否先将其清除？\n\n'  -center -buttons "清除掉:0,不清除:1,取消安装:2"
		case "$?" in
			"0")
				
				echo "正在 dpkg --remove --force-remove-reinstreq wps-office"
				dpkg --remove --force-remove-reinstreq wps-office
				exit_if_fail $? "force-remove-reinstreq 失败"

				echo "正在 apt-get purge wps-office -y"
				apt-get purge wps-office -y

				echo "正在 apt-get -y autoremove --purge wps-office"
				apt-get -y autoremove --purge wps-office

				echo "正在删除主安装文件夹"
				rm -rf /opt/kingsoft/wps-office

				echo "正在删除桌面图标"
				rm2desktop wps-office*

				;;
			"1")
				:
				;;
			*) 
				echo "您已取消安装"
				exit 1
				;;
		esac
	fi
}

if [ "${action}" == "卸载" ]; then
	# sudo    dpkg    --remove     --force-remove-reinstreq    wps-office
	apt-get purge wps-office -y
	apt-get -y autoremove --purge wps-office
	rm2desktop wps-office*
	rm -rf /usr/share/applications/wps-office-wps*
	rm -rf /opt/kingsoft/wps-office
	rm -rf /home/${ZZ_USER_NAME}/.local/share/Kingsoft
	rm -rf /home/${ZZ_USER_NAME}/.config/Kingsoft
else
	check_installed
	sw_download
	sw_install
	sw_create_desktop_file
fi

