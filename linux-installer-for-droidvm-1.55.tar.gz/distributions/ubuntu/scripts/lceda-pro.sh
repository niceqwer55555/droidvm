#!/bin/bash

SWNAME=lceda-pro
SWVER=2.2.36.7

# 注意安装顺序，后装者依赖前装者
DEB_PATH1=./downloads/${SWNAME}-${SWVER}.zip

DIR_DESKTOP_FILES=/usr/share/applications
DSK_FILE=${SWNAME}.desktop
DSK_PATH=${DIR_DESKTOP_FILES}/${DSK_FILE}
app_dir=/opt/apps/${SWNAME}

action=$1
if [ "$action" == "" ]; then action=安装; fi

. ./scripts/common.sh

function sw_download() {
	tmpdns=`cd /exbin && droidexec ./vm_getHostByName.sh image.lceda.cn`
	exit_if_fail $? "DNS解析失败"
	echo "$tmpdns" >> /etc/hosts

	case "${CURRENT_VM_ARCH}" in
		"arm64")
			swUrl="https://image.lceda.cn/files/lceda-pro-linux-arm64-2.2.36.7.zip"
			download_file1 "${DEB_PATH1}" "${swUrl}"
			exit_if_fail $? "下载失败，网址：${swUrl}"
		;;
		"amd64") exit_unsupport ;;
		*) exit_unsupport ;;
	esac
}

function sw_install() {
	echo "正在安装. . ."

	mkdir -p /opt/apps 2>/dev/null
	exit_if_fail $? "安装失败，无法创建目录"

	unzip -oq  ${DEB_PATH1} -d ${ZZSWMGR_TEMP_DIR}
	exit_if_fail $? "安装失败，软件包：${DEB_PATH1}"

	rm -rf /opt/apps/${SWNAME}
	mv ${ZZSWMGR_TEMP_DIR}/lceda-pro /opt/apps/
	exit_if_fail $? "安装失败，无法移动文件"

}

function sw_create_desktop_file() {
	echo "正在生成桌面文件"

	sed -i "s|/opt/lceda|/opt/apps/lceda|g"    /opt/apps/lceda-pro/lceda-pro.dkt

	cp /opt/apps/lceda-pro/lceda-pro.dkt ${DSK_PATH}
	cp2desktop ${DSK_PATH}

	gxmessage -title "提示"     $'\n安装完成\n\n'  -center
}

if [ "${action}" == "卸载" ]; then
	rm -rf /opt/apps/${SWNAME}
	rm2desktop ${SWNAME}.desktop
else
	sw_download
	sw_install
	sw_create_desktop_file
fi

